#!/usr/bin/env python3
"""One isolated native actor per case/condition; immutable attempts, no timer polling."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import importlib.util
import json
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import time

ORIGINAL = Path('/Users/artk0re/Dev/Tools/tea-rags-mcp')
BASE = Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('step_metadata',ORIGINAL/'.tmp/metadata-evals/run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
helper=module.helper

def attach(base):
    module.BASE=base;helper.BASE=base

def preflight(meta):
    out=Path(meta['directory'])/'preflight-no-turn'
    rpc=helper.rpc_for(meta,out)
    try:
        thread=rpc.call('thread/start',{'cwd':meta['cwd'],'model':'gpt-6.1-sol','permissions':'routing_eval','approvalPolicy':'never','ephemeral':True,'experimentalRawEvents':True})
        helper.dump(out/'thread-start.json',thread)
        assert thread['model']=='gpt-6.1-sol' and thread['reasoningEffort']=='medium'
        assert not thread.get('instructionSources')
        tid=thread['thread']['id']
        hooks=rpc.call('hooks/list',{'threadId':tid,'cwds':[]})
        helper.dump(out/'hooks.json',hooks)
        flat=[h for row in hooks['data'] for h in row['hooks']]
        assert flat and all(h['trustStatus']=='trusted' and h.get('pluginId')=='tea-rags@tea-rags' for h in flat)
        skills=rpc.call('skills/list',{'cwds':[meta['cwd']],'forceReload':True})
        helper.dump(out/'skills.json',skills)
        enabled=[s for row in skills['data'] for s in row['skills'] if s.get('enabled')]
        assert enabled and all(s.get('pluginId')=='tea-rags@tea-rags' for s in enabled)
        status=rpc.call('mcpServerStatus/list',{'threadId':tid,'limit':100})
        deadline=time.monotonic()+90
        while not status['data'] or any(s.get('runtimeStatus')=='starting' for s in status['data']):
            # Native startup notifications, not timers or busy polling.
            rpc.next(timeout=max(1,deadline-time.monotonic()))
            assert time.monotonic()<deadline,'MCP startup deadline'
            status=rpc.call('mcpServerStatus/list',{'threadId':tid,'limit':100})
        helper.dump(out/'mcp.json',status)
        assert len(status['data'])==1 and status['data'][0]['runtimeStatus']=='connected',status
        protected=[str(BASE/'run.py'),str(Path(meta['directory'])/'fixture.json'),str(Path(meta['directory'])/'actor-input.json'),'/Users/artk0re/.codex/auth.json',str(ORIGINAL/'package.json')]
        probe='paths='+repr(protected)+'\nfor p in paths:\n try:\n  with open(p,"rb") as f: f.read(1)\n  print("ALLOWED")\n except OSError as e: print("DENIED",e.errno)\n'
        result=rpc.call('command/exec',{'command':[helper.PY,'-c',probe],'cwd':meta['cwd'],'permissionProfile':'routing_eval','timeoutMs':10000})
        helper.dump(out/'filesystem-denials.json',result)
        assert result['stdout'].count('DENIED 1')==len(protected),result
        summary={'ready':True,'model_turns':0,'trusted_hooks':len(flat),'enabled_skills':len(enabled),'mcp':'connected','denied_paths':len(protected)}
        helper.dump(Path(meta['directory'])/'preflight.json',summary)
        return summary
    finally:helper.close_rpc(rpc)

def prepare(source,condition):
    run=BASE/condition
    run.mkdir() # Never overwrite a condition.
    attach(run)
    shutil.copy2(BASE/'fixture_mcp.py',run/'fixture_mcp.py')
    shutil.copy2(BASE/'run.py',run/'run.py')
    shipped=source/'harness/codex/tea-rags'
    snapshot=run/'marketplace/harness/codex/tea-rags'
    shutil.copytree(shipped,snapshot)
    inv=helper.inventory(shipped)
    assert helper.inventory(snapshot)==inv
    version=json.loads((snapshot/'.codex-plugin/plugin.json').read_text())['version']
    catalog=json.loads((source/'.agents/plugins/marketplace.json').read_text())
    catalog['plugins']=[p for p in catalog['plugins'] if p['name']=='tea-rags']
    target=run/'marketplace/.agents/plugins';target.mkdir(parents=True)
    helper.dump(target/'marketplace.json',catalog)
    casepath=Path(args.cases).resolve()
    cases=json.loads(casepath.read_text())['evals']
    manifest={'ROOTGO':False,'preparation_complete':False,'condition':condition,'model':'gpt-6.1-sol','effort':'medium','runs_per_case':1,'plugin_version':version,
              'source_root':str(source),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),
              'source_plugin_sha256':inv,'helper_sha256':helper.sha(ORIGINAL/'.tmp/plugin-routing-evals/run.py'),
              'fixture_server_sha256':helper.sha(run/'fixture_mcp.py'),'case_source_sha256':helper.sha(casepath),
              'runtime_cases_sha256':None,'cases':[],'retry_policy':'No actor repeats, failed and unrun remain open'}
    shutil.copy2(casepath,run/'cases-source.json');manifest['runtime_cases_sha256']=helper.sha(run/'cases-source.json')
    helper.dump(run/'manifest.json',manifest)
    for case in cases:
        directory=run/'cases'/case['id'];directory.mkdir(parents=True)
        meta=module.compile_case(case,directory)
        helper.install_and_trust(meta,run/'marketplace',version,inv)
        meta['preflight']=preflight(meta)
        meta['config_sha256']=helper.sha(Path(meta['home'])/'config.toml')
        manifest['cases'].append(meta);helper.dump(run/'manifest.json',manifest)
        print('PREPARED',condition,case['id'],'zero model turns',flush=True)
    manifest['preparation_complete']=True;manifest['case_source_sha256']=manifest['runtime_cases_sha256']
    helper.dump(run/'manifest.json',manifest)

def execute(condition):
    run=BASE/condition;attach(run)
    m=json.loads((run/'manifest.json').read_text())
    assert m['preparation_complete'] and not m['ROOTGO']
    assert not any((Path(c['directory'])/'actor').exists() for c in m['cases'])
    m['ROOTGO']=True;m['authorization']='User: ок, фикси; one affected/control run per condition, 6.1 Sol medium'
    helper.dump(run/'manifest.json',m)
    def one(c):
        result=subprocess.run([helper.PY,str(BASE/'run.py'),'worker','--condition',condition,'--key',c['key']],capture_output=True,text=True)
        print(result.stdout.strip(),flush=True)
        if result.stderr:print(result.stderr[-1600:],flush=True)
        return {'key':c['key'],'exit_code':result.returncode}
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(one,c) for c in m['cases']]
        exits=[f.result() for f in as_completed(futures)]
    helper.dump(run/'worker-exits.json',exits)
    assert all(x['exit_code']==0 for x in exits),exits

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','run','worker'])
    p.add_argument('--condition',required=True);p.add_argument('--source');p.add_argument('--cases');p.add_argument('--key')
    args=p.parse_args()
    if args.action=='prepare':prepare(Path(args.source).resolve(),args.condition)
    elif args.action=='run':execute(args.condition)
    else:
        attach(BASE/args.condition)
        sys.exit(module.worker(args.key))
