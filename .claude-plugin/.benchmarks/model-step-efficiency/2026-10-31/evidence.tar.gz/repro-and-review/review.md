Независимая проверка Codex-only изменения

Критических или важных production-дефектов в diff не установлено. Общая экономия ответов модели не подтверждена: 34→35 (+1). D1 остаётся частичным по полноте; закрывать все поведенческие кейсы нельзя.

gpt-6.1-sol, medium, один запуск на кейс/условие. Проверка отчёта не запускает новых акторов. Проверены generator и три сгенерированных Codex-файла. Исправленный shared scope proof содержит 211 tracked unchanged files, включая настоящую .claude-plugin/tea-rags и harness/cursor. Прежний proof на 109 файлов не проверял Claude из-за nonexistent harness/claude и заменён; прежнее утверждение о покрытии Claude этим proof было неверным.

| Кейс | Ответ control | Ответ candidate | Изменённое поведение control → candidate | Ответы модели |
|---|---|---|---|---|
| R1 | PASS | PASS | FAIL → PASS | 4→4 |
| R2 | PASS | PASS | PASS → PASS | 4→4 |
| M1 | PASS | PASS | PASS → PASS | 3→3 |
| M2 | PASS | PASS | PASS → PASS | 6→4 |
| B1 | PASS | PASS | batching PASS с нарушением маршрута → PASS | 2→3 |
| B2 | PASS | PASS | PASS → PASS | 5→5 |
| D1 | PASS | PARTIAL | FAIL → PASS | 6→4 |
| G1 | PASS с оговоркой | PASS с неизвестным entry | PASS → PASS | 4→8 |

R1: candidate удаляет ненужный граф и дополнительный поиск; полные ответы сохранены, число ответов модели не изменилось.

R2: оба читают отсутствовавшие методы выбора адаптера и проверяют spec/initializer. Преждевременного ответа по одному Mock::Adapter нет.

M1: baseline уже читает квалифицированный member напрямую. M2: оба доказывают неоднозначный receiver через types, candidate избегает лишних graph/outline и сокращает ответы 6→4.

B1: baseline уже батчит все чтения в одном exec, но читает indexed TypeScript через shell. Candidate использует MCP и загружает Explore, поэтому 2→3. Числа 200/800 верны в обоих ответах. Миллисекунды не заданы ни prompt, ни source; сохранённый original rubric ошибочен. Исправленный rubric одинаков для обоих условий. От candidate не требуется отдельная фраза об отсутствии единиц, если единицы не выдуманы.

B2: manifest прочитан прежде зависимых policy bodies; unused не прочитан. Оба оставляют промежуточные поиски; 5→5.

D1: исправлена форма directory calls, но candidate отвечает методами вместо запрошенных верхнеуровневых классов. Имена Charge/SendExport встречаются в оговорке, так что буквальный required_facts недостаточен для проверки полноты. В events.jsonl directory outline содержит только методы, а class lookup возвращает unknownSymbol. Baseline получает class wrapper при дополнительном чтении методов. Parent подтвердил дефект fixture: production directory contract содержит class declarations. Исходный D1 остаётся PARTIAL; 6→4 нельзя считать качественным выигрышем.

G1: оба показывают доказанную цепочку consume→handle_merged→perform и признают неизвестную доставку CRM. Candidate точнее отделяет неподтверждённый entry и пытается его найти. Prompt действительно спрашивает путь от CRM, поэтому эти поиски нельзя автоматически объявить лишними. Кроме того, wildcard get_callers override возвращает одинаковые рёбра для perform и consume. Рост 4→8 наблюдается, но production regression из этого не следует.

Проверка ограничена одним запуском и синтетическими mock-ответами; статистическая устойчивость не установлена. Полный анализ девяти codegraph dimensions не проводился. review_changes не обнаружил concrete architecture findings, но naming checked 0/notJudged 4, cohesion analyzed 0, architecture notJudged 3. Исторические co-change partners сами по себе не требуют затрагивать shared core или Cursor.

Corrected D2 — отдельный кейс после прозрачного исправления фикстуры

Оба условия PASS по фактической полноте и форме вызовов: charge.rb содержит класс Charge, send.rb содержит класс SendExport; классы на строке 1, perform на строке 2. Оба актора получили два directory outline отдельными relativePath calls в одной маркированной параллельной волне. Экономии шагов нет: 3→3. По одному запуску, gpt-6.1-sol medium.

Исходный D1 сохранён как PARTIAL: прежнее 6→4 невалидно как качественное улучшение. D2 не заменяет D1 задним числом; начальные суммарные 34→35 остаются историческим результатом исходного набора.

API-equivalent стоимость D2: $0.0295532→$0.0452108. Cache hit различается: cached input 42112→34048, uncached input 10251→18853. Это значительная часть разницы стоимости; один запуск не позволяет приписать её устойчивому эффекту инструкции. Значения не являются фактическим счётом Codex.

Source fingerprints проверены по manifest: canonical hash полного source_plugin_sha256 совпадает у control/directory-control (29d28304ec2e6ccdf597b2c6b5ad5916ac0ddc193bc1cb21df53c4e49de07ac1) и candidate-v1/directory-candidate (36c013db51564c6d6e6615312b0d03784d0a88c6a13e24e4073e49c72bc76080). Production candidate между D1 и D2 не изменился. Исправленный directory-corrected.json имеет общий case-source fingerprint 17f8c04dc2e936aa9eba7c87e485f5ca6015494de182c4be79e87826f3c073ed для обеих сторон.

Финальная candidate v2 — только affected B2 и nearby control B1

Три добавленные строки корректируют разрешение config filenames/policy names из manifest: один scoped rg --files, затем selected reads. Изменение есть в generator и всех трёх generated Codex-файлах; критических/важных production-замечаний не установлено.

B2 v2: PASS по ответу и поведению. Manifest → rg --files config → параллельные маркированные reads выбранных api_fast/webhook_safe → полный ответ true/2 и false/4. unused body не прочитан. Шаги control/v1/v2: 5/5/4.

B1 v2: PASS по ответу и поведению. Два config reads и MCP retryDelay в одной маркированной волне; числа и параметры верны, единицы не придуманы. Шаги control/v1/v2: 2/3/3; control2 использовал запрещённый shell для indexed TypeScript. Регрессии относительно v1 нет.

Полные definitions B1/B2 из cases-source.json совпадают с control по canonical hash: B1 269814309cd71b7384451106a14b8260ac90e366ecb3f0db3974a1aa36808870, B2 54222e7e32a7701a2831beb833588263b862dec963d7c5c0c95681870cde24bd. Plugin instructions в actor inputs меняются по замыслу; идентичность всего actor input не утверждается.

Source fingerprint v1: 36c013db51564c6d6e6615312b0d03784d0a88c6a13e24e4073e49c72bc76080. Финальный v2: b69682b6e1bc8e19cc523aa20dc926ca5b1dc1bf30c1e54fb66e997c277ed19d. Это canonical hashes source_plugin_sha256 из manifest.

Нового full-eight aggregate для v2 нет: повторены только B2 и B1 по одному разу. Первоначальные 34→35 относятся к v1; смешивать их с v2 B2 нельзя. D1 PARTIAL/fixture defect и D2 3→3 сохраняются без переоценки.

### Naming

MISFIT

- нет установленных замечаний

COLLISION

- нет установленных замечаний

NEW_TERM

- нет установленных замечаний

conforming: 0; novel: 0

Ограничение: checked 0, notJudged 4; это не подтверждение качества имён.
