"""Offline native response accounting. No models, no inferred quality score."""
import argparse
from decimal import Decimal
import json
from pathlib import Path

FIELDS=('inputTokens','cachedInputTokens','cacheWriteInputTokens','outputTokens','reasoningOutputTokens','totalTokens')
p=argparse.ArgumentParser();p.add_argument('condition');args=p.parse_args()
root=Path(__file__).resolve().parent/args.condition
manifest=json.loads((root/'manifest.json').read_text());rows=[]
for meta in manifest['cases']:
    directory=Path(meta['directory']);actor=directory/'actor';statuspath=actor/'status.json'
    if not statuspath.exists():continue
    status=json.loads(statuspath.read_text());responses={};calls={};final={};wrappers={};cumulative=None
    for line in (actor/'events.jsonl').open():
        event=json.loads(line);method=event.get('method');params=event.get('params',{});item=params.get('item',{})
        if method=='rawResponse/completed':
            assert params.get('responseId'),'Response identity missing'
            responses[params['responseId']]=params.get('usage',{})
        if method=='thread/tokenUsage/updated':cumulative=params['tokenUsage']['total']
        if method=='rawResponseItem/completed' and item.get('type') in ('custom_tool_call','function_call'):
            wrappers[item.get('call_id',item.get('id'))]=item
        if method!='item/completed':continue
        if item.get('type') in ('mcpToolCall','commandExecution'):calls[item['id']]=item
        if item.get('type')=='agentMessage' and item.get('phase')=='final_answer':final[item['id']]=item.get('text','')
    usage={k:sum(r.get(k,0) for r in responses.values()) for k in FIELDS}
    assert cumulative and all(usage[k]==cumulative[k] for k in FIELDS),(meta['key'],usage,cumulative)
    uncached=usage['inputTokens']-usage['cachedInputTokens']
    cost=(Decimal(uncached)*2+Decimal(usage['cachedInputTokens'])*Decimal('0.1')+Decimal(usage['outputTokens'])*10)/1000000
    if usage['cacheWriteInputTokens']:raise ValueError('Explicit cache writes require separate accounting')
    row={'case':meta['key'],'completed':status.get('valid',False),'model_responses':len(responses),
         'usage':usage,'uncached_input':uncached,'standard_API_equivalent_USD':str(cost),
         'raw_equals_native_total':True,'final_answer':'\n\n'.join(final.values()),
         'native_calls':[{'id':i['id'],'type':i['type'],'tool':i.get('tool'),'arguments':i.get('arguments'),'command':i.get('command'),'status':i.get('status')} for i in calls.values()],
         'outer_calls':list(wrappers.values()),'quality':'NOT GRADED'}
    (actor/'answer.txt').write_text(row['final_answer']+'\n')
    rows.append(row)
out={'condition':args.condition,'primary_metric':'underlying native model responses; parallel tools inside response do not multiply steps',
     'model':'gpt-6.1-sol','effort':'medium','runs_per_case':1,'cases':rows,
     'total_model_responses':sum(r['model_responses'] for r in rows),
     'total_API_equivalent_USD':str(sum(Decimal(r['standard_API_equivalent_USD']) for r in rows)),
     'limitations':['Synthetic small retained context, not 200K GruntWorx replay','Raw fixtures supplied as retained text, not fresh native tool history','n=1 per case/condition; no statistical speed claim','Standard API-equivalent is not actual Codex subscription billing']}
(root/'collected.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for r in rows:print(r['case'],r['model_responses'],r['standard_API_equivalent_USD'])
print('TOTAL',out['total_model_responses'],out['total_API_equivalent_USD'])
