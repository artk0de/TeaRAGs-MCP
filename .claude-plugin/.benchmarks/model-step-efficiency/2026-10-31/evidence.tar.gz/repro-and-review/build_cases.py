import json
from pathlib import Path

ROOT = Path('/Users/artk0re/Dev/Tools/tea-rags-mcp/.claude/worktrees/codex-model-steps')
OUT = ROOT / '.claude-plugin/.benchmarks/model-step-efficiency/2026-10-31'
OUT.mkdir(parents=True, exist_ok=True)

def source(path, symbol, content):
    return {'relativePath': path, 'symbolId': symbol, 'startLine': 1,
            'endLine': len(content.splitlines()), 'content': content}

def retained(*bodies):
    return {'project': 'step-fixture', 'messages': [{'role':'tool', 'tool':'find_symbol',
        'result': {'workingTree': {'project':'step-fixture','tree':'__FIXTURE_ROOT__'},
                   'results':[{'payload': b} for b in bodies]}}]}

cases=[]
grades={}
def case(key, prompt, files, context=None, bodies=None, raw=None, **grade):
    c={'id':key,'prompt':prompt,'actor_context':context or {'project':'step-fixture','messages':[]},
       'fixture':{'files':files,'find_symbol_bodies':bodies or {},'raw_tool_responses':raw or []}}
    cases.append(c); grades[key]=grade

client='''module Instead
  class BaseClient
    def initialize(transport: nil)
      @transport = transport
    end
    def adapter_spec
      @transport ? [:test, @transport] : Faraday.default_adapter
    end
  end
end
'''
adapter='''module Instead
  module Mock
    class Adapter < Faraday::Adapter
      def call(env)
        Mock::Router.call(env)
      end
    end
  end
end
'''
files={'lib/instead/base_client.rb':client,'lib/instead/mock/adapter.rb':adapter,
 'config/initializers/instead.rb':'INSTEAD_CLIENT = Instead::BaseClient.new\n',
 'spec/lib/instead/client_spec.rb':'RSpec.describe Instead::BaseClient do\n  subject(:client) { described_class.new(transport: Instead::Mock::Router.new) }\nend\n'}
held=retained(source('lib/instead/base_client.rb','Instead::BaseClient',client),source('lib/instead/mock/adapter.rb','Instead::Mock::Adapter',adapter))
prompt='Как включается mock Instead: используется ли Mock::Adapter при обычной инициализации, как mock подключён в specs и что настроено в initializer?'
case('R1-retained-transport',prompt,files,held,forbidden_tools=['semantic_search','hybrid_search','get_callers','get_callees'],required_facts=['default adapter when transport absent','injected test transport in spec','initializer does not pass transport'])
partial=retained(source('lib/instead/mock/adapter.rb','Instead::Mock::Adapter',adapter))
case('R2-missing-selection-control',prompt,files,partial,required_source=['Instead::BaseClient#adapter_spec'],required_facts=['default adapter when transport absent','injected test transport in spec','initializer does not pass transport'])

caller='''def excel?
  file.attached? ? ContentTypes.excel?(file.content_type) : false
end
'''
mime='''module ContentTypes
  def self.excel?(mime)
    ["application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"].include?(mime)
  end
end
'''
file='app/lib/content_types.rb'
case('M1-qualified-member','Какие MIME-типы excel? реально допускает и пройдёт ли application/vnd.ms-excel.sheet.macroEnabled.12?',
 {file:mime,'app/models/attachment_types.rb':'module AttachmentTypes\n'+caller+'end\n'},
 retained(source('app/models/attachment_types.rb','AttachmentTypes#excel?',caller)),
 {'ContentTypes.excel?':source(file,'ContentTypes.excel?',mime)},
 forbidden_container_symbols=['ContentTypes'],required_facts=['application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','macroEnabled MIME rejected'])
case('M2-ambiguous-receiver-control','Какие MIME-типы разрешает эта проверка в DocumentAttachment и пройдёт ли XLSM MIME?',
 {'app/models/document_attachment.rb':'class DocumentAttachment\n  def types\n    ContentTypes\n  end\n  def excel?\n    types.excel?(file.content_type)\n  end\nend\n',file:mime},
 retained(source('app/models/document_attachment.rb','DocumentAttachment#excel?','def excel?\n  types.excel?(file.content_type)\nend\n')),
 {'ContentTypes.excel?':source(file,'ContentTypes.excel?',mime)},
 required_facts=['receiver ContentTypes','macroEnabled MIME rejected'])

retry='export function retryDelay(attempt: number) { return Math.min(200 * 2 ** attempt, 1600); }\n'
bf={'config/api.yml':'retry:\n  enabled: true\n  max_attempts: 3\n',
    'config/webhook.yml':'retry:\n  enabled: false\n  max_attempts: 5\n',
    'src/retry.ts':retry}
case('B1-independent-reads','Сопоставь config/api.yml и config/webhook.yml: enabled, max_attempts и задержки для attempt 0/2 по retryDelay.',bf,
 retained({'relativePath':'src/retry.ts','symbolId':'retryDelay','startLine':1,'endLine':1,'signature':'retryDelay(attempt: number): number'}),
 {'retryDelay':source('src/retry.ts','retryDelay',retry)},
 raw=[{'tool':'find_symbol','arguments':{'symbols':['retryDelay']},'result':{'results':[{'payload':source('src/retry.ts','retryDelay',retry)}]}}],
 one_wave_targets=['config/api.yml','config/webhook.yml','retryDelay'],required_facts=['api true 3','webhook false 5','200 and 800 milliseconds'])
case('B2-dependent-manifest-control','Какие retry-политики выбраны в config/retries.yml и какие enabled/max_attempts заданы для каждой выбранной политики?',
 {'config/retries.yml':'selected:\n  - api_fast\n  - webhook_safe\n',
  'config/policies/api_fast.yml':'enabled: true\nmax_attempts: 2\n',
  'config/policies/webhook_safe.yml':'enabled: false\nmax_attempts: 4\n',
  'config/policies/unused.yml':'enabled: true\nmax_attempts: 9\n'},
 selected=['api_fast','webhook_safe'],excluded=['unused'],required_facts=['api_fast true 2','webhook_safe false 4'])
case('D1-directory-shape','Какие файлы и верхнеуровневые символы находятся в app/services/billing/ и app/services/exports/?',
 {'app/services/billing/charge.rb':'class Charge\n  def perform\n    :charged\n  end\nend\n',
  'app/services/exports/send.rb':'class SendExport\n  def perform\n    :sent\n  end\nend\n'},
 forbidden_directory_batch=True,required_facts=['app/services/billing/charge.rb','Charge','app/services/exports/send.rb','SendExport'])

merge='def perform\n  move_documents\n  remove_source\nend\n'
trigger={'workingTree':{'project':'step-fixture','tree':'__FIXTURE_ROOT__'},'edges':[
 {'caller':'ContactsConsumer#handle_merged','callee':'MergeForContact#perform'},
 {'caller':'ContactsConsumer#consume','callee':'ContactsConsumer#handle_merged'}]}
case('G1-missing-trigger-control','Как событие CRM приводит к MergeForContact#perform? Покажи цепочку вызовов.',
 {'app/services/merge_for_contact.rb':'class MergeForContact\n'+merge+'end\n',
  'app/consumers/contacts_consumer.rb':'class ContactsConsumer\n  def consume(event)\n    handle_merged(event) if event.type == :merged\n  end\n  def handle_merged(event)\n    MergeForContact.new(event).perform\n  end\nend\n'},
 retained(source('app/services/merge_for_contact.rb','MergeForContact#perform',merge)),
 raw=[{'tool':'get_callers','result':trigger}],
 required_graph=True,required_facts=['ContactsConsumer#consume','ContactsConsumer#handle_merged','MergeForContact#perform'])

(OUT/'cases.json').write_text(json.dumps({'fixture_kind':'synthetic raw-shaped excerpts; no future questions or expected answers','evals':cases},ensure_ascii=False,indent=2)+'\n')
(OUT/'grading.json').write_text(json.dumps({'model':'gpt-6.1-sol','effort':'medium','runs_per_condition':1,'primary_metric':'underlying native model responses, including final','cases':grades},ensure_ascii=False,indent=2)+'\n')
print('WROTE',len(cases),'separated actor cases and grading',OUT)
