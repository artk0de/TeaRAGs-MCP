"""Archive explicit nonsecret eval evidence; keep source captures out of test discovery."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

BASE=Path(__file__).resolve().parent
WORK=Path('/Users/artk0re/Dev/Tools/tea-rags-mcp/.claude/worktrees/codex-model-steps')
TARGET=WORK/'.claude-plugin/.benchmarks/model-step-efficiency/2026-10-31'
stage=BASE/'archive-staging';stage.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def copy(source,target):
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
def gz(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    with source.open('rb') as a,target.open('wb') as b:
        with gzip.GzipFile(filename='',mode='wb',fileobj=b,mtime=0) as z:shutil.copyfileobj(a,z)
    with gzip.open(target,'rb') as a:assert hashlib.sha256(a.read()).hexdigest()==sha(source)

summaries=[]
for condition in ['control','candidate-v1','directory-control','directory-candidate','config-candidate-v2']:
    origin=BASE/condition;out=stage/condition
    for name in ['manifest.json','cases-source.json','worker-exits.json','collected.json','fixture_mcp.py','run.py']:
        copy(origin/name,out/name)
    manifest=json.loads((origin/'manifest.json').read_text())
    plugin=origin/'marketplace/harness/codex/tea-rags'
    shutil.copytree(plugin,out/'plugin-snapshot',dirs_exist_ok=True)
    # Native installed and frozen source inventories must agree, for every actor.
    for meta in manifest['cases']:
        case=Path(meta['directory']);dest=out/'cases'/meta['key']
        for name in ['fixture.json','actor-input.json','preflight.json']:
            copy(case/name,dest/name)
        if (case/'fixture-tool-audit.jsonl').exists():gz(case/'fixture-tool-audit.jsonl',dest/'fixture-tool-audit.jsonl.gz')
        for name in ['status.json','thread-start.json','answer.txt']:
            copy(case/'actor'/name,dest/'actor'/name)
        for name in ['events.jsonl','thread-read.json','turn-events.json']:
            gz(case/'actor'/name,dest/'actor'/(name+'.gz'))
        for name in ['thread-start.json','hooks.json','skills.json','mcp.json','filesystem-denials.json']:
            copy(case/'preflight-no-turn'/name,dest/'preflight-no-turn'/name)
    inventory=manifest['source_plugin_sha256']
    fingerprint=hashlib.sha256(json.dumps(inventory,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    collected=json.loads((origin/'collected.json').read_text())
    summaries.append({'condition':condition,'plugin_version':manifest['plugin_version'],'plugin_fingerprint':fingerprint,
                      'source_head':manifest['source_head'],'model':'gpt-6.1-sol','effort':'medium',
                      'cases':[{k:c[k] for k in ['case','model_responses','usage','uncached_input','standard_API_equivalent_USD']} for c in collected['cases']],
                      'total_model_responses':collected['total_model_responses'],'total_API_equivalent_USD':collected['total_API_equivalent_USD']})

for name in ['run.py','fixture_mcp.py','build_cases.py','collect.py','archive.py','review.md','review.json','review-changes.json','shared-scope-proof.json']:
    copy(BASE/name,stage/'repro-and-review'/name)
for name,path in [('routing-helper.py','.tmp/plugin-routing-evals/run.py'),('metadata-helper.py','.tmp/metadata-evals/run.py'),('app-rpc.py','.tmp/codex61_app_rpc.py')]:
    copy(WORK.parents[2]/path,stage/'repro-and-review'/name)
# Preserve failed zero-model preparation. Its actor directory never existed.
failed=BASE/'candidate'
assert not list(failed.glob('cases/*/actor'))
for name in ['manifest.json','cases-source.json']:
    copy(failed/name,stage/'failed-preparation-zero-models'/name)
for path in Path('/tmp').glob('tea-steps-*.log'):copy(path,stage/'validation-logs'/path.name)
for name in ['tea-codex-steps-baseline-tests.log','tea-codex-steps-candidate-tests.log']:
    copy(Path('/tmp')/name,stage/'validation-logs'/name)
patch=subprocess.check_output(['git','diff','--binary'],cwd=WORK)
(stage/'implementation.patch').write_bytes(patch)
members={str(p.relative_to(stage)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(stage.rglob('*')) if p.is_file()}
(stage/'members.json').write_text(json.dumps(members,indent=2)+'\n')
archive=TARGET/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for p in sorted(stage.iterdir()):t.add(p,arcname=p.name)
with tarfile.open(archive,'r:gz') as t:
    for name,record in members.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==record['sha256'],name
(TARGET/'results.json').write_text(json.dumps({'conditions':summaries,'actor_runs':20,'retries_per_condition':0,
    'archive':{'file':'evidence.tar.gz','sha256':sha(archive),'members_verified':len(members)},
    'limitations':['Same advertised plugin version0.53.9; fingerprints identify changed candidates','No full39 or statistical improvement claim','v2 tests B1/B2 only; do not create a synthetic full-suite total from mixed fingerprints','D1 PARTIAL remains open; D2 is a corrected fixture control','Cache-hit and load differed; Standard API estimates are not subscription bills','Review agent is separate from the20 case actors; reviewer token cost not measured']},ensure_ascii=False,indent=2)+'\n')
print('Archived',len(members),'verified members;',archive.stat().st_size,'bytes')
