#!/usr/bin/env python3
"""Native metadata/search evidence evals; prepare is no-turn, run requires root GO."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
spec = importlib.util.spec_from_file_location('metadata_helpers', ROOT / '.tmp/plugin-routing-evals/run.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.BASE = BASE
original_config = helper.write_config


def profile(meta, plugin, toolbin):
    original_config(meta, plugin, toolbin)
    path = Path(meta['home']) / 'config.toml'
    path.write_text(path.read_text().replace('[features]\n',
        '[features]\nsleep_tool = false\ndefault_mode_request_user_input = true\nunified_exec = true\n', 1))


helper.write_config = profile


class QuestionRPC(helper.transport.RPC):
    def __init__(self, *args, **kwargs):
        self.user_requests = []
        super().__init__(*args, **kwargs)

    def next(self, timeout=180):
        event = self.q.get(timeout=timeout)
        if '_process_exit' in event:
            raise RuntimeError('app-server exited ' + str(event))
        if 'method' in event and 'id' in event:
            if event['method'] == 'item/tool/requestUserInput':
                self.user_requests.append(event)
            else:
                self.send({'id': event['id'], 'error': {'code': -32000, 'message': 'Eval approvals disabled'}})
        return event


helper.transport.RPC = QuestionRPC


def freeze():
    snapshot = BASE / 'marketplace/harness/codex/tea-rags'
    assert not snapshot.exists(), 'Never overwrite a frozen metadata snapshot'
    shipped = ROOT / 'harness/codex/tea-rags'
    shutil.copytree(shipped, snapshot)
    current = helper.inventory(shipped)
    assert helper.inventory(snapshot) == current
    assert json.loads((snapshot / '.codex-plugin/plugin.json').read_text())['version'] == '0.53.9'
    catalog = json.loads((ROOT / '.agents/plugins/marketplace.json').read_text())
    catalog['plugins'] = [p for p in catalog['plugins'] if p['name'] == 'tea-rags']
    (BASE / 'marketplace/.agents/plugins').mkdir(parents=True)
    helper.dump(BASE / 'marketplace/.agents/plugins/marketplace.json', catalog)
    helper.dump(BASE / 'source-plugin-sha256.json', current)
    old_path = ROOT / '.tmp/tool-orchestration-evals/source-plugin-sha256.json'
    older = json.loads(old_path.read_text())
    fingerprint = lambda row: hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    proof = {'version': '0.53.9', 'new_metadata_snapshot_sha256': fingerprint(current),
        'older_wait_only_snapshot_sha256': fingerprint(older),
        'older_inventory_path': str(old_path), 'older_snapshot_untouched': True,
        'changed_files_between_same_version_snapshots': sorted(k for k in current.keys() | older.keys() if current.get(k) != older.get(k))}
    helper.dump(BASE / 'snapshot-fingerprints.json', proof)
    return current


def seed_search():
    source = ROOT / '.claude-plugin/.benchmarks/tool-orchestration/2026-10-30/search-evidence-evals.json'
    output = BASE / 'source-produced-search.json'
    code = '''
import fs from 'node:fs';
import {withAnswerBanner} from './src/core/api/tools/answer-banner.ts';
const input = JSON.parse(fs.readFileSync(process.argv[1], 'utf8'));
for (const c of input.evals) {
  const messages = c.actor_context.messages;
  const last = [...messages].reverse().find(m => m.role === 'tool');
  const raw = last.result;
  last.result = await withAnswerBanner(c.banner_seed.tool, async () => ({structuredContent: raw, content: []}))(c.banner_seed.arguments, {});
}
fs.writeFileSync(process.argv[2], JSON.stringify(input, null, 2) + '\\n');
'''
    result = subprocess.run([helper.NODE, '--import', 'tsx', '--input-type=module', '-e', code, str(source), str(output)],
        cwd=ROOT, text=True, capture_output=True, timeout=30)
    helper.dump(BASE / 'producer-command.json', {'argv_kind': 'node --import tsx; withAnswerBanner from current source',
        'source': str(source), 'source_sha256': helper.sha(source),
        'producer': 'src/core/api/tools/answer-banner.ts',
        'producer_sha256': helper.sha(ROOT / 'src/core/api/tools/answer-banner.ts'),
        'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr, 'model_turns': 0})
    assert result.returncode == 0, result.stderr
    return output


def compile_case(case, directory):
    meta = helper.compile_case('metadata', case, directory)
    meta['key'] = case['id']
    context = case.get('actor_context', {})
    fixture = helper.replace_raw(case['fixture'], meta['cwd'], meta['alias'], context.get('project', 'metadata-fixture'))
    compiled = json.loads((directory / 'fixture.json').read_text())
    for key in ('raw_tool_responses', 'tool_definitions'):
        if key in fixture:
            compiled[key] = fixture[key]
    helper.dump(directory / 'fixture.json', compiled)
    meta['fixture_sha256'] = helper.sha(directory / 'fixture.json')
    return meta


def catalog_proof(meta):
    out = Path(meta['directory']) / 'preflight-no-turn'
    result = subprocess.run([helper.CODEX, 'debug', 'prompt-input'], cwd=meta['cwd'],
        env=helper.native_env(meta['home'], Path(meta['directory']) / 'backend-bin'),
        text=True, capture_output=True, timeout=60)
    (out / 'tool-catalog.json').write_text(result.stdout)
    (out / 'tool-catalog.stderr').write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    raw = json.loads(result.stdout)
    tools = {ns['name'] + '.' + t['name']: t for item in raw if item.get('type') == 'additional_tools'
             for ns in item.get('tools', []) for t in ns.get('tools', [])}
    assert 'clock.sleep' not in tools and 'functions.wait' in tools
    assert 'functions.request_user_input_async' in tools
    assert 'write_stdin(args:' in tools['functions.exec']['description']
    # Native deferred MCP argument schemas must not already appear in M1's initial prompt catalog.
    if meta['key'].startswith('M1'):
        visible = json.dumps(raw, ensure_ascii=False)
        assert 'includeRetryPolicy' not in visible, 'M1 argument schema leaked before discovery'
    proof = {'model_turns': 0, 'sleep_absent': True, 'wait_write_stdin_async_questions_present': True,
             'initial_M1_argument_schema_not_exposed': True if meta['key'].startswith('M1') else None}
    helper.dump(out / 'capability-proof.json', proof)
    return proof


def prepare():
    assert not (BASE / 'manifest.json').exists(), 'Fresh preparation only; no overwrite'
    inventory = freeze()
    source = seed_search()
    result = subprocess.run([helper.PY, str(BASE / 'build_cases.py'), '--search-cases', str(source)],
                            cwd=ROOT, text=True, capture_output=True, timeout=30)
    assert result.returncode == 0, result.stderr
    cases = json.loads((BASE / 'cases-source.json').read_text())['evals']
    assert len(cases) == 5 and len({c['id'] for c in cases}) == 5
    manifest = {'ROOTGO': False, 'model': 'gpt-6.1-sol', 'effort': 'medium', 'plugin_version': '0.53.9',
        'source_plugin_sha256': inventory, 'cases': [], 'prepared_model_turns': 0,
        'helper_sha256': helper.sha(ROOT / '.tmp/plugin-routing-evals/run.py'),
        'runner_sha256': helper.sha(__file__), 'fixture_server_sha256': helper.sha(BASE / 'fixture_mcp.py'),
        'case_source_sha256': helper.sha(BASE / 'cases-source.json'),
        'snapshot_fingerprints': json.loads((BASE / 'snapshot-fingerprints.json').read_text()),
        'producer': json.loads((BASE / 'producer-command.json').read_text()),
        'retry_policy': 'One fresh actor turn per case, no repeat or coaching; no existing actor directory allowed',
        'input_boundary': 'Only prompt and retained raw tool observations; fixture/grading/controller files denied',
        'profile': {'sleep_tool': False, 'default_mode_request_user_input': True},
        'questions': 'Retained unanswered for real user; other approvals denied. No canned answers.'}
    helper.dump(BASE / 'manifest.json', manifest)
    for case in cases:
        directory = BASE / 'cases' / case['id']
        directory.mkdir(parents=True)
        meta = compile_case(case, directory)
        helper.install_and_trust(meta, BASE / 'marketplace', '0.53.9', inventory)
        meta['preflight'] = helper.preflight(meta)
        meta['capability_proof'] = catalog_proof(meta)
        meta['config_sha256'] = helper.sha(Path(meta['home']) / 'config.toml')
        manifest['cases'].append(meta)
        helper.dump(BASE / 'manifest.json', manifest)
        print('PREFLIGHT', meta['key'], 'trusted+connected+isolated; zero model turns', flush=True)
    manifest['preparation_complete'] = True
    helper.dump(BASE / 'manifest.json', manifest)
    print('PREPARED_NO_MODELS', BASE, flush=True)


def worker(key):
    manifest = json.loads((BASE / 'manifest.json').read_text())
    assert manifest.get('ROOTGO') is True and manifest.get('preparation_complete')
    assert helper.sha(ROOT / '.tmp/plugin-routing-evals/run.py') == manifest['helper_sha256']
    assert helper.sha(BASE / 'fixture_mcp.py') == manifest['fixture_server_sha256']
    assert helper.sha(BASE / 'cases-source.json') == manifest['case_source_sha256']
    meta = next(c for c in manifest['cases'] if c['key'] == key)
    directory, out = Path(meta['directory']), Path(meta['directory']) / 'actor'
    out.mkdir()  # Exclusive once-only guard, before any model request.
    assert helper.inventory(meta['plugin']) == manifest['source_plugin_sha256']
    for path, expected in [(directory / 'fixture.json', meta['fixture_sha256']),
                           (directory / 'actor-input.json', meta['actor_input_sha256']),
                           (Path(meta['home']) / 'config.toml', meta['config_sha256'])]:
        assert helper.sha(path) == expected
    actor = json.loads((directory / 'actor-input.json').read_text())
    rpc = helper.rpc_for(meta, out, allow=True)
    started, status = time.monotonic(), {'key': key, 'attempt': 1, 'valid': False, 'model': 'gpt-6.1-sol', 'effort': 'medium'}
    try:
        thread = rpc.call('thread/start', {'cwd': meta['cwd'], 'model': 'gpt-6.1-sol', 'permissions': 'routing_eval',
            'approvalPolicy': 'never', 'ephemeral': False, 'experimentalRawEvents': True})
        helper.dump(out / 'thread-start.json', thread)
        assert thread['model'] == 'gpt-6.1-sol' and thread.get('reasoningEffort') == 'medium'
        assert thread['activePermissionProfile']['id'] == 'routing_eval' and not thread.get('instructionSources')
        tid = thread['thread']['id']; status['thread_id'] = tid
        turn = rpc.call('turn/start', {'threadId': tid, 'cwd': meta['cwd'], 'model': 'gpt-6.1-sol', 'effort': 'medium',
            'permissions': 'routing_eval', 'approvalPolicy': 'never', 'input': [{'type': 'text', 'text': actor['text']}]})
        turn_id = turn['turn']['id']; status['turn_id'] = turn_id
        events, rpc.pending = rpc.pending, []
        deadline, completed = time.monotonic() + 180, None
        while time.monotonic() < deadline:
            completed = next((e for e in events if e.get('method') == 'turn/completed' and e.get('params', {}).get('turn', {}).get('id') == turn_id), None)
            if completed or rpc.user_requests:
                break
            try:
                events.append(rpc.next(timeout=min(30, max(1, deadline - time.monotonic()))))
            except queue.Empty:
                pass
        if rpc.user_requests and not completed:
            status['status'] = 'awaiting_user'
            helper.dump(out / 'user-requests.json', rpc.user_requests)
            rpc.call('turn/interrupt', {'threadId': tid, 'turnId': turn_id}, timeout=10)
        elif not completed:
            rpc.call('turn/interrupt', {'threadId': tid, 'turnId': turn_id}, timeout=10)
            raise TimeoutError('180-second deadline; no retry')
        else:
            status['status'] = completed['params']['turn']['status']
            status['valid'] = status['status'] == 'completed'
        helper.dump(out / 'turn-events.json', events)
        state = rpc.call('thread/read', {'threadId': tid, 'includeTurns': True})
        helper.dump(out / 'thread-read.json', state)
    except BaseException as error:
        status['error'] = str(error); status.setdefault('status', 'runtime_error')
    finally:
        status['wall_seconds'] = round(time.monotonic() - started, 3)
        helper.dump(out / 'status.json', status)
        helper.close_rpc(rpc)
    print('CASE', key, status['status'], status['wall_seconds'], flush=True)
    return 0 if status['valid'] else 1


def execute(rootgo):
    assert rootgo, 'Root review and explicit --rootgo required'
    manifest = json.loads((BASE / 'manifest.json').read_text())
    assert manifest.get('preparation_complete') and len(manifest['cases']) == 5
    assert all(c['preflight']['ready'] for c in manifest['cases'])
    assert not any((Path(c['directory']) / 'actor').exists() for c in manifest['cases']), 'Never repeat actors'
    manifest['ROOTGO'] = True
    helper.dump(BASE / 'manifest.json', manifest)
    pending, active, exits = iter(manifest['cases']), [], []
    while True:
        while len(active) < 2:
            try:
                meta = next(pending)
            except StopIteration:
                break
            process = subprocess.Popen([helper.PY, str(BASE / 'run.py'), 'worker', meta['key']])
            active.append((process, meta))
        if not active:
            break
        # Event-driven process completion; no fixed sleep or timer polling loop.
        done = next((entry for entry in active if entry[0].poll() is not None), None)
        if done is None:
            active[0][0].wait()
            continue
        process, meta = done
        active.remove(done)
        exits.append({'key': meta['key'], 'exit_code': process.returncode})
        helper.dump(BASE / 'worker-exits.json', exits)
    print('METADATA_SEARCH_RESULTS', BASE, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest='action', required=True)
    subs.add_parser('prepare')
    run_parser = subs.add_parser('run'); run_parser.add_argument('--rootgo', action='store_true')
    worker_parser = subs.add_parser('worker'); worker_parser.add_argument('key')
    args = parser.parse_args()
    if args.action == 'prepare': prepare()
    elif args.action == 'run': execute(args.rootgo)
    else: sys.exit(worker(args.key))
