#!/usr/bin/env python3
"""Model-free backend and collector contract checks; no fabricated hook payloads."""
import importlib.util,json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('collector',ROOT/'collect.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
def run():
 with tempfile.TemporaryDirectory() as d:
  d=Path(d);fixture={'cwd':'/workspace','alias':'check','files':{'a.ts':'export class Outer {\n  alpha() { return 7; }\n}\n','b.rb':'module Outer\n  class Args\n    def call\n      :args\n    end\n  end\n  def call\n    :outer\n  end\nend\n'},'raw_tool_responses':[{'tool':'find_symbol','arguments':{'symbol':'Budget'},'result':{'budget':{'truncated':True},'results':{'columns':['payload.symbolId','payload.content'],'rows':[['Budget','def call']]}}}]}
  (d/'fixture.json').write_text(json.dumps(fixture))
  p=subprocess.Popen([sys.executable,str(ROOT/'fixture_mcp.py'),'--fixture',str(d/'fixture.json'),'--audit',str(d/'audit.jsonl')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
  def request(name,args):
   p.stdin.write(json.dumps({'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':name,'arguments':args}})+'\n');p.stdin.flush();return json.loads(p.stdout.readline())
  try:
   mixed=request('find_symbol',{'symbols':['Outer','Outer#alpha']})['result']['structuredContent'];rows=list(c.unwrap_payloads(mixed));assert rows[0]['chunkType']=='containerHeader' and 'return 7' not in rows[0]['content'];assert 'return 7' in rows[1]['content'];assert mixed['kind']=='outline'
   ruby=request('find_symbol',{'symbol':'Outer#call'})['result']['structuredContent'];assert ':outer' in json.dumps(ruby) and ':args' not in json.dumps(ruby)
   assert 'error' in request('find_symbol',{'symbols':['x']*21})
   assert 'error' in request('find_symbol',{'symbols':['x'],'symbol':'x'})
   budget=request('find_symbol',{'symbol':'Budget'})['result']['structuredContent'];assert budget==fixture['raw_tool_responses'][0]['result']
   entry={'relativePath':'a.ts','content':'  alpha() { return 7; }'}
   calls=[{'type':'mcpToolCall','id':'mixed','result':{'structuredContent':mixed},'response_ordinal':2}]
   assert c.evidence_for(entry,{},calls);assert not c.evidence_for(entry,{},[{'type':'mcpToolCall','id':'header','result':{'payload':rows[0]}}])
   held={'actor_context':{'messages':[{'role':'tool','result':{'structuredContent':mixed}}]}};assert c.evidence_for(entry,held,[])[0]['wave']==0
   events=[{'method':'rawResponse/completed','params':{'responseId':'r1','usage':{'inputTokens':12,'cachedInputTokens':5,'outputTokens':1}}},{'method':'item/completed','params':{'item':{'id':'f','type':'agentMessage','phase':'final_answer','text':'actual final'}}}];parsed=c.parse(events);assert parsed['final_answer']=='actual final';assert parsed['responses']['r1']['cachedInputTokens']==5
  finally:p.terminate();p.wait()
 return {'model_turns':0,'checks':['TS container header excludes method body','Ruby nested ownership','mixed outline retains delivered body','max20 and mutual exclusions','raw budget fixture unchanged','header is not body coverage','held equivalent source covers','actual native final response parsed','cache usage preserved'],'pass':True,'limitations':['No native hook payload simulated.','No model actor executed.','Production budget semantics only via explicit raw fixtures.']}
if __name__=='__main__':
 result=run();out=ROOT/'protocol-check.json';assert not out.exists(),'preserve prior check; choose a new attempt path';out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
