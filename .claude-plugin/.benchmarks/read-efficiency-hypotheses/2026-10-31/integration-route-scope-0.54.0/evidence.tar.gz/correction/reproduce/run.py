#!/usr/bin/env python3
"""Focused native plugin wave evals. prepare has zero turns; run requires --rootgo."""
import argparse, importlib.util, json, shutil, subprocess, sys, time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
ORIGINAL=Path('/Users/artk0re/Dev/Tools/tea-rags-mcp')
SCRIPT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('metadata_native',ORIGINAL/'.tmp/metadata-evals/run.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
h=module.helper

# Matched raw-only/Postnote harness: writable controller state, denied to actors.
_original_native_env=h.native_env
_original_write_config=h.write_config
def controlled_native_env(home,shim):
    env=_original_native_env(home,shim)
    env['TEA_RAGS_HOOK_STATE_DIR']=str(Path(home).parent/'hook-state')
    return env
def controlled_write_config(meta,plugin,toolbin):
    _original_write_config(meta,plugin,toolbin)
    state=Path(meta['directory'])/'hook-state';state.mkdir(exist_ok=True)
    p=Path(meta['home'])/'config.toml'
    text=p.read_text();text=text.replace('set = { ', 'set = { TEA_RAGS_HOOK_STATE_DIR = '+json.dumps(str(state))+', ',1);p.write_text(text)
h.native_env=controlled_native_env
h.write_config=controlled_write_config


def attach(base):
    module.BASE=base;h.BASE=base


def preflight(meta):
    out=Path(meta['directory'])/'proof-no-turn'
    rpc=h.rpc_for(meta,out)
    try:
        t=rpc.call('thread/start',{'cwd':meta['cwd'],'model':'gpt-6.1-sol','permissions':'routing_eval','approvalPolicy':'never','ephemeral':True,'experimentalRawEvents':True})
        h.dump(out/'thread-start.json',t)
        assert t['model']=='gpt-6.1-sol' and t.get('reasoningEffort')=='medium'
        assert not t.get('instructionSources') and not t['thread'].get('turns')
        tid=t['thread']['id']
        hooks=rpc.call('hooks/list',{'threadId':tid,'cwds':[]});h.dump(out/'hooks.json',hooks)
        flat=[x for row in hooks['data'] for x in row['hooks']]
        assert len(flat)==14 and all(x['trustStatus']=='trusted' and x.get('pluginId')=='tea-rags@tea-rags' for x in flat)
        skills=rpc.call('skills/list',{'cwds':[meta['cwd']],'forceReload':True});h.dump(out/'skills.json',skills)
        enabled=[s for row in skills['data'] for s in row['skills'] if s.get('enabled')]
        assert len(enabled)==18 and all(s.get('pluginId')=='tea-rags@tea-rags' for s in enabled)
        deadline=time.monotonic()+90
        while True:
            status=rpc.call('mcpServerStatus/list',{'threadId':tid,'limit':100})
            if status['data'] and not any(s.get('runtimeStatus')=='starting' for s in status['data']):break
            assert time.monotonic()<deadline,'MCP startup deadline'
            rpc.next(timeout=max(1,deadline-time.monotonic()))
        h.dump(out/'mcp.json',status)
        assert len(status['data'])==1 and status['data'][0]['runtimeStatus']=='connected'
        protected=[str(Path(meta['directory'])/'hook-state'),str(SCRIPT),str(module.BASE/'grading-source.json'),str(module.BASE/'cases-source.json'),str(Path(meta['directory'])/'fixture.json'),str(Path(meta['directory'])/'actor-input.json'),str(Path(meta['home'])),str(ORIGINAL/'package.json'),'/Users/artk0re/.codex/auth.json']
        probe='paths='+repr(protected)+'\nfor p in paths:\n try:\n  with open(p,"rb") as f:f.read(1)\n  print("ALLOWED")\n except OSError as e:print("DENIED",e.errno)\n'
        result=rpc.call('command/exec',{'command':[h.PY,'-c',probe],'cwd':meta['cwd'],'permissionProfile':'routing_eval','timeoutMs':10000});h.dump(out/'denials.json',result)
        assert result['stdout'].count('DENIED 1')==len(protected),result
        proof={'ready':True,'model_turns':0,'trusted_hooks':len(flat),'enabled_skills':len(enabled),'mcp':'connected','denied_paths':len(protected),'proof_thread_ephemeral':True,'production_actor_fresh':True}
        h.dump(Path(meta['directory'])/'preflight.json',proof);return proof
    finally:h.close_rpc(rpc)


def prepare(source,base,cases,ids=None):
    base.mkdir(parents=True) # Exclusive; preserve every attempt.
    attach(base)
    shutil.copy2(SCRIPT/'fixture_mcp.py',base/'fixture_mcp.py')
    shutil.copy2(SCRIPT/'run.py',base/'run.py')
    shutil.copy2(SCRIPT/'collect.py',base/'collect.py')
    shipped=source/'harness/codex/tea-rags';snapshot=base/'marketplace/harness/codex/tea-rags'
    shutil.copytree(shipped,snapshot);inv=h.inventory(shipped);assert h.inventory(snapshot)==inv
    plugin_manifest=json.loads((snapshot/'.codex-plugin/plugin.json').read_text())
    assert (snapshot/plugin_manifest['mcpServers']).is_file(),'Shipped MCP declaration target missing; cannot evaluate a plugin without its native MCP injection'
    version=plugin_manifest['version']
    catalog=json.loads((source/'.agents/plugins/marketplace.json').read_text());catalog['plugins']=[p for p in catalog['plugins'] if p['name']=='tea-rags']
    target=base/'marketplace/.agents/plugins';target.mkdir(parents=True);h.dump(target/'marketplace.json',catalog)
    raw=json.loads(cases.read_text());rows=raw.get('evals',raw.get('cases'));assert rows and len(rows)==len({c['id'] for c in rows})
    available={c['id'] for c in rows}
    selected=ids or [c['id'] for c in rows]
    assert selected and len(selected)==len(set(selected)) and set(selected)<=available,'--ids must be an explicit unique subset of available case IDs'
    rows=[c for c in rows if c['id'] in selected]
    shutil.copy2(cases,base/'cases-source.json')
    grading=cases.parent/'grading.json';assert grading.is_file()
    shutil.copy2(grading,base/'grading-source.json')
    protocol=cases.parent/'protocol.md';assert protocol.is_file()
    shutil.copy2(protocol,base/'protocol.md')
    rules=json.loads(grading.read_text());assert set(selected)<=rules['cases'].keys()
    manifest={'ROOTGO':False,'preparation_complete':False,'model':'gpt-6.1-sol','effort':'medium','runs_per_case':1,'prepared_model_turns':0,'ledger_state_policy':'Fresh per-case controller hook-state via native process and shell environment; denied to actor; prior policy comparison had uncontrolled/unavailable state.','source_root':str(source),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'plugin_version':version,'plugin_file_count':len(inv),'service_cache':'Cannot be disabled; cachedInputTokens and initial response cache recorded; local caches/history not copied.','codex_version':subprocess.check_output([h.CODEX,'--version'],text=True).strip(),'source_plugin_sha256':inv,'helper_sha256':h.sha(ORIGINAL/'.tmp/plugin-routing-evals/run.py'),'metadata_helper_sha256':h.sha(ORIGINAL/'.tmp/metadata-evals/run.py'),'transport_sha256':h.sha(ORIGINAL/'.tmp/codex61_app_rpc.py'),'fixture_server_sha256':h.sha(base/'fixture_mcp.py'),'runner_sha256':h.sha(SCRIPT/'run.py'),'case_source_sha256':h.sha(base/'cases-source.json'),'grading_sha256':h.sha(base/'grading-source.json'),'protocol_sha256':h.sha(base/'protocol.md'),'collector_sha256':h.sha(base/'collect.py'),'selected_ids':selected,'per_case_source_sha256':{c['id']:__import__('hashlib').sha256(json.dumps(c,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest() for c in rows},'cases':[],'retry_policy':'One run per case and condition; immutable attempt paths. Failed and unrun remain open.','boundary':'Only request and retained raw facts; gold/controller/home/auth denied. Proof thread ephemeral; actor first model turn in fresh thread.'}
    h.dump(base/'manifest.json',manifest)
    for case in rows:
        directory=base/'cases'/case['id'];directory.mkdir(parents=True)
        meta=module.compile_case(case,directory)
        # Raw workingTree identity must refer only to this isolated indexed workspace.
        def identity(value):
            if isinstance(value,dict):
                if 'workingTree' in value:
                    wt=value['workingTree'];assert wt.get('project')==meta['alias'] and wt.get('tree')==meta['cwd'],wt
                for v in value.values():identity(v)
            elif isinstance(value,list):
                for v in value:identity(v)
        identity(h.replace_raw(case.get('actor_context',{}),meta['cwd'],meta['alias'],case.get('actor_context',{}).get('project','step-fixture')))
        actor_text=(directory/'actor-input.json').read_text()
        assert 'taxdome-worktree-navmaster' not in actor_text
        assert '__FIXTURE_ROOT__' not in actor_text
        identity(json.loads((directory/'fixture.json').read_text()))
        h.install_and_trust(meta,base/'marketplace',version,inv)
        meta['preflight']=preflight(meta);meta['config_sha256']=h.sha(Path(meta['home'])/'config.toml')
        manifest['cases'].append(meta);h.dump(base/'manifest.json',manifest)
        print('PREPARED_ZERO_TURNS',case['id'],flush=True)
    manifest['preparation_complete']=True;h.dump(base/'manifest.json',manifest)


def worker(base,key):
    attach(base);m=json.loads((base/'manifest.json').read_text())
    for path,field in [(ORIGINAL/'.tmp/plugin-routing-evals/run.py','helper_sha256'),(ORIGINAL/'.tmp/metadata-evals/run.py','metadata_helper_sha256'),(ORIGINAL/'.tmp/codex61_app_rpc.py','transport_sha256')]:assert h.sha(path)==m[field]
    original_rpc_for=h.rpc_for
    def fresh_rpc(*args,**kwargs):
        rpc=original_rpc_for(*args,**kwargs);original_call=rpc.call
        def call(method,params,*a,**kw):
            result=original_call(method,params,*a,**kw)
            if method=='thread/start':
                assert not result['thread'].get('turns'),'Actor has prior model turns'
            return result
        rpc.call=call;return rpc
    h.rpc_for=fresh_rpc
    # Existing worker already verifies frozen installed inventory, actor/config/fixture inputs,
    # enforces exclusive actor mkdir, raw events, fixed model/effort and one turn.
    return module.worker(key)


def run(base,rootgo):
    assert rootgo,'Explicit root authorization and --rootgo required'
    m=json.loads((base/'manifest.json').read_text());assert m['preparation_complete'] and not m['ROOTGO']
    assert h.sha(base/'run.py')==m['runner_sha256'],'Frozen runner changed'
    assert h.sha(base/'fixture_mcp.py')==m['fixture_server_sha256'],'Frozen fixture server changed'
    assert not any((Path(c['directory'])/'actor').exists() for c in m['cases'])
    assert h.sha(base/'grading-source.json')==m['grading_sha256'],'Frozen grading changed'
    assert h.sha(base/'cases-source.json')==m['case_source_sha256'],'Frozen cases changed'
    assert h.sha(base/'protocol.md')==m['protocol_sha256'],'Frozen protocol changed'
    m['ROOTGO']=True;m['rootgo_source']='Explicit parent GO for this frozen focused condition';h.dump(base/'manifest.json',m)
    def one(c):
        p=subprocess.run([h.PY,str(base/'run.py'),'worker','--base',str(base),'--key',c['key']],text=True,capture_output=True)
        print(p.stdout.strip(),flush=True)
        if p.stderr:print(p.stderr[-2000:],flush=True)
        return {'case':c['key'],'exit_code':p.returncode}
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=[f.result() for f in as_completed([pool.submit(one,c) for c in m['cases']])]
    h.dump(base/'worker-exits.json',results)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['prepare','run','worker']);p.add_argument('--base',required=True);p.add_argument('--source');p.add_argument('--cases');p.add_argument('--rootgo',action='store_true');p.add_argument('--key');p.add_argument('--ids',nargs='+');a=p.parse_args();base=Path(a.base).resolve()
    if a.action=='prepare':prepare(Path(a.source).resolve(),base,Path(a.cases).resolve(),a.ids)
    elif a.action=='run':run(base,a.rootgo)
    else:sys.exit(worker(base,a.key))
