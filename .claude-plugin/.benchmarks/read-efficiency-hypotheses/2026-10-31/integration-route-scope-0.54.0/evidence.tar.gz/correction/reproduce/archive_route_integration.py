#!/usr/bin/env python3
"""Preserve explicit route-scope correction rerun; do not rewrite failed integration."""
import hashlib,io,json,tarfile
from decimal import Decimal
from pathlib import Path
B=Path(__file__).resolve().parent;ROOT=B.parents[1];RUN=B/'integration-route-scope-0.54.0-attempt1';SOURCE=B/'sources/integration-route-scope';OLD=B/'integration-0.54.0-attempt1';OUT=ROOT/'.claude-plugin/.benchmarks/read-efficiency-hypotheses/2026-10-31/integration-route-scope-0.54.0';BENCH=OUT.parent
EXCLUDE={'home','workspace','marketplace','__pycache__','auth.json','config.toml','models_cache.json','.git'}
def load(p):return json.loads(p.read_text())
def dump(p,v):
 assert not p.exists(),p;p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def totals(rows):return {'input_tokens':sum(r['usage']['inputTokens'] for r in rows),'cached_input_tokens':sum(r['usage']['cachedInputTokens'] for r in rows),'fresh_input_tokens':sum(r['usage']['inputTokens']-r['usage']['cachedInputTokens'] for r in rows),'output_tokens':sum(r['usage']['outputTokens'] for r in rows),'native_model_steps_including_final':sum(r['model_responses'] for r in rows),'cost_proxy_usd':str(sum(Decimal(r['standard_API_equivalent_USD']) for r in rows))}
def main():
 preserved={str(p.relative_to(BENCH)):sha(p) for p in [BENCH/'evidence.tar.gz',BENCH/'integration-0.54.0/evidence.tar.gz']};m=load(RUN/'manifest.json');data=load(RUN/'collected.json');old=load(OLD/'collected.json');assert len(m['cases'])==len(data['cases'])==len(load(RUN/'worker-exits.json'))==3;oldm=load(OLD/'manifest.json');assert all(m[k]==oldm[k] for k in ['case_source_sha256','grading_sha256','runner_sha256','collector_sha256','fixture_server_sha256']);OUT.mkdir(exist_ok=True)
 reviews=[];proof=[];rule_deliveries=[];needle="A route's fully qualified controller requires its enclosing namespaces"
 for r in data['cases']:
  cid=r['case'];directory=RUN/'cases'/cid;states=[]
  for p in sorted((directory/'hook-state').rglob('*')):
   if p.is_file():
    try:value=json.loads(p.read_text())
    except ValueError:value=p.read_text()
    states.append({'archive_member':'correction/run/'+str(p.relative_to(RUN)),'data':value})
  for line in (directory/'actor/events.jsonl').read_text().splitlines():
   e=json.loads(line);run=e.get('params',{}).get('run',{})
   if e.get('method')=='hook/completed':
    for entry in run.get('entries',[]):
     text=entry.get('text','');pos=text.find(needle)
     if pos>=0:rule_deliveries.append({'case':cid,'event':run.get('eventName'),'status_message':run.get('statusMessage'),'actual_context_excerpt':text[pos:pos+270]})
  checks=dict(r['grade']['checks']);facts='Correct both locked versions and4 fixture/schema associations, with required delivered source. Nearby known-content control preserved.' if cid=='T-known-contract-content' else 'Correct current4 timeout pairs; native bodies/files/symbol records preserve header/outline/budget/stale distinctions. Nearby source-body control preserved.'
  if cid=='T-config-range-batch':
   header=[c for c in r['native_calls'] if c.get('type')=='commandExecution' and "'1,85p'" in c.get('command','')];block=[c for c in r['native_calls'] if c.get('type')=='commandExecution' and "'713,758p'" in c.get('command','')];checks['header_and_route_same_native_response']=bool(header and block and header[0]['response_ordinal']==block[0]['response_ordinal']==1);checks['actual_full_controller_qualified']='TaxPreparation::Webhooks::TaxAutomations::Instead::EventsController#create' in r['final_answer'];facts='Actual header1–85 and route713–758 delivered in response1; final includes outer tax_preparation scope and full controller. Failed integration only680–758 lacked outer evidence. No expected namespace inserted in candidate rule or fixture.'
  passed=all(checks.values());reviews.append({'case':cid,'factual_source_verdict':'PASS' if passed else 'OPEN_FAIL','checks':checks,'review':facts,'native_model_steps_including_final':r['model_responses'],'input_tokens':r['usage']['inputTokens'],'cached_input_tokens':r['usage']['cachedInputTokens'],'fresh_input_tokens':r['usage']['inputTokens']-r['usage']['cachedInputTokens'],'output_tokens':r['usage']['outputTokens'],'initial_cached_input_tokens':r['initial_cache'],'cost_proxy_usd':r['standard_API_equivalent_USD'],'events_archive_member':f'correction/run/cases/{cid}/actor/events.jsonl','final_archive_member':f'correction/run/cases/{cid}/actor/answer.txt','fixture_archive_member':f'correction/run/cases/{cid}/fixture.json','grading_archive_member':'correction/run/grading-source.json'});proof.append({'case':cid,'actual_final':r['final_answer'],'native_calls':r['native_calls'],'ledger_state':states})
 assert rule_deliveries,'Route guard must actually appear in native hook context'
 growth={}
 for name in ['scripts/codex-rules.txt','scripts/turn-routing.txt','skills/tea-rags-core/SKILL.md']:
  a=(SOURCE/'harness/codex/tea-rags'/name).read_text();b=(B/'sources/integration-main-72d/harness/codex/tea-rags'/name).read_text();growth[name]={'before_chars':len(b),'after_chars':len(a),'added_chars':len(a)-len(b)}
 report={'scope':'Explicit relevant route-scope source correction rerun after preserved0.54.0 OPEN_FAIL. Same3 cases once, no fixture/grading changes.','integration_head':m['source_head'],'source_dirty_tree':True,'source_provenance_archive_member':'correction/source/provenance.json','plugin_version':'0.54.0','model':'gpt-6.1-sol','effort':'medium','runs_per_case':1,'actor_count':3,'max_concurrent_actors':2,'native_zero_turn_preflight':{'trusted_hooks':14,'enabled_skills':18,'fixture_mcp':'connected','state':'fresh protected percase, actor denied'},'cases':reviews,'factual_source_passes':sum(r['factual_source_verdict']=='PASS' for r in reviews),'verdict':'3/3 scoped integration cases PASS' if all(r['factual_source_verdict']=='PASS' for r in reviews) else 'OPEN_FAIL','comparison':{'failed_integration':{'totals':totals(old['cases']),'factual_source_passes':2,'summary':'../integration-0.54.0/summary.json','archive':'../integration-0.54.0/evidence.tar.gz'},'route_scope_correction':{'totals':totals(data['cases']),'factual_source_passes':sum(r['factual_source_verdict']=='PASS' for r in reviews)},'source_rule_text_growth':growth,'interpretation':'Coverage corrected at same8 native responses (3/2/3). Header and route now same response; no speed or causal/statistical claim. Actual tokens/cost reflect source-rule growth and stochastic/cache differences.'},'actual_native_rule_delivery':rule_deliveries,'case_source_sha256':m['case_source_sha256'],'grading_sha256':m['grading_sha256'],'manifest_archive_member':'correction/run/manifest.json','native_state_proof_archive_member':'correction/run/native-state-proof.json','preserved_archive_sha256':preserved,'limitations':['n=1; same frozen synthetic extracted contexts, not original full session replay.','No expected namespace/TaxPreparation hint supplied by route rule; actual source evidence required.','Exactly3 new actors, explicitly relevant source correction rerun; prior failure retained without overwrite.','Service caching cannot be disabled; actual initial/cached/fresh tokens reported.','Fixed API-equivalent cost proxy is not subscription/current-price claim.','Previous12 results remain separate; this scoped correction does not close Q25 fixture naming diagnostic or claim all audit findings fixed.']}
 dump(RUN/'native-state-proof.json',proof);dump(RUN/'semantic-review.json',{'cases':reviews,'actual_native_rule_deliveries':rule_deliveries,'verdict':report['verdict']});dump(RUN/'integration-correction-report.json',report)
 files={}
 for p in sorted(RUN.rglob('*')):
  rel=p.relative_to(RUN)
  if p.is_file() and not p.is_symlink() and not any(part in EXCLUDE for part in rel.parts):files['correction/run/'+str(rel)]=p
 for p in sorted(SOURCE.rglob('*')):
  if p.is_file() and not p.is_symlink():files['correction/source/'+str(p.relative_to(SOURCE))]=p
 for name in ['run.py','fixture_mcp.py','collect.py','archive_route_integration.py','check_protocol.py','protocol-check-controlled-state.json']:files['correction/reproduce/'+name]=B/name
 original=Path('/Users/artk0re/Dev/Tools/tea-rags-mcp')
 for rel,label in [('.tmp/plugin-routing-evals/run.py','plugin-routing-run.py'),('.tmp/metadata-evals/run.py','metadata-run.py'),('.tmp/codex61_app_rpc.py','codex61_app_rpc.py')]:files['correction/dependencies/'+label]=original/rel
 inventory={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in files.items()};blob=json.dumps({'members':inventory,'scope':'Exactly3 explicit correction actors; no homes/auth/workspaces/cache/config.toml/symlinks'},indent=2).encode()+b'\n';archive=OUT/'evidence.tar.gz';assert not archive.exists()
 with tarfile.open(archive,'w:gz') as tar:
  for name,p in files.items():
   content=p.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(content);entry.mode=0o444;entry.mtime=0;tar.addfile(entry,io.BytesIO(content))
  entry=tarfile.TarInfo('member-sha256.json');entry.size=len(blob);entry.mode=0o444;entry.mtime=0;tar.addfile(entry,io.BytesIO(blob))
 with tarfile.open(archive) as tar:
  for entry in tar.getmembers():
   assert not any(part in EXCLUDE for part in Path(entry.name).parts)
   if entry.name in inventory:assert hashlib.sha256(tar.extractfile(entry).read()).hexdigest()==inventory[entry.name]['sha256']
 digest=sha(archive);dump(OUT/'evidence-inventory.json',{'archive':'evidence.tar.gz','archive_sha256':digest,'member_count':len(files)+1,'members':inventory});report['evidence']={'archive':'evidence.tar.gz','sha256':digest,'member_count':len(files)+1,'all_member_hashes_verified':True,'inventory':'evidence-inventory.json'};dump(OUT/'summary.json',report)
 for name,digest in preserved.items():assert sha(BENCH/name)==digest
 print(json.dumps({'summary':str(OUT/'summary.json'),'verdict':report['verdict'],'steps':report['comparison']['route_scope_correction']['totals']['native_model_steps_including_final'],'route_header_plus_block_same_wave':next(r['checks']['header_and_route_same_native_response'] for r in reviews if r['case']=='T-config-range-batch'),'source_growth':growth,'archive_sha256':report['evidence']['sha256'],'members':len(files)+1,'prior_archives_unchanged':True}))
if __name__=='__main__':main()
