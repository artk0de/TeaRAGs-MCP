#!/usr/bin/env python3
"""Offline native response, dependency-wave, coverage and source-identity accounting."""
import argparse, json, re, hashlib, shlex
from decimal import Decimal
from pathlib import Path
FIELDS=('inputTokens','cachedInputTokens','cacheWriteInputTokens','outputTokens','reasoningOutputTokens','totalTokens')

def load(path):return json.loads(Path(path).read_text())
def write(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def parse(events):
    responses={};wrappers={};pending=[];active=None;calls={};final={};total=None;mapping={};seen=[]
    for e in events:
        p=e.get('params',{});i=p.get('item',{});method=e.get('method')
        if method=='rawResponseItem/completed' and i.get('type') in ('custom_tool_call','function_call'):
            active=i.get('call_id',i['id']);wrappers[active]=dict(i);pending.append(active)
        if method=='rawResponse/completed':
            rid=p['responseId'];responses[rid]=p.get('usage',{})
            attr=p.get('usageMetadata',{}).get('metadata',{}).get('attribution',{}).get('items',{})
            own=[k for k,w in wrappers.items() if attr.get(w['id'],{}).get('output_tokens',0)>0]
            for k in own or pending:mapping[k]=rid
            pending=[]
        if method=='thread/tokenUsage/updated':total=p['tokenUsage']['total']
        if method in ('item/started','item/completed') and i.get('type') in ('mcpToolCall','commandExecution'):
            if i['id'] not in calls:
                calls[i['id']]={'wrapper':active,'event_index':len(seen)}
            calls[i['id']].update(i)
        if method=='item/completed' and i.get('type')=='agentMessage' and i.get('phase')=='final_answer':final[i['id']]=i.get('text','')
        seen.append(e)
    for c in calls.values():c['response_id']=mapping.get(c['wrapper']);c['response_ordinal']=list(responses).index(c['response_id'])+1 if c['response_id'] in responses else None
    return {'responses':responses,'wrappers':wrappers,'calls':list(calls.values()),'final_answer':'\n\n'.join(final.values()),'native_total':total}

def clean_symbol(symbol):
    return re.sub(r'\s+\((?:public|protected|private)\)$','',symbol)

def same_symbol(a,b):
    a,b=clean_symbol(a),clean_symbol(b)
    return a==b or re.sub(r'[.#]([^.#]*)$',r'#\1',a)==re.sub(r'[.#]([^.#]*)$',r'#\1',b)

def body_evidence(call,symbol,entry):
    if call.get('type')=='mcpToolCall' and call.get('tool')=='find_symbol':
        a=call.get('arguments',{});asked=a.get('symbols',[]) or [a.get('symbol','')]
        if a.get('metaOnly'):return False
        # Need delivered source, never mere requested IDs, outlines, or container headers.
        if not any(same_symbol(symbol,x) for x in asked) and entry['relativePath'] not in asked and a.get('relativePath')!=entry['relativePath']:return False
        raw=json.dumps(call.get('result',{}),ensure_ascii=False)
        content=entry.get('content',entry.get('body',''))
        # Escaped serialized body must actually be present in observed result.
        return bool(content) and json.dumps(content,ensure_ascii=False)[1:-1] in raw
    if call.get('type')=='commandExecution' and call.get('exitCode')==0:
        text=call.get('aggregatedOutput') or ''
        body=entry.get('content',entry.get('body',''))
        # Shell reads with line-number prefixes are supported; exact significant source lines required.
        lines=[x.strip() for x in body.splitlines() if x.strip() and not x.lstrip().startswith('#')]
        cmd=call.get('command','')
        return entry['relativePath'] in cmd and bool(lines) and all(x in text for x in lines)
    return False

def scoped_search(c,path,patterns,allow_scopes=()):
    if c.get('type')!='commandExecution' or c.get('exitCode') not in (0,1):return False
    cmd=c.get('command','')
    try:
        tokens=shlex.split(cmd)
        for _ in range(3):
            if '-c' not in tokens:break
            tokens=shlex.split(tokens[tokens.index('-c')+1])
    except (ValueError,IndexError):return False
    exact_path=any(t==path or t.endswith('/'+path) for t in tokens)
    scopes={scope.rstrip('/') for scope in allow_scopes}
    exact_scope=any(t.rstrip('/') in scopes for t in tokens)
    in_scope=exact_path or (exact_scope and path in (c.get('aggregatedOutput') or ''))
    return in_scope and any(t.rsplit('/',1)[-1] in ('rg','grep') for t in tokens) and all(p in cmd for p in patterns)

def unwrap_payloads(value):
    """Preserve row-local source, even when a mixed response has kind=outline."""
    if isinstance(value, str):
        try:yield from unwrap_payloads(json.loads(value))
        except (ValueError,TypeError):pass
    elif isinstance(value,list):
        for item in value:yield from unwrap_payloads(item)
    elif isinstance(value,dict):
        result=value.get('results',{})
        if isinstance(result,dict) and isinstance(result.get('columns'),list):
            keys=[key.removeprefix('payload.') for key in result['columns']]
            for row in result.get('rows',[]):
                if isinstance(row,list):yield dict(zip(keys,row))
        if ('content' in value or 'body' in value) and ('symbolId' in value or 'relativePath' in value):yield value
        for key,item in value.items():
            if key!='results' or not isinstance(item,dict):yield from unwrap_payloads(item)

def source_present(text,entry):
    body=entry.get('content',entry.get('body',''))
    lines=[x.strip() for x in body.splitlines() if x.strip()]
    return bool(lines) and all(line in text for line in lines)

def evidence_for(entry,case,calls):
    evidence=[]
    # Context contains only retained raw facts, never expectations or old answers.
    context=case.get('actor_context',{})
    messages=context.get('messages',[]) if isinstance(context,dict) else []
    for index,message in enumerate(messages):
        for payload in unwrap_payloads(message.get('result',message)):
            if source_present(payload.get('content',payload.get('body','')),entry):
                evidence.append({'kind':'held','context_index':index,'symbol':payload.get('symbolId'),'wave':0})
    for call in calls:
        if call.get('type')=='mcpToolCall':
            if call.get('arguments',{}).get('metaOnly'):continue
            for payload in unwrap_payloads(call.get('result',{})):
                if source_present(payload.get('content',payload.get('body','')),entry):
                    evidence.append({'kind':'delivered','call_id':call['id'],'wave':call.get('response_ordinal'),'symbol':payload.get('symbolId')});break
        elif call.get('type')=='commandExecution' and call.get('exitCode')==0:
            if entry.get('relativePath','') in call.get('command','') and source_present(call.get('aggregatedOutput',''),entry):
                evidence.append({'kind':'shell','call_id':call['id'],'wave':call.get('response_ordinal')})
    return evidence

def evaluate(meta,case,parsed,rules):
    rule=rules['cases'][case['id']];calls=parsed['calls'];answer=parsed['final_answer']
    bodies=case['fixture'].get('find_symbol_bodies',{})
    coverage={symbol:evidence_for(bodies[symbol],case,calls) for symbol in rule.get('required_source_units',[])}
    coverage.update({entry['label']:evidence_for(entry,case,calls) for entry in rule.get('required_source_snippets',[])})
    checks={'nonempty_actual_final_answer':bool(answer.strip()),
            'required_source_available':all(coverage.values()),
            'symbols_batch_max20':all(1<=len(c.get('arguments',{}).get('symbols',[]))<=20 for c in calls if c.get('tool')=='find_symbol' and 'symbols' in c.get('arguments',{}))}
    signals=[{'label':fact['label'],'pass':all(re.search(p,answer,re.I|re.S) is not None for p in fact.get('patterns',[]))} for fact in rule.get('facts',[]) if fact.get('patterns')]
    checks['answer_fact_signals']=all(fact['pass'] for fact in signals)
    waves=sorted({e['wave'] for entries in coverage.values() for e in entries if e['wave'] is not None})
    return {'checks':checks,'mechanical_pass':all(checks.values()),'evidence':{'source_coverage':coverage,'facts':signals,'relevant_evidence_response_ordinals':waves},
            'factual_review_criteria':rule.get('factual_review',[]),'hypothesis_review_criteria':rule.get('hypothesis_review',[]),
            'semantic_review':'REQUIRED: assess actual native final answer and all claims against delivered or equivalent held source. Optional helper reads, call counts and regex signals are not correctness gates. Efficiency evaluated separately.'}

def collect(base,rulespath,output=None):
    output=Path(output) if output else base/'collected.json'
    assert not output.exists(),'Never overwrite a prior collected verdict; use --output NEWFILE'
    manifest=load(base/'manifest.json');cases={c['id']:c for c in load(base/'cases-source.json')['evals']};rules=load(rulespath);rows=[]
    for meta in manifest['cases']:
        actor=Path(meta['directory'])/'actor';statuspath=actor/'status.json'
        if not statuspath.exists():rows.append({'case':meta['key'],'status':'UNRUN','verdict':'OPEN'});continue
        status=load(statuspath);events=[json.loads(l) for l in (actor/'events.jsonl').read_text().splitlines() if l.strip()];p=parse(events)
        usage={k:sum(r.get(k,0) for r in p['responses'].values()) for k in FIELDS}
        total=p['native_total'];balanced=bool(total) and all(usage[k]==total[k] for k in FIELDS)
        uncached=usage['inputTokens']-usage['cachedInputTokens'];cost=(Decimal(uncached)*2+Decimal(usage['cachedInputTokens'])*Decimal('0.1')+Decimal(usage['outputTokens'])*10)/1000000
        grade=evaluate(meta,cases[meta['id']],p,rules)
        row={'case':meta['key'],'status':status,'verdict':'REVIEW_REQUIRED' if status.get('valid') and grade['mechanical_pass'] and balanced else 'OPEN_FAIL','model_responses':len(p['responses']),'raw_response_ids':list(p['responses']),'usage':usage,'initial_cache':next(iter(p['responses'].values()),{}).get('cachedInputTokens',0),'cache_service':'Cannot disable; recorded, no copied local caches/history','native_usage_balanced':balanced,'standard_API_equivalent_USD':str(cost),'final_answer':p['final_answer'],'native_calls':p['calls'],'outer_calls':list(p['wrappers'].values()),'grade':grade}
        objective=rules.get('objective_response_depth_gate')
        if objective and meta['id'] in objective['limits']:
            corechecks={k:v for k,v in grade['checks'].items() if k in objective['factual_automated_checks']}
            corechecks.update(native_response_depth=len(p['responses'])<=objective['limits'][meta['id']],native_usage_balanced=balanced,actor_completed=bool(status.get('valid')))
            row['objective_gate']={'max_native_responses':objective['limits'][meta['id']],'observed_native_responses':len(p['responses']),'checks':corechecks,'mechanical_pass':all(corechecks.values()),'verdict':'SEMANTIC_REVIEW_REQUIRED' if all(corechecks.values()) else 'OPEN_FAIL','semantic_review':'REQUIRED and authoritative for factual correctness. Metadata is not body evidence; verify all actual final claims.','strict_diagnostic_verdict_preserved':row['verdict']}
        answerpath=actor/'answer.txt'
        if answerpath.exists():assert answerpath.read_text()==p['final_answer']+'\n'
        else:answerpath.write_text(p['final_answer']+'\n')
        rows.append(row)
    out={'condition':str(base),'model':'gpt-6.1-sol','effort':'medium','runs_per_case':1,'plugin_version':manifest['plugin_version'],'source_plugin_sha256':manifest['source_plugin_sha256'],'case_source_sha256':manifest['case_source_sha256'],'grading_sha256':hashlib.sha256(Path(rulespath).read_bytes()).hexdigest(),'cases':rows,'total_model_responses':sum(r.get('model_responses',0) for r in rows),'limitations':['Synthetic retained raw facts, not fresh history or original large-context replay.','n=1 per case/condition; no statistical speed claim.','One mandatory setup/schema response may be necessary and is not an avoidable wave.','Native response count is primary; nested call count does not measure model steps.','Regex facts require semantic human review; no automated correctness/completion claim.','Standard API-equivalent cost is not subscription billing.']}
    write(output,out)
    print(json.dumps({'base':str(base),'responses':out['total_model_responses'],'cases':[{'case':r['case'],'verdict':r['verdict'],'responses':r.get('model_responses'),'failed_checks':[k for k,v in r.get('grade',{}).get('checks',{}).items() if not v]} for r in rows]},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--grading',required=True);p.add_argument('--output');a=p.parse_args();collect(Path(a.base).resolve(),Path(a.grading).resolve(),a.output)
