#!/usr/bin/env python3
"""Freeze native baseline and separately fingerprint passive hook-input capture."""
import hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
baseline=BASE/'sources/baseline-cb9e37310';diagnostic=BASE/'sources/diagnostic-hook-stdin-cb9e37310'
subprocess.run(['git','diff','--exit-code','cb9e37310','--','harness/codex/tea-rags','.agents/plugins/marketplace.json'],cwd=ROOT,check=True,capture_output=True)
assert (ROOT/'harness/codex/tea-rags/.mcp.json').is_file()
assert not baseline.exists() and not diagnostic.exists()
for snapshot in [baseline]:
 shutil.copytree(ROOT/'harness/codex/tea-rags',snapshot/'harness/codex/tea-rags')
 (snapshot/'.agents/plugins').mkdir(parents=True)
 shutil.copy2(ROOT/'.agents/plugins/marketplace.json',snapshot/'.agents/plugins/marketplace.json')
shutil.copytree(baseline,diagnostic)
capture=BASE/'hook-stdin-capture';capture.mkdir()
plugin=diagnostic/'harness/codex/tea-rags';ledger=plugin/'scripts/reread-ledger.mjs';ledger.rename(ledger.with_name('reread-ledger.original.mjs'))
ledger.write_text('''import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const input=fs.readFileSync(0);
try { fs.appendFileSync('''+json.dumps(str(capture/'stdin.jsonl'))+''',JSON.stringify({timestamp:new Date().toISOString(),pid:process.pid,argv:process.argv.slice(2),stdin:input.toString('utf8')})+'\\n',{mode:0o600}); } catch {}
const child=spawnSync(process.execPath,[fileURLToPath(new URL('./reread-ledger.original.mjs',import.meta.url)),...process.argv.slice(2)],{input,env:process.env,cwd:process.cwd(),maxBuffer:16*1024*1024});
if(child.stdout)process.stdout.write(child.stdout);
if(child.stderr)process.stderr.write(child.stderr);
if(child.error)throw child.error;
process.exit(child.status??1);
''')
def inventory(p):return {str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(p.rglob('*')) if f.is_file()}
b=inventory(baseline/'harness/codex/tea-rags');d=inventory(plugin)
report={'baseline_name':baseline.name,'baseline_source':'cb9e37310','tracked_generated_matches_baseline':True,'ignored_mcp_declaration':'baseline generated native .mcp.json included','baseline_file_count':len(b),'baseline_fingerprint':b,'diagnostic_name':diagnostic.name,'diagnostic_fingerprint':d,'diagnostic_changes':sorted(k for k in b.keys()|d.keys() if b.get(k)!=d.get(k)),'diagnostic_purpose':'Passive actual native hook stdin capture only; not efficacy evidence','capture_path':str(capture/'stdin.jsonl'),'model':'gpt-6.1-sol','effort':'medium','runs':1,'case':'T-known-metrics-content','actor_authorization':'Parent GO for this one diagnostic actor only','limitations':['Instrumentation changes ledger entrypoint only; stdout/stderr/exit delegated unchanged.','Existing shipped matcher determines captured Pre/Post events; no synthetic hook shape or matcher added.','Service caching cannot be disabled.']}
(BASE/'capture-source-freeze.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['baseline_name','baseline_file_count','diagnostic_name','diagnostic_changes','case']}))
