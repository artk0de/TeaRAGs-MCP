import hashlib, json, shutil, subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent / 'sources'
generator = (root / 'scripts/gen-harness-codex.ts').read_text()
procedural = '''Before choosing another read:
1. Name the unsupported fact. Use delivered source to close it first: a full file includes its methods even when child IDs are absent. Only actual body ranges count; headers, outlines, failed/blocked reads, omitted budget ranges and stale pre-edit code leave gaps.
2. Decide whether the missing item is a locator or content. Unknown filename/exhaustive inventory → scoped filenames. Known config/spec/migration file needing values/assertions → bounded content immediately. Do not rediscover that known file with filename-only grep. An absence claim requires the complete relevant scope, never a head-limited sample.
3. Select all currently ready entrypoint/helper bodies and config ranges needed for those facts, then dispatch them together with independent reference checks. Keep nextCall targets in this wave or an unavoidable dependent wave. Tool kind does not establish dependency. Leave outlined or budget-deferred bodies unread until fetched; do not request bodies already inside held file ranges.
4. Require a new fact before another wave: newly discovered locator, ambiguity, prerequisite, output budget or changed source. Stop when the request is supported; do not fetch closing delimiters, EOF, import-only frontend files or extra helper bodies merely to confirm it.
5. Required skills use listed or hook-resolved paths. Never invent a cache version under CODEX_HOME. A failed skill read yields no source: use available workflow and held facts, and report a genuinely unavailable required skill rather than trying guessed installations.'''
start = generator.index('const CODEX_EVIDENCE_READING = `')
end = generator.index('`;', start) + 2
variants = {
    'compact-policy': generator,
    'procedural-policy': generator[:start] + 'const CODEX_EVIDENCE_READING = `' + procedural + '`;' + generator[end:],
}
baseline_ledger = subprocess.check_output(['git','show','cb9e37310:plugins/tea-rags/scripts/reread-ledger.mjs'], cwd=root)
for name, source in variants.items():
    target = base / name
    target.mkdir()  # exclusive: preserve previous attempts
    shutil.copytree(root/'scripts/harness', target/'scripts/harness')
    shutil.copytree(root/'plugins', target/'plugins')
    for filename in ['package.json', '.prettierrc']:
        shutil.copy2(root/filename, target/filename)
    (target/'scripts/gen-harness-codex.ts').write_text(source)
    (target/'plugins/tea-rags/scripts/reread-ledger.mjs').write_bytes(baseline_ledger)
    (target/'provenance.json').write_text(json.dumps({
        'variant': name, 'source_head': 'cb9e37310936c5156bb51a2e0b15e1ace5843be9',
        'generator_sha256': hashlib.sha256(source.encode()).hexdigest(),
        'ledger_sha256': hashlib.sha256(baseline_ledger).hexdigest(),
        'ledger_condition': 'exact baseline in all policy variants; no delivery-note or cmd alias changes',
        'generation': 'npx tsx scripts/gen-harness-codex.ts within this isolated source snapshot',
        'model': 'gpt-6.1-sol', 'effort': 'medium', 'runs_per_case': 1,
    }, indent=2)+'\n')
    print(name, str(target))
