import hashlib, json, shutil, subprocess
from pathlib import Path
root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent / 'sources'
variants = {
    'raw-delivery-fix': root/'.tmp/readfix-v4-ledger/candidate-raw-only/plugins/tea-rags/scripts/reread-ledger.mjs',
    'post-delivery-note': root/'.tmp/readfix-v4-ledger/candidate-postnote/reread-ledger.mjs',
}
for name, ledger in variants.items():
    target = base/name
    target.mkdir()
    shutil.copytree(root/'scripts/harness', target/'scripts/harness')
    shutil.copytree(root/'plugins', target/'plugins')
    shutil.copy2(root/'scripts/gen-harness-codex.ts', target/'scripts/gen-harness-codex.ts')
    for filename in ['package.json','.prettierrc']:
        shutil.copy2(root/filename,target/filename)
    shutil.copy2(ledger,target/'plugins/tea-rags/scripts/reread-ledger.mjs')
    (target/'provenance.json').write_text(json.dumps({
        'variant':name,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'generator_sha256':hashlib.sha256((target/'scripts/gen-harness-codex.ts').read_bytes()).hexdigest(),
        'ledger_sha256':hashlib.sha256(ledger.read_bytes()).hexdigest(),
        'policy':'baseline v3 plus conditional known-file content routing; rejected extra prose absent',
        'generation':'npx tsx scripts/gen-harness-codex.ts within isolated source snapshot',
        'model':'gpt-6.1-sol','effort':'medium','runs_per_case':1,
    },indent=2)+'\n')
    print(name,str(target))
