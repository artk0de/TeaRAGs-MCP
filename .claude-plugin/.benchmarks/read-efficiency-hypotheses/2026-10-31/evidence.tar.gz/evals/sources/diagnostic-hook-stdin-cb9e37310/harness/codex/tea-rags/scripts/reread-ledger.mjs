import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const input=fs.readFileSync(0);
try { fs.appendFileSync("/Users/artk0re/Dev/Tools/tea-rags-mcp/.claude/worktrees/codex-read-efficiency-v4/.tmp/readfix-v4-evals/hook-stdin-capture/stdin.jsonl",JSON.stringify({timestamp:new Date().toISOString(),pid:process.pid,argv:process.argv.slice(2),stdin:input.toString('utf8')})+'\n',{mode:0o600}); } catch {}
const child=spawnSync(process.execPath,[fileURLToPath(new URL('./reread-ledger.original.mjs',import.meta.url)),...process.argv.slice(2)],{input,env:process.env,cwd:process.cwd(),maxBuffer:16*1024*1024});
if(child.stdout)process.stdout.write(child.stdout);
if(child.stderr)process.stderr.write(child.stderr);
if(child.error)throw child.error;
process.exit(child.status??1);
