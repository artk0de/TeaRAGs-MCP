#!/usr/bin/env python3
"""Archive explicit controller evidence after actors close; never include homes/auth/caches."""
import argparse,hashlib,json,tarfile,io
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
EXCLUDE={'home','workspace','marketplace','__pycache__','.git','auth.json','config.toml','models_cache.json'}
def select():
 selected={}
 for p in sorted(BASE.rglob('*')):
  rel=p.relative_to(BASE)
  if not p.is_file() or p.is_symlink() or any(part in EXCLUDE for part in rel.parts):continue
  if rel.parts[0]=='sources':
   inner=Path(*rel.parts[2:])
   if inner.parts and inner.parts[0]=='plugins':continue # duplicate source tree; generated native package retained
   if inner.parts and inner.parts[0]=='harness' and not str(inner).startswith('harness/codex/tea-rags/'):continue
  if p.name.endswith(('.tar.gz','.zip')):continue
  selected['evals/'+str(rel)]=p
 # Frozen reusable cases/provenance/grading/protocol, separate from actor inputs.
 benchmark=ROOT/'.claude-plugin/.benchmarks/read-efficiency-hypotheses/2026-10-31'
 for p in sorted(benchmark.iterdir()):
  if p.is_file() and p.suffix in {'.json','.md'} and 'inventory' not in p.name and 'summary' not in p.name:selected['benchmark/'+p.name]=p
 original=Path('/Users/artk0re/Dev/Tools/tea-rags-mcp')
 for relative,label in [('.tmp/plugin-routing-evals/run.py','plugin-routing-run.py'),('.tmp/metadata-evals/run.py','metadata-run.py'),('.tmp/codex61_app_rpc.py','codex61_app_rpc.py')]:selected['dependencies/'+label]=original/relative
 ledger=ROOT/'.tmp/readfix-v4-ledger'
 if ledger.exists():
  for p in sorted(ledger.rglob('*')):
   rel=p.relative_to(ledger)
   if p.is_file() and not p.is_symlink() and not any(part in EXCLUDE|{'plugins'} for part in rel.parts) and p.suffix in {'.json','.patch','.mjs','.log','.txt'}:selected['ledger-proof/'+str(rel)]=p
 return selected

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);parser.add_argument('--inventory',required=True);args=parser.parse_args();out=Path(args.output);inv=Path(args.inventory);assert not out.exists() and not inv.exists(),'Never overwrite evidence'
 for manifest in BASE.glob('*/manifest.json'):
  m=json.loads(manifest.read_text())
  if m.get('ROOTGO'):
   exits=manifest.parent/'worker-exits.json';assert exits.exists(),f'Actors may still be active: {manifest}'
   assert len(json.loads(exits.read_text()))==len(m['cases'])
   for case in m['cases']:assert (Path(case['directory'])/'actor/status.json').is_file()
 selected=select();inventory={name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for name,p in selected.items()}
 limitations={'boundary':'No homes/auth/config.toml/workspaces/caches/whole redundant plugins source trees/symlinks. Per-condition inventory manifests retain complete installed native package fingerprints; source snapshots retain native87 files, generator and provenance.','required_limits':['n=1; synthetic extracted local Q01/Q15 questions not original full session replay; source completeness/provenance retained.','Old policy comparison ledger-state inference corrected by native-plugin-data-correction.json: plugin data turn files existed; shell spans absent because rawstdout bug, metrics virtual worker file absent.','Metrics virtual method can answer source facts but native ledger stat guard cannot record a nonexistent physical worker path.','Service caching cannot be disabled; procedural initial cache8832 corrected and raw/note boundary initial cache8832 reported.','Postnote route OPEN_FAIL preserved; no retries or oracle changes.','Initial model-free parser syntax failure and superseded zero-turn prep retained.','Raw-only final12 combine first3 and remaining9 exclusive actor attempts; no repeated finalcondition cases.','API-equivalent cost is fixed accounting proxy, not subscription/current-price claim.']}
 inventory_blob=json.dumps({'members':inventory,'limitations':limitations},ensure_ascii=False,indent=2).encode()+b'\n'
 out.parent.mkdir(parents=True,exist_ok=True)
 with tarfile.open(out,'w:gz') as archive:
  for name,p in selected.items():
   data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o444;info.mtime=0;archive.addfile(info,io.BytesIO(data))
  info=tarfile.TarInfo('member-sha256.json');info.size=len(inventory_blob);info.mode=0o444;info.mtime=0;archive.addfile(info,io.BytesIO(inventory_blob))
 digest=hashlib.sha256(out.read_bytes()).hexdigest();inv.write_text(json.dumps({'archive':str(out),'archive_sha256':digest,'member_count':len(inventory)+1,'members':inventory,'limitations':limitations},ensure_ascii=False,indent=2)+'\n')
 with tarfile.open(out) as archive:
  names=archive.getnames();assert len(names)==len(set(names))==len(inventory)+1
  assert not any(any(part in EXCLUDE for part in Path(name).parts) for name in names)
  for member in archive.getmembers():
   data=archive.extractfile(member).read()
   if member.name in inventory:assert hashlib.sha256(data).hexdigest()==inventory[member.name]['sha256']
 print(json.dumps({'archive':str(out),'sha256':digest,'members':len(inventory)+1,'bytes':out.stat().st_size,'all_member_hashes_verified':True}))
if __name__=='__main__':main()
