#!/usr/bin/env python3
"""Package only the authorized0.54.0 integration gate; prior evidence stays immutable."""
import hashlib,io,json,tarfile
from decimal import Decimal
from pathlib import Path
B=Path(__file__).resolve().parent;ROOT=B.parents[1];RUN=B/'integration-0.54.0-attempt1';SOURCE=B/'sources/integration-main-72d';OUT=ROOT/'.claude-plugin/.benchmarks/read-efficiency-hypotheses/2026-10-31/integration-0.54.0'
EXCLUDE={'home','workspace','marketplace','__pycache__','auth.json','config.toml','models_cache.json','.git'}
def load(p):return json.loads(p.read_text())
def dump(p,v):
 assert not p.exists(),p;p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def metrics(r):
 u=r['usage'];return {'input_tokens':u['inputTokens'],'cached_input_tokens':u['cachedInputTokens'],'fresh_input_tokens':u['inputTokens']-u['cachedInputTokens'],'output_tokens':u['outputTokens'],'native_model_steps_including_final':r['model_responses'],'initial_cached_input_tokens':r['initial_cache'],'cost_proxy_usd':r['standard_API_equivalent_USD']}
def main():
 old=ROOT/'.claude-plugin/.benchmarks/read-efficiency-hypotheses/2026-10-31/evidence.tar.gz';oldhash=sha(old);m=load(RUN/'manifest.json');data=load(RUN/'collected.json');assert len(m['cases'])==len(data['cases'])==len(load(RUN/'worker-exits.json'))==3;assert all((Path(c['directory'])/'actor/status.json').is_file() for c in m['cases']);assert m['plugin_version']=='0.54.0';OUT.mkdir(exist_ok=True)
 proof=[];cases=[]
 for r in data['cases']:
  cid=r['case'];case=RUN/'cases'/cid;state=[];notes=[]
  for p in sorted((case/'hook-state').rglob('*')):
   if p.is_file():
    try:value=json.loads(p.read_text())
    except ValueError:value=p.read_text()
    state.append({'archive_member':'integration/run/'+str(p.relative_to(RUN)),'data':value})
  for line in (case/'actor/events.jsonl').read_text().splitlines():
   e=json.loads(line);run=e.get('params',{}).get('run',{})
   if e.get('method')=='hook/completed' and run.get('eventName') in ['postToolUse','preToolUse'] and run.get('entries'):notes.append({'event':run.get('eventName'),'status_message':run.get('statusMessage'),'entries':run['entries']})
  failed=cid=='T-config-range-batch';facts=('Only680–758 delivered. Required outer tax_preparation scope at file start omitted; actual final names controller without TaxPreparation prefix. Frozen required_source_available check fails. Keep OPEN_FAIL; no retry or grading correction.' if failed else 'Actual final gives both resolved gem versions and4 fixture/schema mappings correctly from delivered config/spec ranges.' if cid=='T-known-contract-content' else 'Actual final gives current Request60/30, Retry90/45, Upload120/40, Changed180/50; all4 complete native bodies acquired despite held header/outline/budget/stale limits. File+symbol ledger records present.')
  proof.append({'case':cid,'ledger_state':state,'native_hook_context':notes,'native_calls':r['native_calls'],'actual_final':r['final_answer']});cases.append({'case':cid,**metrics(r),'factual_source_verdict':'OPEN_FAIL' if failed else 'PASS','review':facts,'required_source_available':r['grade']['checks']['required_source_available'],'actual_native_source_state_verified':True,'events_archive_member':f'integration/run/cases/{cid}/actor/events.jsonl','final_archive_member':f'integration/run/cases/{cid}/actor/answer.txt','fixture_archive_member':f'integration/run/cases/{cid}/fixture.json','grading_archive_member':'integration/run/grading-source.json'})
 dump(RUN/'native-state-proof.json',proof);dump(RUN/'semantic-review.json',{'cases':cases,'verdict':'OPEN:2PASS/1OPEN_FAIL','method':'Actual native final answers reviewed against delivered/held source, plus observed native ledger records; optional helper counts not correctness gate.','limitations':['n=1; no causal attribution to6-line fix or incoming unrelated changes.','Relevant integration correction after main72d035ba3; previous0.53.10 reports retained.','No original full-context replay, no automatic retries.']})
 report={'integration_head':m['source_head'],'integration_base':'72d035ba3','plugin_version':'0.54.0','source_snapshot':'integration-main-72d','model':'gpt-6.1-sol','effort':'medium','runs_per_case':1,'actor_count':3,'max_concurrent_actors':2,'native_preflight':{'model_turns':0,'trusted_hooks':14,'enabled_skills':18,'fixture_mcp':'connected','controller_state':'fresh protected percase; actor denied'},'cases':cases,'totals':{'input_tokens':sum(r['usage']['inputTokens'] for r in data['cases']),'cached_input_tokens':sum(r['usage']['cachedInputTokens'] for r in data['cases']),'fresh_input_tokens':sum(r['usage']['inputTokens']-r['usage']['cachedInputTokens'] for r in data['cases']),'output_tokens':sum(r['usage']['outputTokens'] for r in data['cases']),'native_model_steps_including_final':sum(r['model_responses'] for r in data['cases']),'cost_proxy_usd':str(sum(Decimal(r['standard_API_equivalent_USD']) for r in data['cases']))},'verdict':'OPEN:2PASS/1OPEN_FAIL; integration behavioral gate is not green','technical_native_delivery':'Shell stdout ranges persist for Gemfile/lock/spec and route680–758; boundary native MCP files+symbols persist for all4 current bodies.','case_source_sha256':m['case_source_sha256'],'grading_sha256':m['grading_sha256'],'source_fingerprint_archive_member':'integration/run/manifest.json','source_provenance_archive_member':'integration/source/provenance.json','native_state_proof_archive_member':'integration/run/native-state-proof.json','retry_policy':'No retries, new cases, grading changes or prior actor reruns.','prior_evidence_archive_unchanged_sha256':oldhash,'limitations':['n=1; not a causal failure attribution or statistical performance claim.','Same frozen raw cases/grading; expected answers remain isolated from actor inputs.','Cache service cannot be disabled; actual cached/fresh/initial token values shown.','Cost uses fixed $2fresh/$0.10cached/$10output per million accounting proxy, not billing/current-price assertion.','Source package includes incoming unrelated0.54.0 changes; commit/source/package fingerprints preserved.','Original28 actor reports and evidence archive untouched.']}
 dump(RUN/'integration-report.json',report)
 files={}
 for p in sorted(RUN.rglob('*')):
  rel=p.relative_to(RUN)
  if p.is_file() and not p.is_symlink() and not any(part in EXCLUDE for part in rel.parts):files['integration/run/'+str(rel)]=p
 for p in sorted(SOURCE.rglob('*')):
  if p.is_file() and not p.is_symlink():files['integration/source/'+str(p.relative_to(SOURCE))]=p
 for name in ['run.py','fixture_mcp.py','collect.py','archive_integration.py','check_protocol.py','protocol-check-controlled-state.json']:
  files['integration/reproduce/'+name]=B/name
 original=Path('/Users/artk0re/Dev/Tools/tea-rags-mcp')
 for rel,label in [('.tmp/plugin-routing-evals/run.py','plugin-routing-run.py'),('.tmp/metadata-evals/run.py','metadata-run.py'),('.tmp/codex61_app_rpc.py','codex61_app_rpc.py')]:files['integration/dependencies/'+label]=original/rel
 inventory={name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in files.items()};blob=json.dumps({'members':inventory,'scope':'Exactly3 integration actors; no homes/auth/workspaces/caches/config.toml/symlinks'},indent=2).encode()+b'\n';archive=OUT/'evidence.tar.gz';assert not archive.exists()
 with tarfile.open(archive,'w:gz') as tar:
  for name,p in files.items():
   content=p.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(content);entry.mode=0o444;entry.mtime=0;tar.addfile(entry,io.BytesIO(content))
  entry=tarfile.TarInfo('member-sha256.json');entry.size=len(blob);entry.mode=0o444;entry.mtime=0;tar.addfile(entry,io.BytesIO(blob))
 with tarfile.open(archive) as tar:
  for entry in tar.getmembers():
   assert not any(part in EXCLUDE for part in Path(entry.name).parts)
   if entry.name in inventory:assert hashlib.sha256(tar.extractfile(entry).read()).hexdigest()==inventory[entry.name]['sha256']
 digest=sha(archive);dump(OUT/'evidence-inventory.json',{'archive':'evidence.tar.gz','archive_sha256':digest,'member_count':len(files)+1,'members':inventory});report['evidence']={'archive':'evidence.tar.gz','sha256':digest,'member_count':len(files)+1,'inventory':'evidence-inventory.json','all_member_hashes_verified':True};dump(OUT/'summary.json',report);assert sha(old)==oldhash;print(json.dumps({'summary':str(OUT/'summary.json'),'verdict':report['verdict'],'steps':report['totals']['native_model_steps_including_final'],'archive_sha256':digest,'members':len(files)+1,'original_archive_unchanged':True}))
if __name__=='__main__':main()
