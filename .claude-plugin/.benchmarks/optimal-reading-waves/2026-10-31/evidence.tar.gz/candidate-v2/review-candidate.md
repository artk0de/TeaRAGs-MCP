# Candidate-v2 readiness review

**Все5 ответов фактически обоснованы, но literal eval gate не пройден.** W02 по-прежнему разносит known-ready IDs между responses2/3; W21 не получает body token_connection из explicit required11. Metadata не засчитана за body. Raw OPEN_FAIL сохранены.

## W02: лишней целой волны больше нет

Matched control5→candidate4. Вcandidate response3 содержит не только оставшиеся известные bodies, но и spec source, чей путь впервые найден вresponse2. Даже после переноса всех известных bodies вresponse2 остаётся setup→body+rg→spec→final=4. Следовательно остаточный ready-split нарушает буквальный критерий, но его устранение само по себе не экономит modelresponse.

## W21: body отсутствует, факты покрыты другими bodies

Вactualouter output нет def token_connection. Его unseen timeout/encoding/middleware internals не принимаются как доказанные. Финальные claims metrics/operation labels/grant POST/revocation прямо доказаны request/measured_token_call/token_response/exchange_code!/exchange_operation/refresh_tokens!/revoke_tokens!. Для этих claims token_connectionbody не нужен. Однако explicit11-bodycontract заранее включил его — mechanical FAIL остаётся; задним числом PASS не ставится.

## Budget and usage

Native truncated отсутствует; actual outer outputs не содержат truncation markers. W02 source9169+3102chars; W21source14781chars. Per-call20cap не объясняет пропуск token_connection. W02total tokens130272→107643; W21 97047→71322. Это один sample с различным cache input, не обещание общей экономии.

Readiness: нельзя утверждать прохождение всех literal behavioral criteria. Семантическая достаточность и отсутствие дальнейшей отдельной лишней волны должны быть представлены отдельно от оставшихся mechanical failures. Новые модели не запускались.
