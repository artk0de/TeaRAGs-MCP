# Candidate-v1 semantic and strict pending-read review

**Все8 финальных ответов фактически корректны, но цель объединения всех известных нужных чтений ещё не достигнута.** W02 и W21 продолжают выделять уже адресуемые части текущего вопроса в следующую волну.

Наблюдение32vs36responses: P-single−2, batch-limit−1, ambiguous−1; остальные без изменения. Это один sample; W02 частично искажён неполными handler fixtures.

## W02-independent-body-and-refs

PASS_FOR_FIXTURE; FAIL_KNOWN_RELEVANT_BODY_SUBSETS_SERIALIZED; 7→7responses.

- Response26-ID body batch plus independent spec filename search; response3 separately requests8additional Router/BaseClient IDs already present retained context. Total14 unique targets fit20 limit; returned source chars across both waves7642, no truncation or reported output-budget constraint.
- Spec source filename is newly discovered in response2 and its response3 read is a legitimate dependent step. This does not make the independent Router body group dependent.
- Response3 requests Router token/create_entity/start_doc_upload, all real IDs whose exact bodies are in saved actual Q02event175output2. Backend omissions then cause UnknownSymbol, failed pagination guide, dot-alias retries and short-name retries in responses4–6.
- Candidate7vscontrol7 does not show W02 improvement. Strict pending-read violation is distinct from fixture-induced3recovery waves.
- Mechanical scoped_literal_search=false is spec versus spec/ spelling false negative; source is discovered and read.
- No wrong final fact found; response includes optional handle example from entity and middleware selection, supported by served source.

## W21-known-method-batch

PASS_FOR_FIXTURE; FAIL_KNOWN_RELEVANT_BODY_SUBSETS_SERIALIZED; 4→4responses.

- Response2 selects15 IDs; response3 separately selects exchange_code!,refresh_tokens!,token_connection. All3 exact IDs were initially in retained outlines.18unique targets fit20; returned body chars13329+2157=15486 with no truncation.
- First8mandatory methods mechanically pass, masking3later known-ID reads. Those3 provide OAuth measurement operations/endpoints used in final answer and belong to currently requested OAuth subpart.
- Candidate4vscontrol4 shows no W21 reduction.
- Mechanical revocation fact failure is literal client_credentials versus accurate client credentials paraphrase; connect/reconnect,connected_at,refresh_token,token_revoke all present.
- Additional first-wave rate_limit_group_of/retry_after requests are backend misses but no recovery wave follows them; do not attribute the separately known3-ID group to these misses.

## W35-body-and-absence

PASS_FOR_FIXTURE; PASS_OR_NO_VIOLATION_OBSERVED; 3→3responses.

- Required body group and uid|uuid absence check share response2; all separate-name APIs including find_by_account_user are correctly stated.
- Absence applies only to compact assembled fixture file; source coordinate lines are original fragment coordinates.

## C-dependent-new-locators

PASS_FOR_FIXTURE; PASS_OR_NO_VIOLATION_OBSERVED; 4→4responses.

- Metadata semantic_search response2 precedes body response3; no speculative ID. String429 false is valid inference from integer-array include? implementation.

## C-partial-not-body

PASS_FOR_FIXTURE; PASS_OR_NO_VIOLATION_OBSERVED; 3→3responses.

- Reads actual timeout body before answering60/30; no citation was explicitly requested.

## P-single-exact-suggestion

PASS_FOR_FIXTURE; PASS_OR_NO_VIOLATION_OBSERVED; 5→3responses.

- Direct exact-basename suggested relativePath in response2 returns complete file; no directory detour.3vs5responses is observed narrow policy improvement.
- Final path missing, so raw source-path grading fails; inheritance and operation fact are supported.

## C-ambiguous-suggestions

PASS_FOR_FIXTURE; PASS_OR_NO_VIOLATION_OBSERVED; 6→5responses.

- Shared directory first, both classes next, both newly discovered operation IDs together after that. Ambiguity preserved.
- 5vs6responses reflects omitted failed pagination guide/setup wave in this sample, not demonstrated necessary policy effect.

## C-batch-limit

PASS_FOR_FIXTURE; PASS_OR_NO_VIOLATION_OBSERVED; 4→3responses.

- 20+1symbol calls dispatched together response2; all21values and paths correct.3vs4responses removes observed initial21symbol backend rejection from control.

## Minimal next lever

Replace rather than append the broad ALL wording with a silent pre-call mapping across every requested subpart: held evidence versus exact missing locators. A body mention of an ID already in retained outlines is not a new dependency. Dispatch the union of ready needed locators before first source call.

Before the first source call, map every requested subpart to held evidence or missing exact locators; dispatch all ready gaps together. A body mentioning an ID already in retained outlines does not create a new dependency.

Это вывод по наблюдаемому коду вызовов и наличию IDs в retained context. Private reasoning не использовалось; причина в выборе первой неполной группы — интерпретация trace, не доказанный внутренний мотив. Все raw результаты сохранены, overall gate OPEN.
