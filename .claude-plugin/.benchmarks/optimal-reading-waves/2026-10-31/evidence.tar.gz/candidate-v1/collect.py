#!/usr/bin/env python3
"""Offline native response, dependency-wave, coverage and source-identity accounting."""
import argparse, json, re, hashlib
from decimal import Decimal
from pathlib import Path
FIELDS=('inputTokens','cachedInputTokens','cacheWriteInputTokens','outputTokens','reasoningOutputTokens','totalTokens')

def load(path):return json.loads(Path(path).read_text())
def write(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def parse(events):
    responses={};wrappers={};pending=[];active=None;calls={};final={};total=None;mapping={};seen=[]
    for e in events:
        p=e.get('params',{});i=p.get('item',{});method=e.get('method')
        if method=='rawResponseItem/completed' and i.get('type') in ('custom_tool_call','function_call'):
            active=i.get('call_id',i['id']);wrappers[active]=dict(i);pending.append(active)
        if method=='rawResponse/completed':
            rid=p['responseId'];responses[rid]=p.get('usage',{})
            attr=p.get('usageMetadata',{}).get('metadata',{}).get('attribution',{}).get('items',{})
            own=[k for k,w in wrappers.items() if attr.get(w['id'],{}).get('output_tokens',0)>0]
            for k in own or pending:mapping[k]=rid
            pending=[]
        if method=='thread/tokenUsage/updated':total=p['tokenUsage']['total']
        if method in ('item/started','item/completed') and i.get('type') in ('mcpToolCall','commandExecution'):
            if i['id'] not in calls:
                calls[i['id']]={'wrapper':active,'event_index':len(seen)}
            calls[i['id']].update(i)
        if method=='item/completed' and i.get('type')=='agentMessage' and i.get('phase')=='final_answer':final[i['id']]=i.get('text','')
        seen.append(e)
    for c in calls.values():c['response_id']=mapping.get(c['wrapper']);c['response_ordinal']=list(responses).index(c['response_id'])+1 if c['response_id'] in responses else None
    return {'responses':responses,'wrappers':wrappers,'calls':list(calls.values()),'final_answer':'\n\n'.join(final.values()),'native_total':total}

def clean_symbol(symbol):
    return re.sub(r'\s+\((?:public|protected|private)\)$','',symbol)

def same_symbol(a,b):
    a,b=clean_symbol(a),clean_symbol(b)
    return a==b or re.sub(r'[.#]([^.#]*)$',r'#\1',a)==re.sub(r'[.#]([^.#]*)$',r'#\1',b)

def body_evidence(call,symbol,entry):
    if call.get('type')=='mcpToolCall' and call.get('tool')=='find_symbol':
        a=call.get('arguments',{});asked=a.get('symbols',[]) or [a.get('symbol','')]
        if a.get('metaOnly'):return False
        # Need delivered source, never mere requested IDs, outlines, or container headers.
        if not any(same_symbol(symbol,x) for x in asked) and entry['relativePath'] not in asked and a.get('relativePath')!=entry['relativePath']:return False
        raw=json.dumps(call.get('result',{}),ensure_ascii=False)
        content=entry.get('content',entry.get('body',''))
        # Escaped serialized body must actually be present in observed result.
        return bool(content) and json.dumps(content,ensure_ascii=False)[1:-1] in raw
    if call.get('type')=='commandExecution' and call.get('exitCode')==0:
        text=call.get('aggregatedOutput') or ''
        body=entry.get('content',entry.get('body',''))
        # Shell reads with line-number prefixes are supported; exact significant source lines required.
        lines=[x.strip() for x in body.splitlines() if x.strip() and not x.lstrip().startswith('#')]
        cmd=call.get('command','')
        return entry['relativePath'] in cmd and bool(lines) and all(x in text for x in lines)
    return False

def scoped_search(c,path,patterns,allow_scopes=()):
    if c.get('type')!='commandExecution' or c.get('exitCode') not in (0,1):return False
    cmd=c.get('command','')
    in_scope=path in cmd or any(scope in cmd and path in (c.get('aggregatedOutput') or '') for scope in allow_scopes)
    return in_scope and re.search(r'\b(rg|grep)\b',cmd) and all(p in cmd for p in patterns)

def evaluate(meta,case,parsed,rules):
    calls=parsed['calls'];answer=parsed['final_answer'];fixture=case['fixture'];checks={};evidence={}
    rule=rules['cases'][case['id']]
    assert 'required_symbols' in rule,'Grade must explicitly separate required symbols from optional backend support'
    all_bodies=fixture.get('find_symbol_bodies',{})
    bodies={k:all_bodies[k] for k in rule['required_symbols']};coverage={}
    for symbol,entry in bodies.items():
        hits=[c for c in calls if body_evidence(c,symbol,entry)]
        coverage[symbol]={'covered':bool(hits),'waves':sorted(set(c['response_ordinal'] for c in hits if c['response_ordinal'])),'call_ids':[c['id'] for c in hits]}
    checks['all_required_bodies_delivered']=all(x['covered'] for x in coverage.values())
    waves=set(w for x in coverage.values() for w in x['waves']);searches=[]
    if 'scoped_search' in rule:
        ss=rule['scoped_search'];searches=[c for c in calls if scoped_search(c,ss['path'],ss['patterns'],ss.get('allow_scopes',[]))]
        checks['scoped_literal_search']=bool(searches)
        evidence['scoped_search_call_ids']=[c['id'] for c in searches]
        waves.update(c['response_ordinal'] for c in searches if c['response_ordinal'])
        if ss.get('absence'):checks['absence_verified_zero_matches']=any(c.get('exitCode')==1 and not (c.get('aggregatedOutput') or '').strip() for c in searches)
    if rule.get('required_source_read'):
        rs=rule['required_source_read']
        checks['required_discovered_source_read']=any(c.get('type')=='commandExecution' and rs['path'] in c.get('command','') and c.get('exitCode')==0 and all(t in (c.get('aggregatedOutput') or '') for t in rs['tokens']) for c in calls)
    if rule.get('independent_one_wave'):checks['independent_evidence_one_model_response']=len(waves)==1
    checks['symbols_batch_max20']=all(1<=len(c.get('arguments',{}).get('symbols',[]))<=20 for c in calls if c.get('tool')=='find_symbol' and 'symbols' in c.get('arguments',{}))
    facts=[]
    for fact in rule.get('facts',[]):
        passed=all(re.search(pattern,answer,re.I|re.S) is not None for pattern in fact['patterns']);facts.append({'label':fact['label'],'pass':passed})
    checks['answer_fact_signals']=all(x['pass'] for x in facts)
    for pattern in rule.get('source_paths',[]):checks['source_path:'+pattern]=pattern in answer
    if rule.get('source_identity_any'):
        checks['unambiguous_source_identity']=any(x in answer for x in rule['source_identity_any'])
    find=[c for c in calls if c.get('tool')=='find_symbol'];lookups=[(c.get('arguments',{}),c['response_ordinal'],c['id']) for c in find]
    if rule.get('discovery_before_body'):
        target=rule['discovery_before_body']
        body_calls=[c for c in calls if target in coverage and c['id'] in coverage[target]['call_ids']]
        predecessors=[]
        for body in body_calls:
            for candidate in calls:
                if candidate['id']==body['id'] or candidate.get('tool') not in ('semantic_search','hybrid_search','find_symbol'):
                    continue
                if (candidate.get('completedAtMs') or 0) > (body.get('startedAtMs') or 0):
                    continue
                result=json.dumps(candidate.get('result',{}),ensure_ascii=False)
                if target in result:
                    predecessors.append({'discovery_id':candidate['id'],'body_id':body['id'],'discovery_wave':candidate['response_ordinal'],'body_wave':body['response_ordinal']})
        checks['new_locator_observed_before_body']=bool(predecessors)
        evidence['valid_dependency_pairs']=predecessors
    if rule.get('direct_suggestion'):
        target=rule['direct_suggestion'];first=next((a for a,w,cid in lookups),{})
        checks['unique_exact_basename_used_directly']=first.get('relativePath')==target or target in first.get('symbols',[]) or first.get('symbol')==target
        raw='\n'.join(json.dumps(c.get('result',{}),ensure_ascii=False) for c in find)
        checks['complete_suggested_file_delivered']=all(token in raw for token in ['ExportOperationWorker','TransferBytesToPresignedTarget'])
    if rule.get('ambiguous_directory'):
        directory=rule['ambiguous_directory'];first=next((a for a,w,cid in lookups),{})
        checks['ambiguous_suggestions_directory_first']=first.get('relativePath','').rstrip('/')==directory.rstrip('/')
        checks['both_worker_sources_delivered']=all(any(token in json.dumps(c.get('result',{})) for c in find) for token in ['Vendor::Inbound::Download','Vendor::Outbound::Upload'])
    if rule.get('policy_pairs'):
        pairchecks=[]
        for n in range(1,22):
            label=f'Policy{n:02d}';value=str(n+10);path=f'app/lib/vendor/policies/policy_{n:02d}.rb'
            # Table/line association is checked, preventing an unrelated bag of 21 numbers.
            lines=[l for l in answer.splitlines() if label in l or path in l]
            pairchecks.append({'policy':label,'expected':value,'path':path,'pass':any(re.search(r'(?<!\d)'+value+r'(?!\d)',l) and (path in l or f'policy_{n:02d}.rb' in l) for l in lines)})
        checks['all_21_value_source_pairs']=all(x['pass'] for x in pairchecks);evidence['policy_pairs']=pairchecks
    evidence.update(body_coverage=coverage,relevant_evidence_response_ordinals=sorted(waves),facts=facts)
    return {'checks':checks,'mechanical_pass':all(checks.values()),'evidence':evidence,'semantic_review':'REQUIRED: human review final answer for meaning, unsupported assertions and source associations; fact regexes are signals only'}

def collect(base,rulespath,output=None):
    output=Path(output) if output else base/'collected.json'
    assert not output.exists(),'Never overwrite a prior collected verdict; use --output NEWFILE'
    manifest=load(base/'manifest.json');cases={c['id']:c for c in load(base/'cases-source.json')['evals']};rules=load(rulespath);rows=[]
    for meta in manifest['cases']:
        actor=Path(meta['directory'])/'actor';statuspath=actor/'status.json'
        if not statuspath.exists():rows.append({'case':meta['key'],'status':'UNRUN','verdict':'OPEN'});continue
        status=load(statuspath);events=[json.loads(l) for l in (actor/'events.jsonl').read_text().splitlines() if l.strip()];p=parse(events)
        usage={k:sum(r.get(k,0) for r in p['responses'].values()) for k in FIELDS}
        total=p['native_total'];balanced=bool(total) and all(usage[k]==total[k] for k in FIELDS)
        uncached=usage['inputTokens']-usage['cachedInputTokens'];cost=(Decimal(uncached)*2+Decimal(usage['cachedInputTokens'])*Decimal('0.1')+Decimal(usage['outputTokens'])*10)/1000000
        grade=evaluate(meta,cases[meta['id']],p,rules)
        row={'case':meta['key'],'status':status,'verdict':'REVIEW_REQUIRED' if status.get('valid') and grade['mechanical_pass'] and balanced else 'OPEN_FAIL','model_responses':len(p['responses']),'raw_response_ids':list(p['responses']),'usage':usage,'native_usage_balanced':balanced,'standard_API_equivalent_USD':str(cost),'final_answer':p['final_answer'],'native_calls':p['calls'],'outer_calls':list(p['wrappers'].values()),'grade':grade}
        answerpath=actor/'answer.txt'
        if answerpath.exists():assert answerpath.read_text()==p['final_answer']+'\n'
        else:answerpath.write_text(p['final_answer']+'\n')
        rows.append(row)
    out={'condition':str(base),'model':'gpt-6.1-sol','effort':'medium','runs_per_case':1,'plugin_version':manifest['plugin_version'],'source_plugin_sha256':manifest['source_plugin_sha256'],'case_source_sha256':manifest['case_source_sha256'],'grading_sha256':hashlib.sha256(Path(rulespath).read_bytes()).hexdigest(),'cases':rows,'total_model_responses':sum(r.get('model_responses',0) for r in rows),'limitations':['Synthetic retained raw facts, not fresh history or original large-context replay.','n=1 per case/condition; no statistical speed claim.','One mandatory setup/schema response may be necessary and is not an avoidable wave.','Native response count is primary; nested call count does not measure model steps.','Regex facts require semantic human review; no automated correctness/completion claim.','Standard API-equivalent cost is not subscription billing.']}
    write(output,out)
    print(json.dumps({'base':str(base),'responses':out['total_model_responses'],'cases':[{'case':r['case'],'verdict':r['verdict'],'responses':r.get('model_responses'),'failed_checks':[k for k,v in r.get('grade',{}).get('checks',{}).items() if not v]} for r in rows]},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--grading',required=True);p.add_argument('--output');a=p.parse_args();collect(Path(a.base).resolve(),Path(a.grading).resolve(),a.output)
