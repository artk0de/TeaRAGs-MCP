# Control-v3 semantic review

Все8 финальных ответов соответствуют fixture. Модели и повторные прогоны не запускались; raw mechanical verdicts сохранены.

Реальный fail: C-batch-limit отправляет21symbols, получает ошибку backend, затем восстанавливается20+1 в следующей волне. P-single выполняет старую directory fallback policy; это ожидаемое отличие baseline от нового правила. W02 search scope spec и W21 client credentials отвергнуты слишком буквальным grader.

## W02-independent-body-and-refs

PASS_FOR_FIXTURE; PRIMARY_INDEPENDENT_READS_PASS; TOTAL_STEPS_CONFOUNDED; responses=7.

Response2 combines Router call/handle with independent spec filename search. Response3 reads newly discovered spec and further Router sources. Additional handlers/helper search and graph do not establish the originally targeted serialized search behavior.

Mechanical fail review:

- scoped_literal_search false is a lexical grader limitation: rg transport spec searches the same spec directory as spec/ and discovers exact fixture file; response3 reads that source. Filename was absent retained context.

Limitations:

- Remaining requested Router handlers and ENTITY constants are not mapped as individual backend bodies, despite original outline exposing them. Constant shared source delivered under ROUTES/UUID_NAMESPACE already contains ENTITY constants.
- pagination guide request returns Unknown resource; spec helper stub_vendor_ping is referenced in saved spec excerpt but helper file absent.
- Total7 responses cannot be used as clean performance baseline without these qualifications.

## W21-known-method-batch

PASS; KNOWN_GROUP_BATCH_PASS; ONE_EXTRA_READY_GROUP_WAVE_OBSERVED; responses=4.

Eight mandatory bodies and further request methods arrive in response2. exchange_code! and token_connection requested in response3 were already in retained outlines and are independent: one additional known-source group is serialized, though not the original two-group separation.

Mechanical fail review:

- Revocation fact regex falsely rejects client credentials paraphrase because it expects literal client_credentials. All required semantics, including refresh_token/token_revoke and connect/reconnect via connected_at, are present.

Limitations:

- RequestError#initialize is requested but absent backend. Final facts on exception payload are independently supported by on_complete body.
- Required groups all covered in response2, so do not describe this actor as failing original known BaseClient+TokenRefreshable grouping.

## W35-body-and-absence

PASS_WITH_COMPACT_SOURCE_SCOPE; PASS; responses=3.

Response2 reads required lookups and performs uid|uuid absence search concurrently. Final includes find_by_account_user names and scopes absence to Contact API file.

Limitations:

- On-disk Contact file remains compact assembly of exact source methods; absence is fixture-local, not real complete-module proof.
- Actor additionally requests existing_ids absent from fixture, but does not retry it or make unsupported claim.
- Original source line references do not map directly onto assembled fixture file positions.

## C-dependent-new-locators

PASS; PASS; responses=4.

Response2 semantic search discovers exact retryable? ID, response3 reads it. No speculative pre-discovery method read.

Limitations:

- Synthetic policy control.

## C-partial-not-body

PASS; PASS; responses=3.

Metadata/header is followed by direct body read before reporting upload60/ordinary30.

Limitations:

- No source citation was explicitly requested; short answer omitting citation is not a factual or behavioral failure.

## P-single-exact-suggestion

PASS_WITH_MISSING_GRADING_SOURCE_ASSOCIATION; EXPECTED_BASELINE_NEW_POLICY_FAIL; responses=5.

Response2 shared-directory inventory, response3 known class, response4 method body, final5. Corrected parser preserves class owner. Direct file path was available in retained suggestions, but old policy forces directory.

Mechanical fail review:

- Directory first accurately fails candidate desired direct-suggestion criterion; baseline old core explicitly prescribes directory.
- source_path false accurately reports absent final path; this is citation association, not wrong inheritance/operation fact.

Limitations:

- Not an agent violation of baseline policy; use only as baseline/candidate policy contrast.

## C-ambiguous-suggestions

PASS; AMBIGUITY_CONTROL_PASS; responses=6.

Shared directory precedes both class and operation reads. Both final base/operation/path associations correct.

Limitations:

- Pagination resource returns Unknown resource before directory in same response3; total6 responses includes guide/schema overhead, not a necessary ambiguity cost.

## C-batch-limit

PASS; REAL_BATCH_LIMIT_FAILURE_THEN_RECOVERY; responses=4.

One failed model evidence wave occurs before valid20+1 batch, adding one response compared with first-try valid split.

Mechanical fail review:

- symbols_batch_max20=false is genuine: response2 sends21symbols and backend rejects with symbols must contain1-20items. Response3 recovers20+1 in one executor wave; all21 final value/path pairs correct.

Limitations:

- Synthetic short bodies; one actor does not establish a stable model error rate.

Candidate pending. Нельзя превращать36 суммарных responses в чистую оценку plugin cost или заранее обещать выигрыш.
