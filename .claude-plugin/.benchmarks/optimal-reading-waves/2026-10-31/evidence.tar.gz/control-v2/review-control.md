# Control-v2: независимый семантический разбор

Проверены8 завершённых actors без новых моделей, перезапусков и запросов корпуса. Raw артефакты сохранены. Проверка относительно fixture, не внешнего gold. Автор fixtures знает их устройство; это независимый от генерации actors разбор, не слепая оценка.

**Доказанных ошибочных фактов в финальных ответах не найдено.** Есть пропуск connect/reconnect у W21 и отсутствие source citation у C-partial/P-single.5 итоговых счётчиков шагов существенно искажены неполным backend/парсером. Исходные OPEN_FAIL не закрыты и не переписаны.

Основные независимые чтения W02, W21 и W35 уже объединены в response2; старый контроль не воспроизводит исходное разнесение этих чтений. Последующие волны нельзя объявлять ценой batching-правила: они следуют unknownSymbol, ложным Args IDs и outline-only ответам.

## W02-independent-body-and-refs

5 model responses. **ORCHESTRATION_TARGET_ALREADY_PASSES; OVERALL_MEASUREMENT_CONFOUNDED; RAW_OPEN_FAIL_RETAINED**

Initial independent Router body reads and spec filename search share response2. Spec source read in response3 depends on discovered filename. No evidence of the originally targeted serialized-independent-search failure.

Ответ: CORRECT_FOR_SCOPED_QUESTION.

Причины mechanical fail:

- all_required_bodies_delivered=false because apply_error_handling body was not requested; transport-selection answer already supported by held initialize/adapter_spec, so missing this particular body is not itself a factual gap for narrowed prompt.
- scoped_literal_search=false because actual rg searches spec/ for transport; grader requires exact spec file path, which was not retained initially. Actual search discovers that file and is appropriate.

Ограничения fixture:

- Retained Router/BaseClient outlines advertise opaque_token, ROUTES, UUID_NAMESPACE, entity/file and http/token/upload_connection, but backend contains only three selected method bodies. Legitimate requested IDs return unknownSymbol.
- Missing responses induce pagination read, retries and graph fallback; cannot attribute total5 responses or later waves to plugin batching defect.

Волны: Response3 contains necessary newly-located spec read plus failed supplemental lookups. Response4 get_callees yields noEdgeFixture; its usefulness cannot be judged against absent real edges/source.

## W21-known-method-batch

5 model responses. **BATCH_TARGET_PASSES; SMALL_ANSWER_OMISSION_OPEN; OVERALL_MEASUREMENT_CONFOUNDED**

All8 fixture-required BaseClient/TokenRefreshable bodies arrive together in response2. Known-method-group batching already succeeds.

Ответ: CORRECT_MAIN_FACTS_WITH_OMISSION.

Пропуски ответа:

- Does not mention exchange_operation: connected_at.present? selects reconnect, otherwise connect. This is a real omission relative to separate grading requirement, not a contradictory fact.

Причины mechanical fail:

- connect-vs-reconnect fact signal false corresponds to the omitted operation label distinction.
- revocation credentials fact signal false is a lexical false negative: answer says client credentials rather than literal client_credentials and correctly states refresh_token and token_revoke.

Ограничения fixture:

- Actor also requests BaseClient NETWORK_ERRORS/request/perform/apply_error_handling and token refresh/path methods from retained outline; these are absent from compact backend.
- Retry IDs including literal (private) suffix in response4 reflect outline/status formatting and failed backend lookup. Alias correction alone cannot supply missing source.

Волны: Responses3–4 follow incomplete backend results; do not count as proven plugin slowdown or guaranteed removable waves.

## W35-body-and-absence

5 model responses. **TARGET_PASSES_WITH_FIXTURE_SCOPE_LIMITATION; TOTAL_STEPS_CONFOUNDED**

Four required list bodies and scoped uid|uuid rg absence check share response2. Absence-check batching already succeeds.

Ответ: CORRECT_FOR_COMPACT_FIXTURE.

Ограничения fixture:

- Retained original outline advertises find_by_account_user/list_by_phone_number/list_by_sms_thread but compact backend omits them. Hash and dot variants both return unknownSymbol.
- Source fixture is a compact synthetic assembly, not original full Contact module. Zero uid/uuid matches supports fixture-local absence only; cannot extrapolate to actual whole application or real complete Contact source.
- Final references use original source line numbers carried by actual body fragments; compact on-disk file has different assembled positions. Treat source associations as symbolic original locations, not verified clickable fixture line correspondence.

Волны: Responses3–4 are retries after fixture-omitted advertised IDs, not evidence that the UUID check was serialized.

## C-dependent-new-locators

4 model responses. **SEMANTIC_AND_DEPENDENCY_CONTROL_PASS; MECHANICAL_GRADER_FALSE_NEGATIVE**

Response2 semantic_search returns Vendor::RefreshPolicy#retryable? and source path; response3 reads that exact newly discovered ID. This is a valid dependency sequence with no speculative body read.

Ответ: CORRECT.

Причины mechanical fail:

- dependency_discovery_precedes_read=false is an over-specific grading chain: it requires directory->file->method, rejecting valid semantic_search->known method.

Ограничения fixture:

- Synthetic policy source only; no repository behavior generalization.

Волны: Separate discovery/body responses are necessary under this observed route.

## C-partial-not-body

3 model responses. **BODY_CONTROL_PASS; SOURCE_CITATION_REQUIREMENT_OPEN_FAIL**

Actor reads timeout_seconds body before reporting60/30; correctly does not treat header/range metadata as body.

Ответ: CORRECT_WITH_MISSING_SOURCE_CITATION.

Пропуски ответа:

- Final response omits source path/citation required by grading.

Причины mechanical fail:

- source_path false is accurate as citation/source-association requirement; it is not a wrong timeout or body-read failure.

Ограничения fixture:

- Synthetic5-line class; otherwise this run exercises intended control without observed backend error.

Волны: One setup/schema response, one body-read response and final answer; no avoidable evidence wave established.

## P-single-exact-suggestion

7 model responses. **BASELINE_POLICY_HOP_OBSERVED; TOTAL_STEPS_INVALID_FOR_PERFORMANCE; CITATION_OPEN_FAIL**

Actor first lists common directory instead of directly using the sole exact-basename suggestion. That behavior follows old core fallback contract and is valid baseline evidence for intended policy change.

Ответ: CORRECT_WITH_MISSING_SOURCE_CITATION.

Пропуски ответа:

- Final response omits requested grading source path.

Причины mechanical fail:

- unique_exact_basename_used_directly=false accurately records first directory hop under old policy.
- complete_suggested_file_delivered=false: actor obtains operation body plus header via shell, rather than whole file in one response; answer still has necessary facts.
- source_path false accurately flags missing final source association.

Ограничения fixture:

- Ruby fallback parser fails to restore outer class after nested Args; exposes bogus Args#perform_operation locator.
- Mixed class/method batch produces outline-only responses, suppressing readable method body; retries metaOnly:false repeat same outline.
- Control overall7-response count includes fixture parser/result-contract failures; only first directory hop is clean baseline policy evidence.

Волны: Responses3–5 primarily recover from misleading Args ownership and class-induced body suppression; response6 shell header read recovers inheritance. Do not claim6→1-type plugin savings from this run.

## C-ambiguous-suggestions

9 model responses. **AMBIGUITY_CONTROL_AND_ANSWER_PASS; TOTAL_STEPS_INVALID_FOR_PERFORMANCE**

Actor first lists shared directory before choosing either same-basename suggestion. Ambiguity fallback control succeeds. Both final base/operation/path associations are correct.

Ответ: CORRECT.

Ограничения fixture:

- Class lookup returns only line1 metadata, not a real class header.
- A batch containing class plus method rows is globally outlined and strips method content; repeated metaOnly:false request cannot fix it.
- Actor later tries symbolId argument accepted by permissive fixture schema but not implemented by server, yielding unrelated unknownPath.
- 9 total responses therefore reflect fixture/schema fidelity limitations and cannot be used as plugin performance evidence.

Волны: Responses4–8 recover suppressed bodies/headers and unsupported argument behavior. Necessary inheritance evidence finally comes from one-line shell reads.

## C-batch-limit

3 model responses. **PASS_WITH_SYNTHETIC_SCOPE_LIMITATION**

Actor requests known21 methods as20+1 calls within response2, using Promise.allSettled, retains all paths and reports all21 values11..31 correctly.

Ответ: CORRECT.

Ограничения fixture:

- Small synthetic methods test batching and source pairing, not real-project latency or large-output truncation.

Волны: 3 total responses = setup/schema, batched evidence, final; no avoidable evidence wave established.

## Ограничение выводов

Один actor на условие. Не вычислять гарантированную экономию из41 суммарного response или из7/9 responses worker cases. Сначала исправить fidelity и grading, зафиксировать новый fingerprint, затем отдельно запускать разрешённые новые actors. Этот разбор не меняет verdict исходного прогона.
