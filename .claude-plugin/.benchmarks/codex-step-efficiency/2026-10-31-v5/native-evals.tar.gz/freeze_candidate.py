from pathlib import Path
import hashlib,json,re,shutil
root=Path('/Users/artk0re/Dev/Tools/tea-rags-mcp/.claude/worktrees/codex-efficiency-v5')
target=Path(__file__).resolve().parent/'sources/queued-evidence-policy'
assert not target.exists()
target.mkdir()
shutil.copytree(root/'scripts/harness',target/'scripts/harness')
shutil.copytree(root/'plugins',target/'plugins')
for name in ['package.json','.prettierrc']:
 shutil.copy2(root/name,target/name)
source=(root/'scripts/gen-harness-codex.ts').read_text()
policy=("Before an executor, match this question's missing facts to all retained locators and held bodies. "
"Queue every needed known entrypoint/caller/helper, independent scoped reference/absence searches and concept discovery, bounded config/spec reads "
"and missing tool declarations together; no schema-only or literal-first response while other needed work is ready. "
"Reuse held helper bodies instead of rediscovering them. find_symbol(symbols:[…]): max 20 targets per symbols call, "
"concurrent splits; directories via separate relativePath calls. Label inputs and inspect every outcome. "
"Another wave requires new locators, ambiguity, prerequisites or output budget; move remaining ready work into "
"that unavoidable wave. No future-question prefetch.")
marker='const CODEX_ROUTE_SCOPE = '
assert source.count(marker)==1
source=source.replace(marker,'const CODEX_EVIDENCE_WAVE = '+json.dumps(policy,ensure_ascii=False)+';\n\n'+marker,1)
begin=source.index('Before the first evidence call',source.index('**Tool execution and waiting.**'))
end=source.index('Use \\`find_symbol',begin)
removed=source[begin:end]
source=source[:begin]+'${CODEX_EVIDENCE_WAVE}\n'+source[end:]
pattern=r'"- Before the first evidence call, silently map EACH requested subquestion.*?no future-question prefetch\."'
source,count=re.subn(pattern,'`- ${CODEX_EVIDENCE_WAVE}`',source,count=1,flags=re.S)
assert count==1
(target/'scripts/gen-harness-codex.ts').write_text(source)
(target/'provenance.json').write_text(json.dumps({
 'variant':'queued-evidence-policy','base':'aacbfbf81c611b014e748103cb0c54004d331380',
 'mode':'Private hypothesis; not applied to production before native outcome',
 'policy':policy,'policy_chars':len(policy),'replaced_session_prefix_chars':len(removed),
 'generator_sha256':hashlib.sha256(source.encode()).hexdigest(),
 'scope':'Codex generator only; shared core/skills and backend unchanged',
 'generation':'npx tsx scripts/gen-harness-codex.ts in this source snapshot',
},indent=2)+'\n')
print(json.dumps({'target':str(target),'policy_chars':len(policy),'removed_session_chars':len(removed)}))
