# Three-variant native comparison

Recommendation: **do not adopt either policy replacement from these startup-confounded n=1 attempts**. Keep the controller fixes separate. All15 short native actors and81 native responses are retained; no full A/B or39-question benchmark was rerun.

| Variant | Responses | Source waves | Fresh input | Cached input | All input | Output | API-equivalent cost |
|---|---:|---:|---:|---:|---:|---:|---:|
| baseline | 27 | 18 | 143665 | 555648 | 699313 | 5838 | $0.4012748 |
| queued | 26 | 17 | 146425 | 575360 | 721785 | 6247 | $0.4128560 |
| flat | 28 | 20 | 177204 | 631680 | 808884 | 6692 | $0.4844960 |

| Case | Baseline | Queued | Flat |
|---|---:|---:|---:|
| C-Q35-missing-helper-body | 5 | 5 | 6 |
| C-Q36-new-migration-locators | 6 | 4 | 4 |
| T-Q02-independent-discovery-literal | 8 | 9 | 10 |
| T-Q21-known-missing-groups | 5 | 6 | 3 |
| T-Q34-held-validation-missing-gem | 3 | 2 | 5 |

Flat Q21 has a valid two-evidence-wave path: required constructor/status provenance and actual metric-group behavior are established in W2, together with already-known token callers. Its3-response result is not rejected merely because all known IDs were not fetchedW1. It also is not proof of policy causality: source waves stay2 versus baseline and setup differs.

Q34 flat adds actual dedicated fixture-conformance proof. Baseline/queued pass the frozen minimum with an explicit coverage limit; no must-read719 requirement is invented. More fixture evidence can legitimately cost reads, while known-file rediscovery and sequential range location remain distinct inefficiencies.

Q02 historical activation/spec use remains PARTIAL/UNKNOWN in every variant. Initial empty catalogs/CLI probes confound scheduling comparisons. Controls retain needed missing-helper and migration source.

Cost breakdown (fresh / cached / output, USD):
- baseline: $0.28733 / $0.0555648 / $0.05838.
- queued: $0.29285 / $0.057536 / $0.06247.
- flat: $0.354408 / $0.063168 / $0.06692.

All usage balances. Cache cannot be manually cleared; API-equivalent is not subscription billing. Timing is descriptive. Policy adoption remains on hold pending same-actor readiness diagnosis. Exact native IDs, source bodies, full finals, inventories and hashes are in the JSON artifacts.
