# Same-thread readiness controls

Both fresh actors observed the exact17-tool native inventory on their actual RPC/thread before turn/start. Their first filtered ALL_TOOLS outputs were nonempty. Q02 semantic+literal evidence co-waved; Q35 fetched the genuinely missing mapper body. No CLI detour.

| Case | Original baseline → ready responses | Source waves | Current facts / completeness |
|---|---:|---:|---|
| T-Q02-independent-discovery-literal | 8 → 9 | 6 → 7 | PASS_VISIBLE_CURRENT_STATE; PARTIAL/UNKNOWN: original activation and original spec setup remain unproved |
| C-Q35-missing-helper-body | 5 → 4 | 3 → 2 | PASS_VISIBLE_CURRENT_API_MAPPINGS; not applicable |

Total responses13→13 and source waves9→9. Both matching original baseline controls already had nonempty first catalogs; this validates readiness ordering, not a causal empty-catalog repair or speed improvement.

| Metric | Original matching2 | Ready2 |
|---|---:|---:|
| Fresh input | 62569 | 72017 |
| Cached input | 293376 | 306304 |
| All input | 355945 | 378321 |
| Output | 3007 | 3150 |
| Total tokens | 358952 | 381471 |
| API-equivalent cost | $0.1845456 | $0.2061644 |

Original shell/FS/proxy permissions are unchanged. CLI fallback remains NOTFIXED. No policy change, full39/B run, retry, or further models. Q02 original history remains unknown; no claim about the historical485s gap. All17 native attempts (original15+readiness2) are preserved.
