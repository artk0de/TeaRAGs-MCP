#!/opt/homebrew/bin/python3
"""No-model extraction of native visible evidence; never retain reasoning text."""
import importlib.util,json,hashlib,sys
from pathlib import Path
ROOT=Path('/Users/artk0re/Dev/Tools/tea-rags-mcp')
P=ROOT/'.tmp/gruntworx_codex_optimal_AB_2026-10-31/optimization-audit/native-wave-parser.py'
s=importlib.util.spec_from_file_location('native_parser',P);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
base=ROOT/'.tmp/codex-speed-v5-evals/prepared'
variant=sys.argv[1] if len(sys.argv)>1 else '*'
for path in sorted(base.glob(variant+'/*/actor/events-final.json')):
 events=json.loads(path.read_text());parsed=m.parse(events);out=path.parent
 visible_outputs=[];response_mapping={};pending=[];wrappers={}
 for index,e in enumerate(events):
  item=(e.get('params') or {}).get('item') or {};method=e.get('method')
  if method=='rawResponseItem/completed' and item.get('type') in ['custom_tool_call','function_call']:
   key=item.get('call_id',item['id']);wrappers[key]=item;pending.append(key)
  if method=='rawResponse/completed':
   p=e['params'];rid=p['responseId'];attr=p.get('usageMetadata',{}).get('metadata',{}).get('attribution',{}).get('items',{})
   own=[k for k,w in wrappers.items() if attr.get(w['id'],{}).get('output_tokens',0)>0]
   for key in own or pending:response_mapping[key]=rid
   pending=[]
  if method=='rawResponseItem/completed' and item.get('type') in ['custom_tool_call_output','function_call_output']:
   visible_outputs.append({'event_index':index,**item})
 classifications=[]
 for ordinal,rid in enumerate(parsed['responses'],1):
  calls=[c for c in parsed['calls'] if c.get('response_id')==rid]
  outer=[w for k,w in wrappers.items() if response_mapping.get(k)==rid]
  code='\n'.join(w.get('input',w.get('arguments','')) for w in outer)
  skill_calls=[c for c in calls if c.get('type')=='commandExecution' and ('/skills/' in c.get('command','') or 'tea-rags://guide/' in c.get('command',''))]
  availability_calls=[c for c in calls if c.get('type')=='commandExecution' and ('command -v tea-rags' in c.get('command','') or 'which tea-rags' in c.get('command',''))]
  source_calls=[c for c in calls if c not in skill_calls and c not in availability_calls]
  if source_calls:kind='source_evidence'
  elif skill_calls:kind='skill_or_guide_setup_only'
  elif availability_calls:kind='tool_availability_setup_only'
  elif outer and any(t in code for t in ['ALL_TOOLS','tool_search']):kind='catalog_or_schema_setup_only'
  elif not outer:kind='final_or_text_only'
  else:kind='other_review_required'
  classifications.append({'response_id':rid,'ordinal':ordinal,'classification':kind,'source_call_ids':[c['id'] for c in source_calls],'skill_call_ids':[c['id'] for c in skill_calls],'availability_call_ids':[c['id'] for c in availability_calls],'outer_call_ids':[w.get('call_id') for w in outer]})
 artifact={'variant':path.parents[2].name,'case':path.parents[1].name,'canonical_final_events_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'native_response_ids':list(parsed['responses']),'native_response_count':len(parsed['responses']),'response_classifications':classifications,'schema_or_catalog_only_setup_count':sum(x['classification']=='catalog_or_schema_setup_only' for x in classifications),'skill_or_guide_only_setup_count':sum(x['classification']=='skill_or_guide_setup_only' for x in classifications),'tool_availability_only_setup_count':sum(x['classification']=='tool_availability_setup_only' for x in classifications),'outer_visible_tool_code':list(wrappers.values()),'outer_visible_tool_outputs':visible_outputs,'native_observed_tool_calls':parsed['calls'],'final_answer':parsed['final_answer'],'private_reasoning_text_retained':False,'quality':'REQUIRES_SEMANTIC_REVIEW'}
 (out/'visible-evidence.json').write_text(json.dumps(artifact,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'variant':artifact['variant'],'case':artifact['case'],'responses':artifact['native_response_count'],'schema_setup':artifact['schema_or_catalog_only_setup_count'],'skill_setup':artifact['skill_or_guide_only_setup_count']}))
