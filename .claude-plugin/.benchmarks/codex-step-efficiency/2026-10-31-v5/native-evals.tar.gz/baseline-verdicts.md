# Baseline short native results

All5 actors ran once. Native total27; schema/catalog-only setup1; skill-only setup3. Q36 includes a skill read co-waved with source work, so it is not skill-only setup.

| Case | Total native responses | Schema-only | Skill-only | Completeness | Efficiency |
|---|---:|---:|---:|---|---|
| C-Q35-missing-helper-body | 5 | 0 | 1 | PASS_FOR_NAMED_RELEVANT_INTERNAL_API_CALLS | CONTROL_PASS_MISSING_HELPER_READ |
| C-Q36-new-migration-locators | 6 | 0 | 0 | PASS_EXPLICIT_MIGRATION_INDEXES_AND_FKS | CONTROL_PASS_GENUINE_DEPENDENCIES_PRESERVED |
| T-Q02-independent-discovery-literal | 8 | 0 | 1 | PARTIAL_HISTORY_NOT_ESTABLISHED | NO_REPRO |
| T-Q21-known-missing-groups | 5 | 1 | 1 | PASS_REQUESTED_CURRENT_BEHAVIOR | REPRO_KNOWN_READY_GROUP_SPLIT |
| T-Q34-held-validation-missing-gem | 3 | 0 | 0 | PASS_REQUESTED_CURRENT_BEHAVIOR | PARTIAL_REPRO_INDEPENDENT_READY_FILE_SPLIT |

Q02 supports current-state claims and handles uncertainty honestly, but does not establish historical activation/original spec usage. Its quality verdict is PARTIAL/UNKNOWN. Initial semantic+literal concurrency is NO_REPRO.

Q21 reproduces known ready source groups split across two evidence responses (16 targets,9903 chars); two setup responses are legitimate separate observations. Q34 reuses held helper but still splits independent Gemfile/client-spec reads. Controls preserve needed source discovery and missing helper reads.

All usage balanced; API-equivalent cost $0.4012748. No statistical or plugin latency conclusion. Exact native IDs, source references, full visible finals, inventories and evidence hashes are in baseline-verdicts.json.
