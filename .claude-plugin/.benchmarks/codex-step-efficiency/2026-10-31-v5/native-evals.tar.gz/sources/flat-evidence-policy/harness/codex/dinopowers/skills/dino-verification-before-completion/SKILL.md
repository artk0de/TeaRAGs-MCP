---
name: dino-verification-before-completion
description:
  'Before claiming done — collateral-damage scan of edits, then verification
  commands (evidence before claims). Completion claim beats
  finishing-a-development-branch unless merge/PR asked. Triggers "ready to
  commit", "all done", "should be fixed now", "commit and push", "готово",
  "можно коммитить", "проверь перед commit", "все работает", scan empty on an
  unindexed edit (UNVERIFIABLE, no bug). NOT mid-work checks w/o a completion
  claim.'
---

# dinopowers: verification-before-completion

Wrapper over `$verification-before-completion`. Adds **collateral-damage scan**:
before "complete", tea-rags blast-radius signals (imports, churn, ownership) on
just-edited files → which dependents to verify.

## Iron Rule

**Collateral-damage scan MUST run BEFORE claiming "done"** — whenever session
edited ≥1 existing file. Diff size irrelevant: 2-line change in high-blast file
= catastrophe; renames break imports.

Core value: `semantic_search` + impact rerank (`"blastRadius"` codegraph on,
`{imports 0.5, churn 0.3, ownership 0.2}` off) + brace-expanded `pathPattern`
over `git diff --name-only HEAD` + `metaOnly: true` + verdict surfacing
high-`fanIn`/`imports` files with explicit "verify dependents".

Only new files (no existing-file edits) → skip scan, verdict
`SAFE (no existing-file edits)`. Never fabricate pathPattern.

**Subagents run the scan themselves.** Task-agent / explore / any subagent
claiming or verifying completion → scan FIRST (read-only `semantic_search`, no
reindex), verdict per file, THEN `$verification-before-completion`. "Report to
parent" covers reindex / drift remedies only — never hand the scan itself to the
parent.

**Codegraph on?** Graph tools (`get_callers`, `trace_path`, `review_changes`, …)
in your tool list; absent = off.

**Diff review, same gate** (codegraph on, session edited files) — BEFORE "done"
/ commit: open the tea-rags plugin file `skills/data-driven-generation/SKILL.md`
(not under dinopowers) in this turn, plan-only included, run its Step 7 (checks
per its `references/step-7-verify.md`), and print its `#### Step 7 answer block`
line by line — that block IS the answer; nothing here narrows or restates it.
Wrapper-only: `changes:{}` = uncommitted edit; committed branch →
`changes:{base}`, base = `git merge-base HEAD main`, never a sibling /
integration branch; findings from a stack below = its owner's, cite the commit,
no triage.

## Verdict Ladder (PRESCRIPTIVE — apply before claiming done)

🛑 STOP — read the ladder, then act.

Blast signal = `fanIn` when codegraph on (real dependents), else `imports`
proxy.

| Verdict        | Triggers                                                              | Action (MUST state)                                                                                |
| -------------- | --------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| `UNVERIFIABLE` | scan ran, returned empty (file unindexed / not in git)                | "blast radius unknown" → run FULL suite conservatively; never relabel SAFE                         |
| `HIGH-BLAST`   | `fanIn`/`imports` top 10% of result set (or absolute: >20 dependents) | Surface block to user BEFORE verification runs; recommend FULL suite (all dependents, not own dir) |
| `MEDIUM-BLAST` | `fanIn`/`imports` top 30% (or 5-20 dependents)                        | Run tests of the dependents' area (integration around the file)                                    |
| `LOW-BLAST`    | `fanIn`/`imports` < 5 dependents                                      | File's own tests suffice                                                                           |

`SAFE (no existing-file edits)` only when Step 1 finds no existing-file edit and
the scan never ran. Scan given as numbers / "empty" in the prompt = Step 2
output → name verdict AND its Action now.

Prescriptive, not informational — DO NOT skip; never downgrade HIGH-BLAST to
"probably fine" without evidence. Block says WHICH tests to run; LOW-BLAST needs
no full suite. HIGH-BLAST under time pressure ("deadline", "just the quick
ones"): never pick a narrower set yourself — show the block, state the full
dependent suite it requires, wait for the user's explicit override that
acknowledges the risk before running less. Say: "HIGH-BLAST on <file> — full
dependent suite required. Running only <narrower set> needs your explicit
override acknowledging the risk (untested dependents may break) — reply
'override, I accept the risk'." Deadline in the request ≠ that override.

**Chaining rule:** see [CHAINING.md](../../CHAINING.md) — every $dino-X
redirects $X. NEVER bypass the wrapper. Open each chained SKILL.md with its own
read.

**Requires superpowers for the inner step:** `$verification-before-completion` —
availability per [CHAINING.md](../../CHAINING.md) "Missing superpowers" steps
1–3. Not in the skills list ≠ unavailable (the list is truncated): run
`ls $CODEX_HOME/plugins/cache/*/superpowers/*/skills/verification-before-completion/SKILL.md`
as written first — a hand-built path failing proves nothing. Only that glob
matching nothing → still run the collateral-damage scan (Iron Rule), then stop
before claiming "done", say the inner step could not run, ask the user to
install superpowers (https://github.com/obra/superpowers). The missing skill
blocks only the inner step and the completion claim, never the scan; NEVER
present the scan alone as the full workflow.

**Index freshness:** see [FRESHNESS.md](../../FRESHNESS.md) +
`tea-rags://guide/freshness`. Linked worktree → overlay serves edits, never
reindex. Main checkout → incremental `index_codebase` BEFORE first call over
uncommitted edits, or once `changedFiles` > 0 — no consent (drift `Run:` with
`--force*` → ask the user, never awaited; print
`--force not run; reads continue`; then the answering call). Lag ≠ unusable
(core rules).

## Step 1 — Collect edited file set

From `git status --short` / `git diff --name-only`:

| Source                                 | Example                                  |
| -------------------------------------- | ---------------------------------------- |
| Modified files (`M`) in working tree   | `src/core/domains/explore/reranker.ts`   |
| Staged files (`M`/`R` in index)        | `tests/explore/reranker.test.ts`         |
| Files changed in session (uncommitted) | any file touched by Edit/Write/MultiEdit |

Output:

- `editedFiles`: relative paths with content changes + renames under OLD path
  (its dependents break); new-only files excluded
- `intent`: one sentence — what session changed

`editedFiles` empty → Step 4, verdict `SAFE (no existing-file edits)`.

## Step 2 — Collateral-damage scan call

ONE `semantic_search` — SAME idiom as `$dino-writing-plans` /
`$dino-executing-plans`:

```
project:     <alias>                    ← `tea-rags://guide/freshness` "Addressing the Codebase"
path:        <your working directory>   ← the tree (worktree / branch checkout)
query:       <intent from Step 1>
pathPattern: "{editedFile1,editedFile2,...}"   ← brace expansion
rerank:      "blastRadius"               ← codegraph on; OFF fallback below
limit:       <editedFiles.length * 3>
metaOnly:    true
fields:      ["relativePath", "imports", "git"]   ← metaOnly alone drops raw git.* / imports
```

**Codegraph gating for `rerank`:** on → `"blastRadius"` (real `fanIn`); off →
`{ custom: { imports: 0.5, churn: 0.3, ownership: 0.2 } }` (import-proxy).

Do NOT substitute:

| Wrong tool                                                      | Why wrong                                                                                                                                                                               |
| --------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `hybrid_search`                                                 | BM25 leg re-ranks by token overlap — want semantic + signals                                                                                                                            |
| Named preset `"hotspots"` / `"codeReview"` / `"impactAnalysis"` | `impactAnalysis` doesn't exist; `hotspots` = BUG-prone history, not BLAST radius. `"blastRadius"` correct when codegraph on                                                             |
| `mcp__tree-sitter__trace_impact`                                | Structural call trace = complementary, not git-signal blast radius; tea-rags first                                                                                                      |
| One call per file                                               | Brace expansion covers all                                                                                                                                                              |
| Built-in `grep -r "import.*<file>"`                             | Not grep: it matches import text only — misses re-exports and call weight. Importers via `get_callers(relativePath=<module>)` (codegraph on) / `hybrid_search` on the module path (off) |
| `git log --oneline <files>`                                     | History of edited files, not dependents                                                                                                                                                 |

Do NOT pass:

- `metaOnly: false` — verdict inputs = signals, not content
- Different weights — must match `$dino-writing-plans` / `executing-plans` /
  `$data-driven-generation` IMPACT step (cross-skill comparability)
- `filter` narrowing — `pathPattern` scopes

Empty results (files brand-new / not in git) → Step 4, verdict
`UNVERIFIABLE (edited files not indexed)`. Never fabricate signals.

## Step 3 — Compute collateral-damage verdict

Per unique `relativePath`: raw values from `payload.git.file.*` + `imports`
(present only because Step 2 names them in `fields`) + labels from
`rankingOverlay.file.*` (kept under metaOnly; payload never labelled):

- blast radius — `rankingOverlay.file.fanIn` (blastRadius, codegraph on) or
  `imports` count (custom fallback, off)
- `commitCount` — churn
- `blameDominantAuthorPct` + adaptive label — silo risk (use label `silo` /
  `deep-silo`, codebase-relative, not magic %)

`treeState` rows (your edited files) = the index's PRE-EDIT copies — print per
file:
`<file>: treeState modified — pre-edit index copy, text/lines stale, not proof of the edit; dependents' fanIn/churn valid; current code → find_symbol(relativePath: <file>, project=<alias>, path=<cwd>)`.
Why: fanIn + churn of dependents stay valid (unless those dependents were edited
too; graph edges follow cascade floor rule); row text and lines are stale —
never evidence the edit is correct. Current code via
`find_symbol project=<alias> path=<your working directory>`; linked worktree →
no reindex (Index freshness above).

Apply Verdict Ladder per file. Aggregate:

```
### dinopowers collateral-damage scan

| Edited file | imports | churn | verdict |
|---|---|---|---|
| src/core/contracts/errors.ts | 47 | 23 commits | HIGH-BLAST |
| src/adapters/qdrant/client.ts | 12 | 8 commits | MEDIUM-BLAST |
| tests/explore/strategies.test.ts | 0 | 2 commits | LOW-BLAST |

**Next action:** invoke `$verification-before-completion` now with
this block — its own plan step, never verification planned inline instead.

**Verify before claiming done:**
- `errors.ts` imported by 47 modules → run the project's test suite covering all dependents
- `client.ts` imported by 12 modules → run integration tests touching the qdrant adapter
- `strategies.test.ts` → no dependents; the file's own tests are sufficient
```

Runner-agnostic — never name runners (vitest, jest, pytest, rspec…). Reader
resolves actual test command from project context (package.json scripts,
Makefile, CI).

## Step 3a — Tests-at-risk lookup (targeted verification)

Invoke `$tests-as-context` with:

```
recipe: "tests-at-risk"
affectedFiles: <editedFiles from Step 1>
intent: <intent from Step 1>
```

Recipe → DSL leaf test chunks bound to change. Per HIGH/MEDIUM-BLAST file with
non-empty list, augment verdict block:

```
**Targeted scenarios for high-blast files:**
- src/core/contracts/errors.ts → run the tests for these scenarios:
  - tests/errors/typed-errors.test.ts:42 — TypedError > propagates cause
  - tests/api/handler-errors.test.ts:78 — handler > error response shape
```

Runner-agnostic ("run the tests for these files", "execute these scenarios via
the project's standard test command").

Recipe SKIP (no DSL test chunks) → add
`**Targeted scenarios:** unavailable (no DSL test chunks indexed) — verification scope guided by blast-radius signals only`.

Recipe empty (preflight passed, no match) → add
`**Targeted scenarios:** no obvious test bindings — run general verification covering blast-radius dependents`.

## Step 4 — Invoke $verification-before-completion

Invoke `Skill` tool with `$verification-before-completion`. Prepend
collateral-damage block. Handoff:

> "Before claiming done, the edited files have these blast-radius signals:
> …<block>… Run verification commands that exercise HIGH-BLAST dependents, not
> just files directly edited. Evidence before assertions.
>
> Chaining rule reminder: when your cycle would next invoke
> `$finishing-a-development-branch` (or any wrapped `$Y`), invoke `$dino-Y`
> instead — see the Chaining rule section above."

Inner skill runs verification (tests, type-check, lint, build). Wrapper informs
scope, never substitutes.

## Red Flags — STOP and restart from Step 2

- "Only tests need to run, change isolated" / "edited files' tests pass" → ANY
  edited file `imports > 0` → run Step 2; dependents may break
- "git diff small, skip scan" / "trivial rename" → run Step 2
- User offers `grep` for importers → answer opens with the `Not grep: …` line of
  the table above, verbatim
- Substituted `grep -r` / `git log` → importers via
  `get_callers(relativePath=<module>)` (codegraph off: `hybrid_search` on the
  module path); blast radius via Step 2
- Rerank wrong for codegraph state → redo: on → `"blastRadius"`, off →
  `{imports: 0.5, churn: 0.3, ownership: 0.2}` (tea-rags analytics-rerank)
- `rerank: "hotspots"` → bug history, not blast radius; redo
- Skipped verification after surfacing HIGH-BLAST → wrapper informs scope, never
  substitutes
- Ran scan, ignored block in verification → block is prescriptive
- `metaOnly: false` → restart
- Inner skill chained raw `$finishing-a-development-branch` → intercept, invoke
  `$dino-finishing-a-development-branch` (Chaining rule)
