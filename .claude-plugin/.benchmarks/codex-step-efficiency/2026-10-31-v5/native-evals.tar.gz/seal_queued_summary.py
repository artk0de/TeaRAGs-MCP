from pathlib import Path
import importlib.util,json,time
root=Path('/Users/artk0re/Dev/Tools/tea-rags-mcp/.tmp/codex-speed-v5-evals')
p=root/'short_native.py'
sp=importlib.util.spec_from_file_location('queued_proof',p)
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
records=[]
expected_changes=['scripts/codex-rules.txt','scripts/turn-routing.txt','skills/tea-rags-core/SKILL.md']
for f in sorted((root/'prepared/queued').glob('*/manifest.json')):
 q=m.load(f);backup=f.with_name('pre-optimize-guard-manifest.json')
 assert not backup.exists();backup.write_bytes(f.read_bytes())
 q['runner_sha256']=m.sha(p);q['runtime']=m.runtime();m.dump(f,q)
 b=m.load(root/'prepared/baseline'/q['case']/'manifest.json');m.verify_environment_seal(q)
 assert q['cases_sha256']==b['cases_sha256'] and q['grading_sha256']==b['grading_sha256'] and q['provenance_sha256']==b['provenance_sha256']
 assert q['prompt_sha256']==b['prompt_sha256']
 assert q['module_sha256']==b['module_sha256'] and q['backend_frozen_files']==b['backend_frozen_files'] and q['frozen_executables']==b['frozen_executables']
 assert {k:v for k,v in q['runtime'].items() if k!='optimize'}==b['runtime']
 assert not (Path(q['home'])/'sessions').exists() and not (f.parent/'actor').exists()
 changed=[name for name,h in q['plugin_inventory'].items() if b['plugin_inventory'].get(name)!=h]
 assert sorted(changed)==expected_changes,changed
 normalized=[]
 for rel in ['home/config.toml','proxy-actor.json','bin-actor/tea-rags']:
  qtext=(f.parent/rel).read_text().replace(str(f.parent.resolve()),'<BASE>')
  bf=root/'prepared/baseline'/q['case']
  btext=(bf/rel).read_text().replace(str(bf.resolve()),'<BASE>')
  assert qtext==btext,(q['case'],rel)
  normalized.append(rel)
 records.append({'variant':'queued','case':q['case'],'manifest':str(f.resolve()),'manifest_sha256':m.sha(f),'pre_guard_manifest_sha256':m.sha(backup),'model_turns':0,'tools':17,'skills':18,'hooks':14,'plugin_files':len(q['plugin_inventory']),'package_changed_files_vs_baseline':changed,'same_prompt_module_backend_binaries':True,'normalized_launch_files_match':normalized})
assert len(records)==5
first=Path(records[0]['manifest']);start=time.monotonic();m.validate(first.parent,m.load(first));elapsed=time.monotonic()-start
summary={'status':'GUARDED_READY_FOR_ROOT_REVIEW_NO_GO','variant':'queued','model_turns':0,'actors_started':0,'runtime':m.runtime(),'runner_sha256':m.sha(p),'historical_baseline_runner':str((root/'versions/short_native-4aaf.py').resolve()),'historical_baseline_runner_sha256':m.sha(root/'versions/short_native-4aaf.py'),'controller_delta_after_baseline':'Ordinary early rejection of optimized Python or wrong Python version; optimize0 runtime recorded. Normal no-O Python3.15 actor behavior unchanged. Baseline manifests/results unmodified.','cases_sha256':m.sha(m.CASES/'cases.json'),'grading_sha256':m.sha(m.CASES/'grading.json'),'provenance_sha256':m.sha(m.CASES/'provenance.json'),'protocol_sha256':m.sha(m.CASES/'protocol.md'),'source_marketplace':str((root/'sources/queued-evidence-policy').resolve()),'prepared_queued':records,'shared_frozen_backend_full_corpus_validation_seconds':elapsed,'cases_grading_prompts_modules_runtime_backend_unchanged_vs_baseline':True,'normalized_profiles_proxy_shims_match_baseline':True,'native_package_only_changed_files':expected_changes,'rootgo_exists':False,'behavioral_verdict':'UNRUN/OPEN','baseline_verdict_reference':str((root/'baseline-verdicts.json').resolve()),'baseline_Q02_quality':'PARTIAL/UNKNOWN historical activation and original spec completeness; current-state safety/honesty PASS','optimization_guard_proof':str((root/'optimization-guard-proof.json').resolve())}
m.dump(root/'queued-no-turn-summary.json',summary)
print(json.dumps(summary,ensure_ascii=False))
