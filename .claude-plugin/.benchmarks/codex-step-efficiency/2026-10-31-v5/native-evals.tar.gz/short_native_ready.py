#!/opt/homebrew/bin/python3
"""Short native one-question actors; prepare is strictly no-model, run needs root GO.

Uses unchanged archived live API/proxy and prepare.setup/proof. Never invokes
39-question runner, builds a server, indexes source, or synthesizes tool results.
"""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from mcp_readiness import wait_for_mcp_ready

ROOT=Path('/Users/artk0re/Dev/Tools/tea-rags-mcp')
ARCHIVE=ROOT/'.tmp/gruntworx_codex_A_2026-10-31_v4_01'
SCRATCH=ROOT/'.tmp/codex-speed-v5-evals'
CASES=ROOT/'.claude/worktrees/codex-efficiency-v5/.claude-plugin/.benchmarks/codex-step-efficiency/2026-10-31-v5'
REPO='/Users/Shared/nav-ab/repo-master'
PROJECT='taxdome-worktree-navmaster'
MODULE_NAMES=['codex61_app_rpc.py','codex61_mcp_proxy.py','codex61_cli.py','codex61_metrics.py','codex61_context_metrics.py','protocol.py','mcp_readiness.py']

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def dump(p,x):
 p=Path(p);tmp=p.with_name(p.name+'.writing');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');tmp.replace(p)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def runtime():
 if sys.flags.optimize != 0:
  raise RuntimeError('Optimized Python is forbidden: safety assertions must remain enabled')
 if sys.version_info[:2] != (3,15):
  raise RuntimeError('Explicit Python 3.15 runtime required')
 return {'executable':sys.executable,'version':sys.version,'resolved_executable':str(Path(sys.executable).resolve()),'optimize':sys.flags.optimize}
def inventory(p):return {str(x.relative_to(p)):sha(x) for x in sorted(Path(p).rglob('*')) if x.is_file() and not x.is_symlink()}
def case_by_id(cid):return next(x for x in load(CASES/'cases.json')['cases'] if x['id']==cid)
def prompt_for(case):
 raw=load(CASES/'cases.json');sections=['Project: '+PROJECT+'\nWorking directory: '+REPO]
 if raw.get('retained_schema_excerpts'):
  sections.append('Retained visible tool-schema output from the prior conversation:\n'+json.dumps(raw['retained_schema_excerpts'],ensure_ascii=False))
 if case['retained_visible_context']:
  sections.append('Retained visible tool results from the prior conversation:\n'+json.dumps(case['retained_visible_context'],ensure_ascii=False))
 sections.append(case['question']);return '\n\n'.join(sections)
def address(variant,cid):
 assert variant and '/' not in variant and variant not in ['.','..'];case_by_id(cid)
 return SCRATCH/'prepared'/variant/cid

def seal_environment(base,m,api):
 # No credentials are read or hashed. Existing proven profiles remain unchanged.
 executable_paths={'python':sys.executable,'cli':api.CODEX,'node':api.NODE,'rg':api.RG}
 m['runtime']=runtime()
 m['frozen_executables']={name:{'path':str(Path(path)),'resolved_path':str(Path(path).resolve()),'sha256':sha(Path(path).resolve())} for name,path in executable_paths.items()}
 launch_files=[Path(m['home'])/'config.toml',base/'proxy-actor.json',base/'bin-actor/tea-rags',base/'lib/codex61/metadata-table-schemas.json']
 m['launch_files_sha256']={str(path.resolve()):sha(path) for path in launch_files}
 m['corpus_inventory_sha256']=sha(ARCHIVE/'corpus-readable-inventory.json')
 m['runner_sha256']=sha(Path(__file__))
 return m

def verify_environment_seal(m):
 assert runtime()==m['runtime'],'Python runtime identity changed'
 for name,record in m['frozen_executables'].items():
  path=Path(record['path'])
  assert str(path.resolve())==record['resolved_path'],'Executable target changed: '+name
  assert sha(path.resolve())==record['sha256'],'Executable binary changed: '+name
 assert m['frozen_executables']['cli']['sha256']==m['cli_sha256'],'CLI fingerprint disagrees with native preparation'
 for path,expected in m['launch_files_sha256'].items():
  assert sha(path)==expected,'Launch/profile file changed: '+path
 assert sha(ARCHIVE/'corpus-readable-inventory.json')==m['corpus_inventory_sha256'],'Frozen corpus inventory file changed'

def prepare(variant,cid,marketplace):
 runtime_record=runtime();base=address(variant,cid)
 assert not base.exists(),'Fresh preparation directory required; preserve all earlier attempts'
 base.mkdir(parents=True);(base/'lib').mkdir()
 # No server build or corpus copy: all policy variants call exactly archived A.
 (base/'final-runtime').symlink_to(ARCHIVE/'final-runtime',target_is_directory=True)
 marketplace=Path(marketplace).resolve();assert marketplace.is_dir()
 source_plugin=marketplace/'harness/codex/tea-rags';assert source_plugin.is_dir()
 assert not any(x.is_symlink() for x in source_plugin.rglob('*'))
 shutil.copytree(marketplace,base/'final-marketplace')
 for name in MODULE_NAMES:
  source_module=Path(__file__).with_name(name) if name=='mcp_readiness.py' else ARCHIVE/'lib'/name
  shutil.copy2(source_module,base/'lib'/name)
 (base/'lib/codex61').mkdir();shutil.copy2(ARCHIVE/'lib/codex61/metadata-table-schemas.json',base/'lib/codex61/metadata-table-schemas.json')
 shutil.copy2(ARCHIVE/'upstream-template.json',base/'upstream-template.json')
 # Archived proof probes must exist to test denial rather than ENOENT.
 dump(base/'questions-only.json',[{'id':c['id'],'question':c['question']} for c in load(CASES/'cases.json')['cases']])
 (base/'lib/codex61_runner.py').write_text('# Inert first-byte controller boundary probe; never imported or executed.\n')
 # Minimal controller imports; no old full-run execute path is imported or called.
 sys.path.insert(0,str(base/'lib'));api=module('short_api',base/'lib/codex61_app_rpc.py')
 prep=module('no_model_prepare',ROOT/'.tmp/only-a-benchmark-v4/prepare.py');prep.BASE=base;prep.ROOT=ROOT
 prep.verify_native_cli(api)
 expected=prep.inventory(source_plugin)
 home=base/'home';extra,plugin=prep.setup(api,home,'actor',expected)
 summary=prep.proof(api,home,extra,plugin,home)
 mcp=load(base/'final-proof-A/mcp.json')['data'][0]
 proxy=module('frozen_proxy_check',base/'lib/codex61_mcp_proxy.py')
 assert set(mcp['tools'])==set(proxy.READ_TOOLS) and len(mcp['tools'])==17
 assert proxy.REPO==REPO and proxy.PROJECT==PROJECT
 # Same preserved proxy boundary must deny mutators and cross-project selectors.
 for tool,args in [('index_codebase',{}),('find_symbol',{'project':'wrong','path':REPO}),('find_symbol',{'project':PROJECT,'path':'/tmp'})]:
  try:proxy.guard_call(tool,args)
  except ValueError:pass
  else:raise AssertionError('Frozen boundary accepted forbidden input')
 case=case_by_id(cid);prompt=prompt_for(case)
 (base/'actor-prompt.txt').write_text(prompt)
 manifest={'variant':variant,'case':cid,'runner_sha256':sha(Path(__file__)),'prepared_model_turns':0,'runtime':runtime_record,'source_marketplace':str(marketplace),'plugin_inventory':expected,'plugin_root':str(plugin),'home':str(home),'backend_env':extra,'no_turn_proof':summary,'real_tool_names':sorted(mcp['tools']),'backend_runtime':str(ARCHIVE/'final-runtime'),'project':PROJECT,'cwd':REPO,'model':'gpt-6.1-sol','effort':'medium','n':1,'cases_sha256':sha(CASES/'cases.json'),'grading_sha256':sha(CASES/'grading.json'),'provenance_sha256':sha(CASES/'provenance.json'),'prompt_sha256':sha(base/'actor-prompt.txt'),'backend_frozen_files':{n:h for n,h in load(ARCHIVE/'final-manifest.json')['frozen_files'].items() if n.startswith(str(ARCHIVE/'final-runtime')+'/')},'archive_source_capture_sha256':sha(ARCHIVE/'source-capture.json'),'corpus_inventory_sha256':sha(ARCHIVE/'corpus-readable-inventory.json'),'cli_sha256':sha(api.CODEX),'module_sha256':{n:sha(base/'lib'/n) for n in MODULE_NAMES},'tool_catalog_sha256':sha(base/'final-proof-A/mcp.json'),'native_install_proof':str(base/'actor-native-install.json')}
 dump(base/'manifest.json',manifest)
 # Case/grading/provenance and all controller files remain outside native roots.
 denied=[str(CASES/'grading.json'),str(CASES/'cases.json'),str(CASES/'provenance.json'),str(SCRATCH/'short_native.py'),str(base/'manifest.json'),str(base/'actor-prompt.txt')]
 rpc=api.RPC(home,base/'controller-denial-proof',extra_env=extra,allow_model_turns=False)
 try:
  code='paths='+repr(denied)+'\nfor p in paths:\n try:\n  open(p,"rb").read(1); print("ALLOWED")\n except OSError as e: print("DENIED",e.errno)'
  result=rpc.call('command/exec',{'command':[str(Path(sys.executable).resolve()),'-c',code],'cwd':REPO,'permissionProfile':'benchmark','timeoutMs':10000})
  assert result['stdout'].count('DENIED 1')==len(denied),result
  dump(base/'controller-denial-proof/result.json',result)
 finally:rpc.close()
 seal_environment(base,manifest,api)
 dump(base/'manifest.json',manifest)
 print(json.dumps({'prepared':str(base),'manifest_sha256':sha(base/'manifest.json'),'model_turns':0,'tools':17,'skills':18,'hooks':14}))

def validate(base,m):
 assert sha(Path(__file__))==m['runner_sha256'],'Reviewed short controller changed'
 assert sha(Path(__file__).with_name('mcp_readiness.py'))==m['module_sha256']['mcp_readiness.py'],'Readiness helper changed'
 verify_environment_seal(m)
 assert m['model']=='gpt-6.1-sol' and m['effort']=='medium' and m['n']==1 and m['prepared_model_turns']==0
 assert sha(CASES/'cases.json')==m['cases_sha256'] and sha(CASES/'grading.json')==m['grading_sha256'] and sha(CASES/'provenance.json')==m['provenance_sha256']
 assert sha(base/'actor-prompt.txt')==m['prompt_sha256']
 assert sha(base/'final-proof-A/mcp.json')==m['tool_catalog_sha256'],'Native catalog proof changed'
 assert inventory(Path(m['plugin_root']))==m['plugin_inventory']
 for name,h in m['module_sha256'].items():assert sha(base/'lib'/name)==h
 assert sha(ARCHIVE/'source-capture.json')==m['archive_source_capture_sha256']
 for name,h in m['backend_frozen_files'].items():assert sha(name)==h,'Frozen A backend changed: '+name
 # Full corpus inventory exactly once per short actor, outside measured model turn.
 sys.path.insert(0,str(ARCHIVE/'lib'));old=module('frozen_corpus_inventory',ARCHIVE/'lib/codex61_runner.py')
 assert old.corpus_inventory()==load(ARCHIVE/'corpus-readable-inventory.json')
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()=='f88b42f3c286815ea43b464960205d56445ee2e6'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).strip()

def slot():
 # At most two concurrent native actors across this entire scratch harness.
 handles=[]
 for n in [1,2]:
  f=(SCRATCH/f'actor-slot-{n}.lock').open('a')
  try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);return f
  except BlockingIOError:f.close()
 raise RuntimeError('Two native actors already active; caller must wait, no extra actor launched')

def run(variant,cid,rootgo):
 runtime();base=address(variant,cid);m=load(base/'manifest.json');go=load(rootgo)
 assert go.get('ROOTGO') is True and go.get('model')=='gpt-6.1-sol' and go.get('effort')=='medium' and go.get('n')==1
 authorized=go.get('authorized',[])
 assert {'variant':variant,'case':cid,'manifest_sha256':sha(base/'manifest.json')} in authorized,'Root must authorize exact prepared manifest'
 assert go.get('cases_sha256')==m['cases_sha256'] and go.get('grading_sha256')==m['grading_sha256']
 validate(base,m)
 out=base/'actor';assert not out.exists(),'Never rerun/overwrite native actor; retain failed attempts'
 lock=slot();out.mkdir()
 sys.path.insert(0,str(base/'lib'));api=module('live_short_api',base/'lib/codex61_app_rpc.py');protocol=module('live_short_protocol',base/'lib/protocol.py')
 rpc=api.RPC(Path(m['home']),out,extra_env=m['backend_env'],allow_model_turns=True);started=time.monotonic()
 try:
  assert not (Path(m['home'])/'sessions').exists(),'Fresh home/thread required'
  thread=rpc.call('thread/start',{'cwd':REPO,'model':'gpt-6.1-sol','permissions':'benchmark','approvalPolicy':'never','ephemeral':False,'experimentalRawEvents':True})
  assert thread['model']=='gpt-6.1-sol' and thread['reasoningEffort']=='medium' and not thread.get('instructionSources')
  assert thread['activePermissionProfile']['id']=='benchmark';dump(out/'thread-start.json',thread)
  readiness=wait_for_mcp_ready(rpc,thread['thread']['id'],m['real_tool_names'])
  dump(out/'mcp-before-turn.json',readiness)
  turn=rpc.call('turn/start',{'threadId':thread['thread']['id'],'cwd':REPO,'permissions':'benchmark','approvalPolicy':'never','model':'gpt-6.1-sol','effort':'medium','input':[{'type':'text','text':(base/'actor-prompt.txt').read_text()}]})
  # Canonical RPC JSONL is flushed per event. No optional JSON rewrite callback.
  result=protocol.await_turn(rpc,turn['turn']['id'],timeout=1200)
  events=result.pop('events');requests=result.pop('requests');dump(out/'events-final.json',events)
  if requests:dump(out/'unanswered-user-requests.json',requests)
  pricing=load(ARCHIVE/'verified-api-pricing.json');pricing=pricing.get('pricing',pricing)
  needed={'input','cached','output','long_context_threshold','long_input_multiplier','long_output_multiplier'}
  accounting=protocol.account_events(events,pricing=pricing if needed<=set(pricing) else None)
  finals=[e['params']['item']['text'] for e in events if e.get('method')=='item/completed' and (e.get('params',{}).get('item') or {}).get('type')=='agentMessage' and e['params']['item'].get('phase')=='final_answer']
  (out/'answer.txt').write_text('\n\n'.join(finals)+'\n')
  dump(out/'observations.json',{'case':cid,'variant':variant,'model':'gpt-6.1-sol','effort':'medium','n':1,'runtime':m['runtime'],'status':result,'wall_seconds':time.monotonic()-started,'accounting':accounting,'outcomes':protocol.turn_outcomes(events),'quality':'UNREVIEWED','efficiency':'UNREVIEWED; schema-only setup responses must be identified separately, included in total','manifest_sha256':sha(base/'manifest.json'),'rootgo_sha256':sha(rootgo),'case_sha256':m['cases_sha256'],'grading_sha256':m['grading_sha256'],'readiness_protocol':'same-thread-native-inventory-v1','readiness_wall_seconds':readiness['wall_seconds'],'limitations':['Same-thread readiness does not itself prove code-mode ALL_TOOLS projection','CLI fallback remains unavailable under the preserved shell/deny profile; native MCP tools are the positive route','Single short-context replay, may be NO_REPRO','No private reasoning text used for grading','Model/network residual not attributed to plugin']})
  print(json.dumps({'case':cid,'variant':variant,'responses':accounting['completed_responses'],'status':result['status'],'out':str(out)}))
 except BaseException as e:
  dump(out/'failure.json',{'error':str(e),'raw_journal':'events.jsonl','retry':False,'quality':'OPEN','partial_usage':'UNKNOWN until canonical journal reviewed'});raise
 finally:rpc.close();lock.close()

if __name__=='__main__':
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True)
 for name in ['prepare','run']:
  s=sub.add_parser(name);s.add_argument('--variant',required=True);s.add_argument('--case',required=True)
  if name=='prepare':s.add_argument('--marketplace',required=True)
  else:s.add_argument('--rootgo',required=True)
 a=p.parse_args()
 if a.mode=='prepare':prepare(a.variant,a.case,a.marketplace)
 else:run(a.variant,a.case,a.rootgo)
