# Queued policy comparative verdict

Recommendation: **do not adopt this replacement as a demonstrated fix**. Central Q21 ready-group deferral remains open.

| Case | Baseline → queued responses | Source waves | Factual completeness | Result |
|---|---:|---:|---|---|
| C-Q35-missing-helper-body | 5 → 5 | 3 → 3 | PASS_FOR_NAMED_RELEVANT_INTERNAL_API_CALLS | CONTROL_PASS_MISSING_HELPER_5_TO_5 |
| C-Q36-new-migration-locators | 6 → 4 | 5 → 3 | PASS_EXPLICIT_MIGRATION_INDEXES_AND_FKS | CONTROL_PASS_IMPROVED_6_TO_4 |
| T-Q02-independent-discovery-literal | 8 → 9 | 6 → 7 | PARTIAL_HISTORY_NOT_ESTABLISHED | NO_REPRO_PRIMARY_CONCURRENCY_BOTH_VARIANTS |
| T-Q21-known-missing-groups | 5 → 6 | 2 → 3 | PASS_REQUESTED_CURRENT_BEHAVIOR | OPEN_TARGET_READY_GROUP_DEFERRAL_PERSISTS |
| T-Q34-held-validation-missing-gem | 3 → 2 | 2 → 1 | PASS_REQUESTED_CURRENT_BEHAVIOR | IMPROVED_OBSERVED_3_TO_2 |

Total27→26 native responses; source waves18→17. Setup counts remain1 catalog-only and3 skill-only. Q21 initial empty live catalog followed by available MCP names is an unresolved setup anomaly, not counted as actor waste.

API-equivalent cost $0.4012748 → $0.4128560. Usage balanced in all5. Cache and source-selection differences limit attribution; timers are descriptive.

Q02 historical activation/original spec use remains PARTIAL/UNKNOWN in both variants despite supported, honest current-state answers. No strict optional-helper checklist or diagnostic response ceiling determines quality. Exact source/native IDs, full visible finals, inventories and transcript hashes are in queued-verdicts.json.
