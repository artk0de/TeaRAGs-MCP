#!/usr/bin/env python3
"""Archive real orchestration outcomes only after root confirms the five-case EOF."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DEST = ROOT / ".claude-plugin/.benchmarks/tool-orchestration/2026-10-30/orchestration-results"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def compressed(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as inp, destination.open("wb") as raw, gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as out:
        shutil.copyfileobj(inp, out)
    with gzip.open(destination, "rb") as check:
        assert hashlib.sha256(check.read()).hexdigest() == sha(source)
    return {"source_sha256": sha(source), "uncompressed_bytes": source.stat().st_size,
            "gzip_sha256": sha(destination), "gzip_bytes": destination.stat().st_size}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--eof-confirmed", action="store_true")
    args = parser.parse_args()
    assert args.eof_confirmed
    manifest = json.loads((BASE / "manifest.json").read_text())
    exits = json.loads((BASE / "worker-exits.json").read_text())
    grade = json.loads((BASE / "grade.json").read_text())
    assert len(exits) == 5 and len(manifest["cases"]) == 5
    assert not DEST.exists(), "Never overwrite prior outcomes"
    DEST.mkdir()
    raw, summary = {}, []
    for meta in manifest["cases"]:
        key, source = meta["key"], Path(meta["directory"])
        actor, target = source / "actor", DEST / "cases" / meta["key"]
        target.mkdir(parents=True)
        status = json.loads((actor / "status.json").read_text())
        assert status["attempt"] == 1
        for name in ("status.json", "thread-start.json", "thread-read.json", "final-answer.txt", "pending-lifecycle.json", "fixture-job-cleanup.json", "unanswered-user-request.json"):
            if (actor / name).exists():
                shutil.copy2(actor / name, target / name)
        for name in ("events.jsonl", "received-timeline.jsonl", "turn-events.json"):
            if (actor / name).exists():
                raw[key + "/" + name] = compressed(actor / name, target / (name + ".gz"))
        for name in ("fixture.json", "actor-input.json", "fixture-tool-audit.jsonl", "native-install.json"):
            if (source / name).exists():
                shutil.copy2(source / name, target / name)
        shutil.copy2(Path(meta["home"]) / "config.toml", target / "profile.toml")
        for proof_name in ("preflight-no-turn", "preflight-sleep-removed-no-turn"):
            proof = source / proof_name
            if not proof.exists():
                continue
            copy = target / proof_name
            copy.mkdir()
            for name in ("hooks.json", "skills.json", "mcp.json", "thread-start.json", "filesystem-denials.json", "filesystem-allowed.json", "capability-proof.json"):
                if (proof / name).exists():
                    shutil.copy2(proof / name, copy / name)
            if (proof / "tool-catalog.json").exists():
                raw[key + "/" + proof_name + "/tool-catalog.json"] = compressed(proof / "tool-catalog.json", copy / "tool-catalog.json.gz")
        summary.append({"key": key, "runtime_status": status["status"], "wall_seconds": status["wall_seconds"],
                        "pending_state_exercised": status.get("pending_state_exercised"),
                        "sleep_exposed": manifest["profile"]["sleep_tool"][key], "attempt": 1})
    repro = DEST / "repro"
    repro.mkdir()
    for name in ("run.py", "fixture_mcp.py", "archive.py", "case-adaptations.json", "cases-source.json", "source-plugin-sha256.json", "preflight-review.json", "manifest.json", "worker-exits.json", "grade.json"):
        shutil.copy2(BASE / name, repro / name)
    for name in ("grade-o1-o2-independent.json", "grade-o1-o2-independent.md", "grade-o1-o2-independent.py"):
        if (BASE / name).exists():
            shutil.copy2(BASE / name, repro / name)
    shutil.copytree(BASE / "marketplace/harness/codex/tea-rags", DEST / "plugin-snapshot")
    dump(DEST / "summary.json", {"model": manifest["model"], "effort": manifest["effort"], "plugin_version": manifest["plugin_version"],
         "scope": "One fresh native actor per case, five cases, no retries. Private wait/parallel-only snapshot; later metadata edits are outside this snapshot.",
         "pending_protocol": manifest["pending_protocol"], "cases": summary, "grade": grade,
         "limitations": ["O1/O2 initial job-start actions are documented prompt adaptations; no fabricated retained handle was seeded.",
                         "FIFO barrier/yield durations exercise waiting behavior and are not a performance benchmark.",
                         "O1/O2/O3 expose clock.sleep; O4/O5 use sleep removal. Native user question requests remain unanswered, with cleanup interruption after the assessment endpoint.",
                         "Agent waiting policy is not exercised by these five cases. No global profile was changed."]})
    dump(DEST / "raw-manifest.json", raw)
    dump(DEST / "archive-verification.json", {"gzip_roundtrip_sha256": True, "no_auth_homes_sessions_or_private_forensics_copied": True})
    dump(DEST / "files-sha256.json", {str(p.relative_to(DEST)): sha(p) for p in sorted(DEST.rglob("*")) if p.is_file()})
    print("ARCHIVED", DEST, flush=True)


if __name__ == "__main__":
    main()
