#!/usr/bin/env python3
"""Extract completed O1/O2 native evidence; never starts or polls an actor."""
import argparse
import json
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text())


def json_lines(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def texts(item):
    output = item.get('output', [])
    if isinstance(output, str):
        return [output]
    return [x.get('text', '') for x in output if isinstance(x, dict)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-eof', action='store_true', help='Root has confirmed all five worker EOF')
    args = parser.parse_args()
    assert args.root_eof, 'Wait for explicit root EOF; do not read partial actor traces'
    exits = load(BASE / 'worker-exits.json')
    assert len(exits) == 5 and len({x['key'] for x in exits}) == 5, 'Five terminal workers required'
    manifest = load(BASE / 'manifest.json')
    results = []
    for meta in manifest['cases']:
        if not meta['key'].startswith(('O1', 'O2')):
            continue
        directory = Path(meta['directory'])
        actor = directory / 'actor'
        status = load(actor / 'status.json')
        assert status['attempt'] == 1 and status.get('turn_id'), 'One native actor attempt required'
        events = json_lines(actor / 'events.jsonl')
        native_items = [e['params']['item'] for e in events if e.get('method') == 'item/completed']
        raw_items = [e['params']['item'] for e in events if e.get('method') == 'rawResponseItem/completed']
        calls = [x for x in raw_items if x.get('type') in ('custom_tool_call', 'function_call')]
        outputs = {x.get('call_id'): x for x in raw_items if x.get('type') in ('custom_tool_call_output', 'function_call_output')}
        wrappers = []
        for call in calls:
            output = outputs.get(call.get('call_id'), {})
            wrappers.append({'id': call.get('id'), 'call_id': call.get('call_id'),
                             'name': call.get('name'), 'input': call.get('input', call.get('arguments')),
                             'output_id': output.get('id'), 'delivered_output': texts(output)})
        audit = json_lines(directory / 'fixture-tool-audit.jsonl')
        lifecycle = load(actor / 'pending-lifecycle.json') if (actor / 'pending-lifecycle.json').exists() else []
        pending = next((x for x in lifecycle if x['event'] == 'actual_native_pending_observed'), None)
        release = next((x for x in lifecycle if x['event'] == 'controller_fifo_released'), None)
        job_events = [x for x in audit if x.get('event') in ('job_start', 'job_ready', 'job_end')]
        ready = next((x for x in job_events if x['event'] == 'job_ready'), None)
        delivered = '\n'.join(text for wrapper in wrappers for text in wrapper['delivered_output'])
        tool_items = [x for x in native_items if x.get('type') in ('mcpToolCall', 'commandExecution')]
        answers = [x for x in native_items if x.get('type') == 'agentMessage' and x.get('phase') == 'final_answer']
        flags = []
        for call in wrappers:
            source = str(call.get('input', ''))
            if re.search(r'(?:setTimeout|Atomics\.wait|time\.sleep|clock[_.]sleep|\bsleep\s*\()', source):
                flags.append({'id': call['id'], 'reason': 'Potential delay in executed code; inspect purpose, not returned source text', 'input': source})
            if call.get('name') in ('sleep', 'clock.sleep'):
                flags.append({'id': call['id'], 'reason': 'Native sleep call'})
        checks = {
            'completed_once': status.get('status') == 'completed' and status['attempt'] == 1,
            'one_native_turn': sum(e.get('method') == 'turn/started' for e in events) == 1,
            'all_event_thread_ids_match': all(e.get('params', {}).get('threadId', status['thread_id']) == status['thread_id'] for e in events),
            'actual_pending_and_release': bool(pending and release and pending['monotonic_ns'] <= release['monotonic_ns']),
            'job_ready_before_release_if_MCP_job': bool(ready and release and ready['monotonic_ns'] < release['monotonic_ns']) if meta['key'].startswith('O1') else None,
            'single_MCP_fixture_job_if_O1': len([x for x in job_events if x['event'] == 'job_start']) == 1 if meta['key'].startswith('O1') else None,
            'clock_delay_flags_for_manual_review': flags,
        }
        expected = {'checked': 4, 'missing': ['billing.retry']} if meta['key'].startswith('O1') else {'valid': 3, 'rejected': 1}
        results.append({'case': meta['key'], 'status': status, 'observations': checks,
                        'pending_lifecycle': lifecycle, 'MCP_job_events': job_events,
                        'native_tool_items': tool_items, 'wrappers': wrappers,
                        'expected_result': expected, 'answers': answers,
                        'expected_fact_strings_delivered': {str(x): str(x) in delivered for x in expected.values()},
                        'manual_review_required': 'Confirm exact pending-call/job association, matching wait/write_stdin IDs, terminal output bytes after release, single process start, no restarts/delays, and answer semantics. This extractor does not award PASS from a runner status flag.'})
    assert len(results) == 2
    output = BASE / 'grade-o1-o2-independent.json'
    output.write_text(json.dumps({'independent_reviewer': '/root/eval_architecture_gate',
                                 'root_EOF_confirmed': True, 'cases': results}, indent=2) + '\n')
    for result in results:
        print(result['case'], json.dumps(result['observations']))
    print('Evidence:', output)


if __name__ == '__main__':
    main()
