# Independent O1/O2 completed-trace review

**O2 PASS; O1 INCONCLUSIVE_HARNESS_FAILURE. No actor wait-policy failure is established.** Only saved completed traces/proofs were read. No actor was started or retried by this reviewer.

## O1: controller missed a real native pending cell

The actor started `verify_route_contracts` once in wrapper `ctc_061422f02d0f19f5016ae4ef47c7cc819197f9ba7a56bb90cc`, call `call_63d8acb5803d403a96da256c41b03cb9`. MCP metadata links it to thread `01a18e46-6cad-7022-90c1-8ede62e72e30` and turn `01a18e46-6d33-7401-9afb-0ca2a4cd4a12`. Job audit records one start and one `ORCH_JOB_READY 391` for PID391.

Native output `ctco_01a18e47-2b76-7d51-99c4-2d8a0c752f67` is a **string**, `Script running with cell ID 2`. Executed runner `output_texts()` handled only arrays of text blocks and silently discarded it. Consequently, no assessment `controller_fifo_released` event occurred; the only release was `cleanup_fifo_released` after the180.176-second timeout.

The actor correctly issued **nine native wait calls, all with cell_id2**, with ordinary native yield timeouts. It never restarted the job or used clock/shell/JS delays. It received no completion bytes and gave no final result, so full-case PASS would be false. The observed correct wait choice is partial evidence; completion coverage is invalidated by the controller defect. Raw attempt/status artifacts remain unchanged, and no rerun was requested.

## O2: real pending session, exact resume and grounded output

One command `exec-ad7043eb-089b-4935-aa84-4fd3bf475d9a` ran `python3 jobs/validate_export.py`. Initial wrapper call `call_e808246e4d9949b5b7bf6e481e122033` delivered real session **69338** and `ORCH_JOB_READY 205` in output `ctco_01a18e46-8ced-79a3-bd22-42446a6dbedb`.

The ready output was received at monotonic **72948731421208**, followed by pending observation **72948731689958**, then FIFO release **72948731759125**. The actor then used `write_stdin(session_id:69338, chars:"")` in wrapper `ctc_097670bfb55bba14016ae4ef4270348191babd4a72d6650780`. Actual delivered output `ctco_01a18e46-9d01-7123-af35-8c9cc3532b9f` has exit_code0 and `{"valid":3,"rejected":1}`. The final answer states3 valid rows and1 rejected row. All calls use the same actor thread/turn. No restart, clock or synthetic delay occurred.

Both capability proofs show **clock.sleep available**, alongside native wait/write_stdin. Thus O2 exercises native-resume choice with clock present. Neither single case is a performance comparison. Exact IDs, source bytes, native tool outputs and per-check evidence are retained in `grade-o1-o2-independent.json`.
