#!/usr/bin/env python3
"""Fresh native orchestration cases. Preparation forbids model turns; run needs ROOTGO."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import queue
import re
import shutil
import signal
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
spec = importlib.util.spec_from_file_location("orchestration_helpers", ROOT / ".tmp/plugin-routing-evals/run.py")
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.BASE = BASE
original_config = helper.write_config


def profile(meta, plugin, toolbin):
    original_config(meta, plugin, toolbin)
    path = Path(meta["home"]) / "config.toml"
    sleep = "true" if meta["key"].startswith(("O1", "O2", "O3")) else "false"
    text = path.read_text().replace("[features]\n", "[features]\nsleep_tool = " + sleep + "\ndefault_mode_request_user_input = true\nunified_exec = true\n", 1)
    path.write_text(text)


helper.write_config = profile


class QuestionRPC(helper.transport.RPC):
    """Questions remain pending for a real user; approval requests are refused."""
    def __init__(self, *args, **kwargs):
        self.user_requests = []
        super().__init__(*args, **kwargs)

    def next(self, timeout=180):
        event = self.q.get(timeout=timeout)
        if "_process_exit" in event:
            raise RuntimeError("app-server exited " + str(event))
        if "method" in event and "id" in event:
            if event["method"] == "item/tool/requestUserInput":
                self.user_requests.append(event)
            else:
                self.send({"id": event["id"], "error": {"code": -32000, "message": "Eval approval/server requests disabled"}})
        return event


helper.transport.RPC = QuestionRPC


def tool_names(catalog):
    names, descriptions = [], {}
    def visit(items, prefix=""):
        for item in items:
            name = prefix + item.get("name", "")
            if item.get("type") == "namespace":
                visit(item.get("tools", []), name + ".")
            else:
                names.append(name)
                descriptions[name] = item.get("description", "")
    for item in catalog:
        if item.get("type") == "additional_tools":
            visit(item.get("tools", []))
    return names, descriptions


def catalog_proof(meta):
    out = Path(meta["directory"]) / "preflight-no-turn"
    env = helper.native_env(meta["home"], Path(meta["directory"]) / "backend-bin")
    result = subprocess.run([helper.CODEX, "debug", "prompt-input"], cwd=meta["cwd"], env=env, capture_output=True, text=True, timeout=120)
    (out / "tool-catalog.json").write_text(result.stdout)
    (out / "tool-catalog.stderr").write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    names, descriptions = tool_names(json.loads(result.stdout))
    sleep_expected = meta["key"].startswith(("O1", "O2", "O3"))
    assert ("clock.sleep" in names) == sleep_expected
    assert "functions.wait" in names and "functions.exec" in names
    assert "functions.request_user_input" in names and "functions.request_user_input_async" in names
    assert "write_stdin" in descriptions["functions.exec"]
    proof = {"clock_sleep_present": sleep_expected, "native_wait_present": True, "native_write_stdin_declared": True,
             "user_question_tools_present": True, "model_turns": 0, "tool_names": names}
    helper.dump(out / "capability-proof.json", proof)
    return proof


def adjust_profiles():
    manifest = json.loads((BASE / "manifest.json").read_text())
    assert not manifest["ROOTGO"] and manifest.get("preparation_complete")
    assert not any((Path(m["directory"]) / "actor").exists() for m in manifest["cases"])
    for meta in manifest["cases"]:
        if not meta["key"].startswith(("O1", "O2", "O3")):
            continue
        directory = Path(meta["directory"])
        shutil.move(str(directory / "preflight-no-turn"), str(directory / "preflight-sleep-removed-no-turn"))
        config = Path(meta["home"]) / "config.toml"
        old = config.read_text()
        assert old.count("sleep_tool = false") == 1
        config.write_text(old.replace("sleep_tool = false", "sleep_tool = true", 1))
        meta["preflight"] = helper.preflight(meta)
        meta["capability_proof"] = catalog_proof(meta)
        meta["config_sha256"] = helper.sha(config)
        print("ADJUSTED_NO_MODEL", meta["key"], "sleep available; wait/questions preserved", flush=True)
    manifest["profile"]["sleep_tool"] = {m["key"]: m["key"].startswith(("O1", "O2", "O3")) for m in manifest["cases"]}
    manifest["sleep_capability_note"] = "O1/O2/O3 assess instruction choice with clock.sleep exposed. O4/O5 use the separately proven future sleep removal mitigation. Earlier false no-turn proofs preserved."
    manifest["runner_sha256"] = helper.sha(__file__)
    helper.dump(BASE / "manifest.json", manifest)


def cleanup_fixture_jobs(meta, out):
    candidates = set()
    audit = Path(meta["directory"]) / "fixture-tool-audit.jsonl"
    if audit.exists():
        for line in audit.open():
            row = json.loads(line)
            if row.get("event") == "job_start" and row.get("pid"):
                candidates.add(int(row["pid"]))
    events = out / "events.jsonl"
    if events.exists():
        for line in events.open():
            candidates.update(int(x) for x in re.findall(r"ORCH_JOB_READY[ \t]+([0-9]+)", line))
    records = []
    for pid in sorted(candidates):
        command = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True)
        match = command.returncode == 0 and meta.get("job_path", "__no_job__") in command.stdout
        cwd_match = False
        if match:
            cwd = subprocess.run(["/usr/sbin/lsof", "-a", "-p", str(pid), "-d", "cwd", "-Fn"], capture_output=True, text=True)
            cwd_match = "n" + meta["cwd"] in cwd.stdout.splitlines()
        record = {"pid": pid, "command_matches_fixture_job": match, "cwd_matches_case": cwd_match, "terminated": False}
        if match and cwd_match:
            try:
                os.kill(pid, signal.SIGTERM)
                record["terminated"] = True
            except ProcessLookupError:
                record["already_exited"] = True
        records.append(record)
    helper.dump(out / "fixture-job-cleanup.json", records)


def prepare():
    assert not (BASE / "manifest.json").exists(), "Fresh preparation only"
    snapshot = BASE / "marketplace/harness/codex/tea-rags"
    inventory = json.loads((BASE / "source-plugin-sha256.json").read_text())
    assert helper.inventory(snapshot) == inventory
    assert json.loads((snapshot / ".codex-plugin/plugin.json").read_text())["version"] == "0.53.9"
    cases = json.loads((BASE / "cases-source.json").read_text())["evals"]
    manifest = {"ROOTGO": False, "model": "gpt-6.1-sol", "effort": "medium", "plugin_version": "0.53.9",
                "source_plugin_sha256": inventory, "fixture_server_sha256": helper.sha(BASE / "fixture_mcp.py"),
                "helper_sha256": helper.sha(ROOT / ".tmp/plugin-routing-evals/run.py"), "runner_sha256": helper.sha(__file__),
                "case_source_sha256": helper.sha(BASE / "cases-source.json"), "cases": [], "max_workers": 2,
                "profile": {"sleep_tool": False, "default_mode_request_user_input": True, "unified_exec": True},
                "retry_policy": "One actor turn per case, no repeats, coaching or fabricated handles. Pending cases may be NOT_EXERCISED/UNSUPPORTED.",
                "question_handling": "Native question requests are retained unanswered; no canned human answer and no denial. An observed request is an awaiting-user assessment endpoint.",
                "pending_protocol": "Actor itself starts one real FIFO-barrier job in the same native runtime. Controller releases after observing actual native pending output, independently of subsequent tool choice. No sleep, timer or polling release.",
                "original_cases_adapted": "O1/O2 add only the initial user action to start the provided job; their pending-state boundary then arises within the same actor turn. Original fixture facts and assessed outputs are unchanged."}
    helper.dump(BASE / "manifest.json", manifest)
    adaptations = {}
    for case in cases:
        key = case["id"]
        directory = BASE / "cases" / key
        directory.mkdir(parents=True)
        raw = json.loads(json.dumps(case))
        if key.startswith("O1"):
            raw["prompt"] = "Run the provided verify_route_contracts tool once. Give me its completed result: how many routes were checked, and which route is missing?"
        elif key.startswith("O2"):
            raw["prompt"] = "Run jobs/validate_export.py once. Report how many rows are valid and how many were rejected when the job finishes."
        adaptations[key] = {"original_prompt": case["prompt"], "runtime_prompt": raw["prompt"], "setup_model_turns": 0, "assessed_model_turns": 1}
        meta = helper.compile_case("orchestration", raw, directory)
        meta["key"] = key
        if key.startswith(("O1", "O2")):
            gate = Path(meta["cwd"]) / ".events/release.fifo"
            gate.parent.mkdir()
            os.mkfifo(gate)
            job = "jobs/check_routes.py" if key.startswith("O1") else "jobs/validate_export.py"
            path = Path(meta["cwd"]) / job
            barrier = 'import os\nprint("ORCH_JOB_READY", os.getpid(), flush=True)\nwith open(".events/release.fifo", "rb", buffering=0) as gate:\n    gate.read(1)\n'
            path.write_text(barrier + path.read_text())
            compiled = json.loads((directory / "fixture.json").read_text())
            compiled["job_path"] = job
            compiled["files"][job] = path.read_text()
            helper.dump(directory / "fixture.json", compiled)
            meta.update(gate_path=str(gate), job_path=job, fixture_sha256=helper.sha(directory / "fixture.json"))
        helper.install_and_trust(meta, BASE / "marketplace", "0.53.9", inventory)
        meta["preflight"] = helper.preflight(meta)
        meta["capability_proof"] = catalog_proof(meta)
        meta["config_sha256"] = helper.sha(Path(meta["home"]) / "config.toml")
        meta["workspace_files_sha256"] = {str(p.relative_to(meta["cwd"])): helper.sha(p) for p in Path(meta["cwd"]).rglob("*") if p.is_file()}
        manifest["cases"].append(meta)
        helper.dump(BASE / "manifest.json", manifest)
        print("PREFLIGHT", key, "trusted+connected; sleep removed; wait/questions preserved; zero actors", flush=True)
    helper.dump(BASE / "case-adaptations.json", adaptations)
    manifest["preparation_complete"] = True
    helper.dump(BASE / "manifest.json", manifest)
    print("PREPARED_NO_MODELS", BASE, flush=True)


def output_texts(event):
    if event.get("method") != "rawResponseItem/completed":
        return []
    item = event.get("params", {}).get("item", {})
    if item.get("type") != "custom_tool_call_output":
        return []
    return [x.get("text", "") for x in item.get("output", []) if isinstance(x, dict)]


def worker(key):
    manifest = json.loads((BASE / "manifest.json").read_text())
    assert manifest.get("ROOTGO") is True
    assert helper.sha(BASE / "fixture_mcp.py") == manifest["fixture_server_sha256"]
    assert helper.sha(ROOT / ".tmp/plugin-routing-evals/run.py") == manifest["helper_sha256"]
    meta = next(x for x in manifest["cases"] if x["key"] == key)
    directory, out = Path(meta["directory"]), Path(meta["directory"]) / "actor"
    out.mkdir()
    assert helper.sha(directory / "actor-input.json") == meta["actor_input_sha256"]
    assert helper.sha(directory / "fixture.json") == meta["fixture_sha256"]
    assert helper.sha(Path(meta["home"]) / "config.toml") == meta["config_sha256"]
    assert helper.inventory(Path(meta["plugin"])) == manifest["source_plugin_sha256"]
    gate_fd = os.open(meta["gate_path"], os.O_RDWR | os.O_NONBLOCK) if meta.get("gate_path") else None
    rpc = helper.rpc_for(meta, out, allow=True)
    started, events, lifecycle = time.monotonic(), [], []
    status = {"key": key, "attempt": 1, "model": "gpt-6.1-sol", "effort": "medium", "valid_runtime": False,
              "actor_input_sha256": meta["actor_input_sha256"], "setup_model_turns": 0, "assessed_model_turns": 1}
    pending = None
    def observe(event):
        nonlocal pending
        texts = output_texts(event)
        found = None
        if texts and key.startswith("O1"):
            match = re.match(r"^Script running with cell ID ([A-Za-z0-9:_-]+)", texts[0])
            if match:
                found = {"kind": "exec_cell", "cell_id": match[1], "call_id": event["params"]["item"].get("call_id")}
        elif texts and key.startswith("O2"):
            for text in texts[1:]:
                try:
                    result = json.loads(text)
                except ValueError:
                    continue
                if isinstance(result, dict) and result.get("session_id") is not None and "ORCH_JOB_READY" in str(result.get("output", "")):
                    found = {"kind": "unified_session", "session_id": result["session_id"], "call_id": event["params"]["item"].get("call_id")}
        if found and pending is None:
            pending = found
            lifecycle.append({"event": "actual_native_pending_observed", "monotonic_ns": time.monotonic_ns(), **found})
            os.write(gate_fd, b"1")
            lifecycle.append({"event": "controller_fifo_released", "monotonic_ns": time.monotonic_ns(), "reason": "Actual native pending output observed; independent of actor's next tool choice"})
            helper.dump(out / "pending-lifecycle.json", lifecycle)
    try:
        thread = rpc.call("thread/start", {"cwd": meta["cwd"], "model": "gpt-6.1-sol", "permissions": "routing_eval", "approvalPolicy": "never", "ephemeral": False, "experimentalRawEvents": True})
        helper.dump(out / "thread-start.json", thread)
        assert thread["model"] == "gpt-6.1-sol" and thread["reasoningEffort"] == "medium" and thread["activePermissionProfile"]["id"] == "routing_eval"
        tid = thread["thread"]["id"]
        status["thread_id"] = tid
        actor = json.loads((directory / "actor-input.json").read_text())
        turn = rpc.call("turn/start", {"threadId": tid, "cwd": meta["cwd"], "permissions": "routing_eval", "approvalPolicy": "never", "model": "gpt-6.1-sol", "effort": "medium", "input": [{"type": "text", "text": actor["text"]}]})
        turn_id = turn["turn"]["id"]
        status["turn_id"] = turn_id
        events, rpc.pending = rpc.pending, []
        for event in events:
            observe(event)
        deadline, completed, question = time.monotonic() + 180, None, None
        while time.monotonic() < deadline:
            completed = next((e for e in events if e.get("method") == "turn/completed" and e.get("params", {}).get("turn", {}).get("id") == turn_id), None)
            question = next((e for e in events if e.get("method") == "item/tool/requestUserInput" and "id" in e), None)
            if completed or question:
                break
            try:
                event = rpc.next(timeout=min(30, max(1, deadline - time.monotonic())))
                events.append(event)
                observe(event)
            except queue.Empty:
                continue
        if question:
            status.update(status="awaiting_user", valid_runtime=True, human_answers_supplied=0)
            helper.dump(out / "unanswered-user-request.json", question)
            # Assessment ends at the real unanswered request; cancel transport cleanup only.
            rpc.call("turn/interrupt", {"threadId": tid, "turnId": turn_id}, timeout=10)
        elif completed:
            status.update(status=completed["params"]["turn"]["status"], valid_runtime=completed["params"]["turn"]["status"] == "completed")
        else:
            rpc.call("turn/interrupt", {"threadId": tid, "turnId": turn_id}, timeout=10)
            status.update(status="timeout", valid_runtime=False)
        helper.dump(out / "turn-events.json", events)
        state = rpc.call("thread/read", {"threadId": tid, "includeTurns": True})
        helper.dump(out / "thread-read.json", state)
        answers = [i.get("text", "") for t in state.get("thread", {}).get("turns", []) for i in t.get("items", []) if i.get("type") == "agentMessage" and i.get("phase") == "final_answer"]
        (out / "final-answer.txt").write_text("\n\n".join(answers))
        status["pending_state_exercised"] = pending is not None if gate_fd is not None else None
        if gate_fd is not None and pending is None:
            status["limitation"] = "No faithful native pending handle observed; pending-state criterion is NOT_EXERCISED, never PASS"
    except BaseException as error:
        status.update(status="runtime_error", error=str(error))
    finally:
        status["wall_seconds"] = round(time.monotonic() - started, 3)
        helper.dump(out / "status.json", status)
        if gate_fd is not None:
            if pending is None:
                os.write(gate_fd, b"1")
                lifecycle.append({"event": "cleanup_fifo_released", "monotonic_ns": time.monotonic_ns(), "reason": "Unblock real job during cleanup, never counted as successful assessment completion"})
                helper.dump(out / "pending-lifecycle.json", lifecycle)
        helper.close_rpc(rpc)
        if gate_fd is not None:
            os.close(gate_fd)
            cleanup_fixture_jobs(meta, out)
    print("CASE", key, status["status"], status["wall_seconds"], "seconds", flush=True)
    return 0 if status["valid_runtime"] else 1


def execute(rootgo):
    assert rootgo, "Root review/GO required"
    manifest = json.loads((BASE / "manifest.json").read_text())
    assert manifest.get("preparation_complete") and len(manifest["cases"]) == 5
    assert not any((Path(m["directory"]) / "actor").exists() for m in manifest["cases"]), "Never retry an actor"
    manifest["ROOTGO"] = True
    manifest["execution_runner_sha256"] = helper.sha(__file__)
    helper.dump(BASE / "manifest.json", manifest)
    remaining, running, exits = iter(manifest["cases"]), [], []
    while True:
        while len(running) < 2:
            try:
                case = next(remaining)
            except StopIteration:
                break
            process = subprocess.Popen([helper.PY, str(BASE / "run.py"), "worker", case["key"]])
            running.append((process, case["key"]))
        if not running:
            break
        # Controller process scheduling only; no actor tool waiting is synthesized.
        finished, wait_status = os.waitpid(-1, 0)
        for process, key in list(running):
            if process.pid == finished:
                process.returncode = os.waitstatus_to_exitcode(wait_status)
                exits.append({"key": key, "process_reaped": True, "exit_code": process.returncode})
                running.remove((process, key))
                helper.dump(BASE / "worker-exits.json", exits)
    print("RAW_RESULTS", BASE, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="action", required=True)
    subs.add_parser("prepare")
    subs.add_parser("adjust-profiles")
    run = subs.add_parser("run")
    run.add_argument("--rootgo", action="store_true")
    item = subs.add_parser("worker")
    item.add_argument("key")
    args = parser.parse_args()
    if args.action == "prepare":
        prepare()
    elif args.action == "adjust-profiles":
        adjust_profiles()
    elif args.action == "run":
        execute(args.rootgo)
    else:
        sys.exit(worker(args.key))
