[`RetryBudget#allows`](src/retry/RetryBudget.ts:3) permits another retry when `attempt + 1 < maxAttempts`.

| Delivery type | Configured limit | Attempt 2 | Attempt 4 |
|---|---:|---|---|
| HTTP | [3](config/http_delivery.yml:1) | **No** — `3 < 3` is false | **No** — `5 < 3` is false |
| Webhook | [5](config/webhook_delivery.yml:1) | **Yes** — `3 < 5` is true | **No** — `5 < 5` is false |
