Only **`isolated_preview`** disables timeout retries (`retry_on_timeout: false`). It uses a delay of **0 ms** — [zone_sigma.yml](config/retry/zone_sigma.yml:1).
