The inventory checks **5 routes**. Missing from the registered set:

- `payments.capture`
- `reports.export`
