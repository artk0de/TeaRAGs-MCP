| File | Attempt 0 | Attempt 2 |
|---|---:|---:|
| [src/http/retry.ts](src/http/retry.ts) — `100 * 2 ** attempt` | 100 | 400 |
| [src/webhook/retry.ts](src/webhook/retry.ts) — `300 * 2 ** attempt` | 300 | 1,200 |

The webhook delay is three times the HTTP delay at each attempt.
