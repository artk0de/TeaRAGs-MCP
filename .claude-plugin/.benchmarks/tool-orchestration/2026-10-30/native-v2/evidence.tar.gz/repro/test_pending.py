import unittest

from pending import matching_job, output_texts, pending_exec


# Exact native output shape/text from the preserved O1 attempt.
ACTUAL_PENDING = {
    'method': 'rawResponseItem/completed',
    'params': {'item': {
        'type': 'custom_tool_call_output',
        'id': 'ctco_01a18e47-2b76-7d51-99c4-2d8a0c752f67',
        'call_id': 'call_63d8acb5803d403a96da256c41b03cb9',
        'output': 'Script running with cell ID 2\nWall time 31.0 seconds\nOutput:\n',
    }},
}


class PendingTests(unittest.TestCase):
    def test_actual_native_string_yield_is_detected(self):
        self.assertEqual(output_texts(ACTUAL_PENDING), [ACTUAL_PENDING['params']['item']['output']])
        self.assertEqual(pending_exec(ACTUAL_PENDING)['cell_id'], '2')

    def test_content_blocks_remain_supported(self):
        event = {'method': 'rawResponseItem/completed', 'params': {'item': {
            'type': 'custom_tool_call_output', 'call_id': 'block-call',
            'output': [{'type': 'input_text', 'text': 'Script running with cell ID block-3\n'},
                       {'type': 'input_text', 'text': 'other output'}]}}}
        self.assertEqual(output_texts(event), ['Script running with cell ID block-3\n', 'other output'])
        self.assertEqual(pending_exec(event)['cell_id'], 'block-3')

    def test_native_function_output_string_is_supported(self):
        event = {'method': 'rawResponseItem/completed', 'params': {'item': {
            'type': 'function_call_output', 'call_id': 'wait-call',
            'output': 'Script running with cell ID 2\n'}}}
        self.assertEqual(output_texts(event), ['Script running with cell ID 2\n'])

    def proof_inputs(self):
        candidate = {'cell_id': '2', 'call_id': 'native-call'}
        calls = {'native-call': {'id': 'native-wrapper', 'name': 'exec',
                                'input': 'text(await tools.mcp__tea_rags__verify_route_contracts({}));'}}
        audit = [
            {'event': 'start', 'method': 'tools/call', 'request_id': 7,
             'params': {'name': 'verify_route_contracts', '_meta': {'itemId': 'native-wrapper', 'callId': 'mcp-call'}}},
            {'event': 'job_start', 'pid': 42, 'job': 'jobs/check_routes_v2.py', 'monotonic_ns': 100},
            {'event': 'job_ready', 'pid': 42, 'ready': 'ORCH_JOB_READY 42', 'monotonic_ns': 110},
        ]
        return candidate, calls, audit

    def test_release_proof_links_native_wrapper_to_one_actual_ready_job(self):
        proof = matching_job(*self.proof_inputs())
        self.assertIsNotNone(proof)
        self.assertEqual(proof['job_pid'], 42)
        self.assertEqual(proof['native_mcp_call_id'], 'mcp-call')
        self.assertEqual(proof['job_ready_monotonic_ns'], 110)

    def test_unrelated_cell_cannot_release_validation_job(self):
        candidate, calls, audit = self.proof_inputs()
        audit[0]['params']['_meta']['itemId'] = 'another-wrapper'
        self.assertIsNone(matching_job(candidate, calls, audit))

    def test_actual_mcp_request_link_supports_dynamic_tool_dispatch(self):
        candidate, calls, audit = self.proof_inputs()
        calls['native-call']['input'] = 'text(await tools[selectedName]({}));'
        self.assertIsNotNone(matching_job(candidate, calls, audit))

    def test_absent_job_ready_cannot_release(self):
        candidate, calls, audit = self.proof_inputs()
        self.assertIsNone(matching_job(candidate, calls, audit[:-1]))

    def test_restarted_job_cannot_satisfy_single_job_proof(self):
        candidate, calls, audit = self.proof_inputs()
        audit.append({'event': 'job_start', 'pid': 99})
        self.assertIsNone(matching_job(candidate, calls, audit))


if __name__ == '__main__':
    unittest.main()
