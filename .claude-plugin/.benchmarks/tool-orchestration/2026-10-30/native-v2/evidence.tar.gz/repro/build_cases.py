#!/usr/bin/env python3
"""Prepare three future-only raw cases; never freezes plugins or starts actors."""
import argparse
import copy
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--projection-case', type=Path, help='Optional already source-produced P1 case bundle')
args = parser.parse_args()
old = json.loads((BASE.parent / 'tool-orchestration-evals/cases-source.json').read_text())['evals']
cases = [copy.deepcopy(c) for c in old if c['id'].startswith(('O4-', 'O5-'))]
assert len(cases) == 2
cases.append({
    'id': 'O6-new-route-inventory-pending-control',
    'prompt': 'Run the provided verify_route_contracts tool once. How many routes does this inventory check, and which routes are missing from the registered set?',
    'actor_context': {'cwd': '__FIXTURE_ROOT__', 'project': 'orchestration-fixture', 'messages': []},
    'fixture': {'files': {
        'fixtures/contracts_v2.json': '{"routes":["clients.sync","invoices.send","payments.capture","reports.export","audit.persist"]}\n',
        'fixtures/registered_v2.json': '{"routes":["clients.sync","invoices.send","audit.persist"]}\n',
        'jobs/check_routes_v2.py': 'import json\nfrom pathlib import Path\nexpected = json.loads(Path("fixtures/contracts_v2.json").read_text())["routes"]\nregistered = set(json.loads(Path("fixtures/registered_v2.json").read_text())["routes"])\nprint(json.dumps({"checked": len(expected), "missing": [route for route in expected if route not in registered]}), flush=True)\n',
    }},
    'grading': {
        'required': [
            'One actual native exec cell contains the verify_route_contracts invocation and yields its real runtime cell id. The actor resumes that same cell through native wait; no fabricated or other-runtime handle qualifies.',
            'Controller release must follow actual pending output and a verified same-wrapper MCP request plus one matching job_start/job_ready PID. The stored readiness timestamp precedes controller release. No timer or actor-choice-dependent release.',
            'Exactly one real job is started. Clock is available but the actor uses no clock/shell/JS/Python delay or restart to await it. Native wait yield timeouts are allowed.',
            'Native wait delivers the real terminal completion bytes before the final answer. Reports five checked routes and both missing routes from those bytes.',
        ],
        'expected_result': {'checked': 5, 'missing': ['payments.capture', 'reports.export']},
        'invalid_if': 'No correct same-runtime pending/resume/completion chain or no verified job-ready-before-release; never award PASS from status alone.',
        'new_case_not_retry': 'Distinct five-route/two-missing inventory. Original O1 attempt, files and verdict stay unchanged.'
    }
})
if args.projection_case:
    projection = json.loads(args.projection_case.read_text())
    rows = projection.get('evals', projection.get('cases', []))
    assert len(rows) == 1 and rows[0]['id'].startswith('P1')
    cases += rows
assert len({c['id'] for c in cases}) == len(cases)
(BASE / 'cases-source.json').write_text(json.dumps({'evals': cases}, indent=2) + '\n')
print('BUILT', len(cases), 'future raw cases; no snapshot/preflight/actors')
