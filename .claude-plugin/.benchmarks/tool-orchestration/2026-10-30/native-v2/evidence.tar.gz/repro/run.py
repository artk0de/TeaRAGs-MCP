#!/usr/bin/env python3
"""Future-only O4/O5 and new O6 controls. No actors before fresh preflight and explicit ROOTGO."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import queue
import re
import shutil
import signal
import subprocess
import sys
import time

from pending import matching_job, output_texts, pending_exec

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
spec = importlib.util.spec_from_file_location("orchestration_helpers", ROOT / ".tmp/plugin-routing-evals/run.py")
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.BASE = BASE
original_config = helper.write_config


def profile(meta, plugin, toolbin):
    original_config(meta, plugin, toolbin)
    path = Path(meta["home"]) / "config.toml"
    sleep = "true" if meta["key"].startswith("O6") else "false"
    text = path.read_text().replace("[features]\n", "[features]\nsleep_tool = " + sleep + "\ndefault_mode_request_user_input = true\nunified_exec = true\n", 1)
    path.write_text(text)


helper.write_config = profile


class QuestionRPC(helper.transport.RPC):
    """Questions remain pending for a real user; approval requests are refused."""
    def __init__(self, *args, **kwargs):
        self.user_requests = []
        super().__init__(*args, **kwargs)

    def next(self, timeout=180):
        event = self.q.get(timeout=timeout)
        if "_process_exit" in event:
            raise RuntimeError("app-server exited " + str(event))
        if "method" in event and "id" in event:
            if event["method"] == "item/tool/requestUserInput":
                self.user_requests.append(event)
            else:
                self.send({"id": event["id"], "error": {"code": -32000, "message": "Eval approval/server requests disabled"}})
        return event


helper.transport.RPC = QuestionRPC


def tool_names(catalog):
    names, descriptions = [], {}
    def visit(items, prefix=""):
        for item in items:
            name = prefix + item.get("name", "")
            if item.get("type") == "namespace":
                visit(item.get("tools", []), name + ".")
            else:
                names.append(name)
                descriptions[name] = item.get("description", "")
    for item in catalog:
        if item.get("type") == "additional_tools":
            visit(item.get("tools", []))
    return names, descriptions


def catalog_proof(meta):
    out = Path(meta["directory"]) / "preflight-no-turn"
    env = helper.native_env(meta["home"], Path(meta["directory"]) / "backend-bin")
    result = subprocess.run([helper.CODEX, "debug", "prompt-input"], cwd=meta["cwd"], env=env, capture_output=True, text=True, timeout=120)
    (out / "tool-catalog.json").write_text(result.stdout)
    (out / "tool-catalog.stderr").write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    names, descriptions = tool_names(json.loads(result.stdout))
    sleep_expected = meta["key"].startswith("O6")
    assert ("clock.sleep" in names) == sleep_expected
    assert "functions.wait" in names and "functions.exec" in names
    assert "functions.request_user_input" in names and "functions.request_user_input_async" in names
    assert "write_stdin" in descriptions["functions.exec"]
    proof = {"clock_sleep_present": sleep_expected, "native_wait_present": True, "native_write_stdin_declared": True,
             "user_question_tools_present": True, "model_turns": 0, "tool_names": names}
    helper.dump(out / "capability-proof.json", proof)
    return proof


def cleanup_fixture_jobs(meta, out):
    candidates = set()
    audit = Path(meta["directory"]) / "fixture-tool-audit.jsonl"
    if audit.exists():
        for line in audit.open():
            row = json.loads(line)
            if row.get("event") == "job_start" and row.get("pid"):
                candidates.add(int(row["pid"]))
    events = out / "events.jsonl"
    if events.exists():
        for line in events.open():
            candidates.update(int(x) for x in re.findall(r"ORCH_JOB_READY[ \t]+([0-9]+)", line))
    records = []
    for pid in sorted(candidates):
        command = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True)
        match = command.returncode == 0 and meta.get("job_path", "__no_job__") in command.stdout
        cwd_match = False
        if match:
            cwd = subprocess.run(["/usr/sbin/lsof", "-a", "-p", str(pid), "-d", "cwd", "-Fn"], capture_output=True, text=True)
            cwd_match = "n" + meta["cwd"] in cwd.stdout.splitlines()
        record = {"pid": pid, "command_matches_fixture_job": match, "cwd_matches_case": cwd_match, "terminated": False}
        if match and cwd_match:
            try:
                os.kill(pid, signal.SIGTERM)
                record["terminated"] = True
            except ProcessLookupError:
                record["already_exited"] = True
        records.append(record)
    helper.dump(out / "fixture-job-cleanup.json", records)


def produce_projection(source):
    """Resolve P1 with the actual source export; never reconstruct projected rows."""
    produced = BASE / "source-produced-projection.json"
    proof_path = BASE / "projection-producer-proof.json"
    code = '''
import fs from 'node:fs';
import crypto from 'node:crypto';
import {projectSearchResultPayloads} from './src/core/api/public/dto/payload-projection.ts';
const suite = JSON.parse(fs.readFileSync(process.argv[1], 'utf8'));
const c = suite.evals[0];
const f = c.fixture;
for (const row of f.raw_search_results) {
  if (row.payload.content !== f.files[row.payload.relativePath]) throw new Error('Raw source/fixture mismatch');
}
if (JSON.stringify(f.requested_fields) !== JSON.stringify(['symbolId','content'])) throw new Error('Unexpected requested fields');
const args = structuredClone([f.raw_search_results, f.requested_fields]);
const actual = projectSearchResultPayloads(f.raw_search_results, f.requested_fields);
if (actual.results.length !== args[0].length) throw new Error('Projection changed row count');
actual.results.forEach((row, i) => {
  if (row.id !== args[0][i].id || row.payload?.relativePath !== args[0][i].payload.relativePath) throw new Error('Real production locator missing or row order changed');
});
const decorated = {...f.response_metadata, ...actual};
const message = c.actor_context.messages.find(m => m.result_from_producer);
if (!message) throw new Error('Producer seed missing');
delete message.result_from_producer;
message.result = decorated;
fs.writeFileSync(process.argv[2], JSON.stringify(suite, null, 2) + '\\n');
fs.writeFileSync(process.argv[3], JSON.stringify({export:'projectSearchResultPayloads', optional_mode_omitted:true,
  raw_arguments:args, actual_return:actual, actual_decorated_response:decorated,
  return_sha256:crypto.createHash('sha256').update(JSON.stringify(actual)).digest('hex')}, null, 2) + '\\n');
'''
    result = subprocess.run([helper.NODE, "--import", "tsx", "--input-type=module", "-e", code,
                             str(source), str(produced), str(proof_path)],
                            cwd=ROOT, capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stderr
    proof = json.loads(proof_path.read_text())
    proof.update(source_definition_sha256=helper.sha(source),
                 source_module="src/core/api/public/dto/payload-projection.ts",
                 source_module_sha256=helper.sha(ROOT / "src/core/api/public/dto/payload-projection.ts"),
                 actual_source_import=True, model_turns=0, produced_case_sha256=helper.sha(produced))
    helper.dump(proof_path, proof)
    return produced


def prepare(projection_case=None):
    assert not (BASE / "manifest.json").exists(), "Fresh preparation only; never overwrite actors"
    command = [helper.PY, str(BASE / "build_cases.py")]
    if projection_case:
        command += ["--projection-case", str(produce_projection(projection_case))]
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stderr
    snapshot = BASE / "marketplace/harness/codex/tea-rags"
    assert not snapshot.exists(), "Never overwrite a frozen candidate"
    shipped = ROOT / "harness/codex/tea-rags"
    shutil.copytree(shipped, snapshot)
    inventory = helper.inventory(shipped)
    assert helper.inventory(snapshot) == inventory
    assert json.loads((snapshot / ".codex-plugin/plugin.json").read_text())["version"] == "0.53.9"
    catalog = json.loads((ROOT / ".agents/plugins/marketplace.json").read_text())
    catalog["plugins"] = [p for p in catalog["plugins"] if p["name"] == "tea-rags"]
    (BASE / "marketplace/.agents/plugins").mkdir(parents=True)
    helper.dump(BASE / "marketplace/.agents/plugins/marketplace.json", catalog)
    helper.dump(BASE / "source-plugin-sha256.json", inventory)
    cases = json.loads((BASE / "cases-source.json").read_text())["evals"]
    assert len(cases) in (3, 4) and len({c["id"] for c in cases}) == len(cases)
    old_source = ROOT / ".tmp/tool-orchestration-evals/cases-source.json"
    old_cases = json.loads(old_source.read_text())["evals"]
    repeated = [c for c in cases if c["id"].startswith(("O4-", "O5-"))]
    assert len(repeated) == 2 and all(c == next(o for o in old_cases if o["id"] == c["id"]) for c in repeated)
    manifest = {"ROOTGO": False, "model": "gpt-6.1-sol", "effort": "medium", "plugin_version": "0.53.9",
                "source_plugin_sha256": inventory, "fixture_server_sha256": helper.sha(BASE / "fixture_mcp.py"),
                "helper_sha256": helper.sha(ROOT / ".tmp/plugin-routing-evals/run.py"), "runner_sha256": helper.sha(__file__),
                "pending_parser_sha256": helper.sha(BASE / "pending.py"),
                "case_source_sha256": helper.sha(BASE / "cases-source.json"), "cases": [], "max_workers": 2,
                "profile": {"sleep_tool": "available O6; O4/O5 unchanged absent", "default_mode_request_user_input": True, "unified_exec": True},
                "retry_policy": "One fresh actor turn for each future case; never retry or overwrite any original attempt.",
                "pending_protocol": "Real same-runtime exec cell plus matching MCP wrapper and single-job readiness proof before FIFO release. Strings and content blocks both supported. No sleep, timer or polling release.",
                "provenance": {"original_case_source_sha256": helper.sha(old_source),
                               "original_runner_sha256": helper.sha(ROOT / ".tmp/tool-orchestration-evals/run.py"),
                               "O4_O5_definitions_identical": True,
                               "O6_is_new_inventory": "five routes, two missing; not a retry of O1"}}
    if projection_case:
        manifest["projection_producer"] = json.loads((BASE / "projection-producer-proof.json").read_text())
    helper.dump(BASE / "manifest.json", manifest)
    for case in cases:
        key = case["id"]
        directory = BASE / "cases" / key
        directory.mkdir(parents=True)
        meta = helper.compile_case("orchestration-v2", case, directory)
        meta["key"] = key
        if key.startswith("O6"):
            gate = Path(meta["cwd"]) / ".events/release.fifo"
            gate.parent.mkdir()
            os.mkfifo(gate)
            job = "jobs/check_routes_v2.py"
            path = Path(meta["cwd"]) / job
            barrier = 'import os\nprint("ORCH_JOB_READY", os.getpid(), flush=True)\nwith open(".events/release.fifo", "rb", buffering=0) as gate:\n    gate.read(1)\n'
            path.write_text(barrier + path.read_text())
            compiled = json.loads((directory / "fixture.json").read_text())
            compiled["job_path"] = job
            compiled["files"][job] = path.read_text()
            helper.dump(directory / "fixture.json", compiled)
            meta.update(gate_path=str(gate), job_path=job, fixture_sha256=helper.sha(directory / "fixture.json"))
        helper.install_and_trust(meta, BASE / "marketplace", "0.53.9", inventory)
        meta["preflight"] = helper.preflight(meta)
        meta["capability_proof"] = catalog_proof(meta)
        meta["config_sha256"] = helper.sha(Path(meta["home"]) / "config.toml")
        meta["workspace_files_sha256"] = {str(p.relative_to(meta["cwd"])): helper.sha(p) for p in Path(meta["cwd"]).rglob("*") if p.is_file()}
        manifest["cases"].append(meta)
        helper.dump(BASE / "manifest.json", manifest)
        print("PREFLIGHT", key, "trusted+connected+isolated; zero actors", flush=True)
    assert helper.inventory(shipped) == inventory, "Shipped candidate changed during freeze/preflight"
    if projection_case:
        assert helper.sha(ROOT / manifest["projection_producer"]["source_module"]) == manifest["projection_producer"]["source_module_sha256"], "Projection producer changed during preflight"
    manifest["preparation_complete"] = True
    helper.dump(BASE / "manifest.json", manifest)
    print("PREPARED_NO_MODELS", BASE, flush=True)


def worker(key):
    manifest = json.loads((BASE / "manifest.json").read_text())
    assert manifest.get("ROOTGO") is True
    assert helper.sha(BASE / "fixture_mcp.py") == manifest["fixture_server_sha256"]
    assert helper.sha(BASE / "pending.py") == manifest["pending_parser_sha256"]
    assert helper.sha(BASE / "cases-source.json") == manifest["case_source_sha256"]
    assert helper.sha(ROOT / ".tmp/plugin-routing-evals/run.py") == manifest["helper_sha256"]
    meta = next(x for x in manifest["cases"] if x["key"] == key)
    directory, out = Path(meta["directory"]), Path(meta["directory"]) / "actor"
    out.mkdir()
    assert helper.sha(directory / "actor-input.json") == meta["actor_input_sha256"]
    assert helper.sha(directory / "fixture.json") == meta["fixture_sha256"]
    assert helper.sha(Path(meta["home"]) / "config.toml") == meta["config_sha256"]
    assert helper.inventory(Path(meta["plugin"])) == manifest["source_plugin_sha256"]
    gate_fd = os.open(meta["gate_path"], os.O_RDWR | os.O_NONBLOCK) if meta.get("gate_path") else None
    rpc = helper.rpc_for(meta, out, allow=True)
    started, events, lifecycle = time.monotonic(), [], []
    status = {"key": key, "attempt": 1, "model": "gpt-6.1-sol", "effort": "medium", "valid_runtime": False,
              "actor_input_sha256": meta["actor_input_sha256"], "setup_model_turns": 0, "assessed_model_turns": 1}
    pending, native_calls, pending_candidates = None, {}, []
    def observe(event):
        nonlocal pending
        item = event.get("params", {}).get("item", {})
        if event.get("method") == "rawResponseItem/completed" and item.get("type") in ("custom_tool_call", "function_call"):
            native_calls[item["call_id"]] = {**item, "thread_id": event["params"].get("threadId"), "turn_id": event["params"].get("turnId")}
        candidate = pending_exec(event)
        if candidate:
            pending_candidates.append({**candidate, "observed_monotonic_ns": time.monotonic_ns(), "output_id": item.get("id")})
        if gate_fd is None or pending is not None:
            return
        audit_path = directory / "fixture-tool-audit.jsonl"
        audit = [json.loads(line) for line in audit_path.read_text().splitlines() if line.strip()] if audit_path.exists() else []
        for candidate in pending_candidates:
            proof = matching_job(candidate, native_calls, audit)
            if not proof or Path(proof["job"]).resolve() != (Path(meta["cwd"]) / meta["job_path"]).resolve():
                continue
            pending = candidate
            lifecycle.append({"event": "actual_native_pending_observed", "monotonic_ns": candidate["observed_monotonic_ns"], **candidate})
            lifecycle.append({"event": "matching_job_ready_verified", "monotonic_ns": time.monotonic_ns(), **proof})
            assert proof["job_ready_monotonic_ns"] < time.monotonic_ns()
            os.write(gate_fd, b"1")
            lifecycle.append({"event": "controller_fifo_released", "monotonic_ns": time.monotonic_ns(),
                              "reason": "Matching native pending cell and same-wrapper single job_ready verified; independent of next actor choice", **proof})
            helper.dump(out / "pending-lifecycle.json", lifecycle)
            break
    try:
        thread = rpc.call("thread/start", {"cwd": meta["cwd"], "model": "gpt-6.1-sol", "permissions": "routing_eval", "approvalPolicy": "never", "ephemeral": False, "experimentalRawEvents": True})
        helper.dump(out / "thread-start.json", thread)
        assert thread["model"] == "gpt-6.1-sol" and thread["reasoningEffort"] == "medium" and thread["activePermissionProfile"]["id"] == "routing_eval" and not thread.get("instructionSources")
        tid = thread["thread"]["id"]
        status["thread_id"] = tid
        actor = json.loads((directory / "actor-input.json").read_text())
        turn = rpc.call("turn/start", {"threadId": tid, "cwd": meta["cwd"], "permissions": "routing_eval", "approvalPolicy": "never", "model": "gpt-6.1-sol", "effort": "medium", "input": [{"type": "text", "text": actor["text"]}]})
        turn_id = turn["turn"]["id"]
        status["turn_id"] = turn_id
        events, rpc.pending = rpc.pending, []
        for event in events:
            observe(event)
        deadline, completed, question = time.monotonic() + 180, None, None
        while time.monotonic() < deadline:
            completed = next((e for e in events if e.get("method") == "turn/completed" and e.get("params", {}).get("turn", {}).get("id") == turn_id), None)
            question = next((e for e in events if e.get("method") == "item/tool/requestUserInput" and "id" in e), None)
            if completed or question:
                break
            try:
                event = rpc.next(timeout=min(30, max(1, deadline - time.monotonic())))
                events.append(event)
                observe(event)
            except queue.Empty:
                continue
        if question:
            status.update(status="awaiting_user", valid_runtime=True, human_answers_supplied=0)
            helper.dump(out / "unanswered-user-request.json", question)
            # Assessment ends at the real unanswered request; cancel transport cleanup only.
            rpc.call("turn/interrupt", {"threadId": tid, "turnId": turn_id}, timeout=10)
        elif completed:
            status.update(status=completed["params"]["turn"]["status"], valid_runtime=completed["params"]["turn"]["status"] == "completed")
        else:
            rpc.call("turn/interrupt", {"threadId": tid, "turnId": turn_id}, timeout=10)
            status.update(status="timeout", valid_runtime=False)
        helper.dump(out / "turn-events.json", events)
        state = rpc.call("thread/read", {"threadId": tid, "includeTurns": True})
        helper.dump(out / "thread-read.json", state)
        answers = [i.get("text", "") for t in state.get("thread", {}).get("turns", []) for i in t.get("items", []) if i.get("type") == "agentMessage" and i.get("phase") == "final_answer"]
        (out / "final-answer.txt").write_text("\n\n".join(answers))
        status["pending_state_exercised"] = pending is not None if gate_fd is not None else None
        if gate_fd is not None and pending is None:
            status["limitation"] = "No faithful native pending handle observed; pending-state criterion is NOT_EXERCISED, never PASS"
    except BaseException as error:
        status.update(status="runtime_error", error=str(error))
    finally:
        status["wall_seconds"] = round(time.monotonic() - started, 3)
        helper.dump(out / "status.json", status)
        if gate_fd is not None:
            if pending is None:
                os.write(gate_fd, b"1")
                lifecycle.append({"event": "cleanup_fifo_released", "monotonic_ns": time.monotonic_ns(), "reason": "Unblock real job during cleanup, never counted as successful assessment completion"})
                helper.dump(out / "pending-lifecycle.json", lifecycle)
        helper.close_rpc(rpc)
        if gate_fd is not None:
            os.close(gate_fd)
            cleanup_fixture_jobs(meta, out)
    print("CASE", key, status["status"], status["wall_seconds"], "seconds", flush=True)
    return 0 if status["valid_runtime"] else 1


def execute(rootgo):
    assert rootgo, "Root review/GO required"
    manifest = json.loads((BASE / "manifest.json").read_text())
    assert manifest.get("preparation_complete") and len(manifest["cases"]) in (3, 4)
    assert not any((Path(m["directory"]) / "actor").exists() for m in manifest["cases"]), "Never retry an actor"
    manifest["ROOTGO"] = True
    manifest["execution_runner_sha256"] = helper.sha(__file__)
    helper.dump(BASE / "manifest.json", manifest)
    remaining, running, exits = iter(manifest["cases"]), [], []
    while True:
        while len(running) < 2:
            try:
                case = next(remaining)
            except StopIteration:
                break
            process = subprocess.Popen([helper.PY, str(BASE / "run.py"), "worker", case["key"]])
            running.append((process, case["key"]))
        if not running:
            break
        # Controller process scheduling only; no actor tool waiting is synthesized.
        finished, wait_status = os.waitpid(-1, 0)
        for process, key in list(running):
            if process.pid == finished:
                process.returncode = os.waitstatus_to_exitcode(wait_status)
                exits.append({"key": key, "process_reaped": True, "exit_code": process.returncode})
                running.remove((process, key))
                helper.dump(BASE / "worker-exits.json", exits)
    print("RAW_RESULTS", BASE, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="action", required=True)
    prep = subs.add_parser("prepare")
    prep.add_argument("--projection-case", type=Path)
    run = subs.add_parser("run")
    run.add_argument("--rootgo", action="store_true")
    item = subs.add_parser("worker")
    item.add_argument("key")
    args = parser.parse_args()
    if args.action == "prepare":
        prepare(args.projection_case)
    elif args.action == "run":
        execute(args.rootgo)
    else:
        sys.exit(worker(args.key))
