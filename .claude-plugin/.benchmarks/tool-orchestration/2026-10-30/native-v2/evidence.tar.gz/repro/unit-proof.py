#!/usr/bin/env python3
"""Offline archival replay of the old pure parser RED and fixed parser GREEN."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
OLD = BASE.parent / 'tool-orchestration-evals'
source = (OLD / 'run.py').read_text()
tree = ast.parse(source)
function = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == 'output_texts')
old_function = ast.get_source_segment(source, function)
events = [json.loads(x) for x in (OLD / 'cases/O1-running-exec-cell/actor/events.jsonl').read_text().splitlines()]
event = next(x for x in events if x.get('params', {}).get('item', {}).get('id') == 'ctco_01a18e47-2b76-7d51-99c4-2d8a0c752f67')
script = 'import unittest\n' + old_function + '\nevent=' + repr(event) + '''
class OriginalParserRegression(unittest.TestCase):
    def test_actual_pending_string_must_not_be_discarded(self):
        self.assertEqual(output_texts(event), [event['params']['item']['output']])
unittest.main()
'''
red = subprocess.run([sys.executable, '-c', script], capture_output=True, text=True)
green = subprocess.run([sys.executable, str(BASE / 'test_pending.py')], capture_output=True, text=True)
assert red.returncode == 1 and 'AssertionError' in red.stderr and 'Script running with cell ID 2' in red.stderr
assert green.returncode == 0 and 'Ran 8 tests' in green.stderr
proof = {
    'kind': 'Offline archival replay; no actor execution or original attempt modification',
    'historical_test_first_sequence': 'Exact-string regression was observed RED before pending.py fix, then GREEN. This stored subprocess proof is a later replay using the immutable executed old parser and original native output, not a claim of captured historical test stdout.',
    'old_runner_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'original_native_event': event,
    'old_pure_parser_source': old_function,
    'red': {'exit_code': red.returncode, 'stdout': red.stdout, 'stderr': red.stderr, 'reason': 'Assertion: original parser drops actual native output string'},
    'green': {'exit_code': green.returncode, 'stdout': green.stdout, 'stderr': green.stderr, 'test_source_sha256': hashlib.sha256((BASE / 'test_pending.py').read_bytes()).hexdigest(), 'parser_sha256': hashlib.sha256((BASE / 'pending.py').read_bytes()).hexdigest()},
    'model_turns': 0,
}
(BASE / 'unit-parser-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print('PASS: preserved old parser + actual native string RED; fixed parser GREEN8/8; zero actors.')
