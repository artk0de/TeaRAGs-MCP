#!/usr/bin/env python3
"""Offline completed-trace checks for O6/P1; no runner or actor imports."""
import json
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text())


def lines(path):
    return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]


def output_texts(item):
    value = item.get('output', [])
    return [value] if isinstance(value, str) else [x['text'] for x in value if isinstance(x, dict) and 'text' in x]


def main():
    manifest = load(BASE / 'manifest.json')
    assert len(load(BASE / 'worker-exits.json')) == 4, 'Wait for root-confirmed four-worker EOF'
    grades = []
    for meta in manifest['cases']:
        if not meta['key'].startswith(('O6', 'P1')):
            continue
        directory = Path(meta['directory']); actor = directory / 'actor'
        events = lines(actor / 'events.jsonl')
        status = load(actor / 'status.json')
        native = [e['params']['item'] for e in events if e.get('method') == 'item/completed']
        raw = [e['params']['item'] for e in events if e.get('method') == 'rawResponseItem/completed']
        calls = [x for x in raw if x.get('type') in ('custom_tool_call', 'function_call')]
        outputs = {x['call_id']: x for x in raw if x.get('type') in ('custom_tool_call_output', 'function_call_output')}
        final = [x for x in native if x.get('type') == 'agentMessage' and x.get('phase') == 'final_answer']
        checks = {'completed_once': status.get('status') == 'completed' and status.get('attempt') == 1,
                  'one_native_turn': sum(e.get('method') == 'turn/started' for e in events) == 1,
                  'one_final_answer': len(final) == 1}
        evidence = {'thread_id': status['thread_id'], 'turn_id': status['turn_id'],
                    'final_answer': final[0]['text'] if final else '', 'actor_wall_seconds': status['wall_seconds']}
        if meta['key'].startswith('O6'):
            audit = lines(directory / 'fixture-tool-audit.jsonl')
            lifecycle = load(actor / 'pending-lifecycle.json')
            pending = next(x for x in lifecycle if x['event'] == 'actual_native_pending_observed')
            release = next(x for x in lifecycle if x['event'] == 'controller_fifo_released')
            starts = [x for x in audit if x['event'] == 'job_start']
            ready = [x for x in audit if x['event'] == 'job_ready']
            ends = [x for x in audit if x['event'] == 'job_end']
            expected = {'checked': 5, 'missing': ['payments.capture', 'reports.export']}
            wrapper = next(x for x in calls if x['call_id'] == pending['call_id'])
            requests = [x for x in audit if x.get('event') == 'start' and x.get('method') == 'tools/call' and x.get('params', {}).get('name') == 'verify_route_contracts']
            request_meta = requests[0]['params']['_meta']
            pending_output = outputs[wrapper['call_id']]
            actual_cell = re.match(r'^Script running with cell ID (\S+)', output_texts(pending_output)[0])[1]
            waits = [x for x in calls if x.get('name') == 'wait']
            wait_args = json.loads(waits[0]['arguments'])
            wait_output = outputs[waits[0]['call_id']]
            delivered = json.loads(output_texts(wait_output)[1])['structuredContent']
            tool_calls = [x for x in native if x.get('type') == 'mcpToolCall']
            checks.update({
                'single_real_job_and_tool': len(starts) == len(ready) == len(ends) == len(requests) == len(tool_calls) == 1 and tool_calls[0]['tool'] == 'verify_route_contracts',
                'same_native_runtime_wrapper': request_meta['itemId'] == wrapper['id'] and request_meta['threadId'] == status['thread_id'] and request_meta['x-codex-turn-metadata']['turn_id'] == status['turn_id'],
                'same_job_ready_before_release': starts[0]['pid'] == ready[0]['pid'] == ends[0]['pid'] == release['job_pid'] and starts[0]['monotonic_ns'] < ready[0]['monotonic_ns'] < pending['monotonic_ns'] < release['monotonic_ns'] < ends[0]['monotonic_ns'],
                'same_cell_native_wait': len(waits) == 1 and wait_args['cell_id'] == actual_cell == pending['cell_id'] and not wait_args.get('terminate'),
                'real_terminal_bytes_delivered': ends[0]['exit_code'] == 0 and json.loads(ends[0]['output']) == delivered == tool_calls[0]['result']['structuredContent'] == expected and output_texts(wait_output)[0].startswith('Script completed'),
                'clock_available_no_delay_or_restart': meta['capability_proof']['clock_sleep_present'] and len(calls) == 3 and all(x.get('name') in ('exec', 'wait') for x in calls) and not any(re.search(r'\b(?:setTimeout|sleep)\s*\(|time\.sleep|Atomics\.wait', str(x.get('input', ''))) for x in calls),
                'final_facts_grounded': bool(final) and '5 routes' in final[0]['text'] and all(x in final[0]['text'] for x in expected['missing']),
            })
            evidence.update({'start_wrapper_id': wrapper['id'], 'start_call_id': wrapper['call_id'],
                             'native_mcp_id': tool_calls[0]['id'], 'job_pid': starts[0]['pid'],
                             'pending_output_id': pending_output['id'], 'cell_id': actual_cell,
                             'wait_id': waits[0]['id'], 'wait_output_id': wait_output['id'],
                             'pending_lifecycle': lifecycle, 'job_events': starts + ready + ends,
                             'actual_delivered_terminal_result': delivered})
        else:
            proof = load(BASE / 'projection-producer-proof.json')
            arguments = proof['raw_arguments']; returned = proof['actual_return']['results']
            actor_input = load(directory / 'actor-input.json')['text']
            answer = final[0]['text'] if final else ''
            checks.update({
                'actual_source_projection': proof['actual_source_import'] and proof['model_turns'] == 0 and proof['optional_mode_omitted'],
                'fields_omit_path_output_preserves_it': arguments[1] == ['symbolId', 'content'] and [x['payload']['relativePath'] for x in returned] == [x['payload']['relativePath'] for x in arguments[0]] == ['src/webhook/retry.ts', 'src/http/retry.ts'] and [x['id'] for x in returned] == [x['id'] for x in arguments[0]],
                'actual_projected_bodies_seeded': all(x['payload']['content'].replace('\n', '\\n') in actor_input and x['payload']['relativePath'] in actor_input for x in returned),
                'zero_extra_context_calls': not calls and not any(x.get('type') in ('mcpToolCall', 'commandExecution', 'dynamicToolCall') for x in native),
                'correct_path_mapping': bool(re.search(r'src/http/retry\.ts[^\n]*100[^\n]*400', answer)) and bool(re.search(r'src/webhook/retry\.ts[^\n]*300[^\n]*1,?200', answer)),
            })
            evidence.update({'source_module': proof['source_module'], 'source_sha256': proof['source_module_sha256'],
                             'raw_requested_fields': arguments[1], 'actual_projected_path_order': [x['payload']['relativePath'] for x in returned],
                             'actual_producer_return': proof['actual_return'], 'post_prompt_tool_count': len(calls)})
        grades.append({'case': meta['key'], 'verdict': 'PASS' if all(checks.values()) else 'FAIL', 'checks': checks, 'evidence': evidence})
    assert len(grades) == 2
    report = {'reviewer': '/root/eval_architecture_gate', 'method': 'Offline native-call, actual-output and source-producer evidence; not runner-status grading',
              'cases': grades, 'passed': sum(x['verdict'] == 'PASS' for x in grades), 'total': len(grades),
              'limits': ['One synthetic observation per case; no full benchmark or latency claim.', 'O6 is a new five-route control; original O1 remains inconclusive, not a corrected/retried actor attempt.', 'P1 proves actual shared projection plus native actor consumption for one fields case; server unit matrix covers other endpoints.']}
    (BASE / 'grade-o6-p1.json').write_text(json.dumps(report, indent=2) + '\n')
    for grade in grades:
        print(grade['verdict'], grade['case'], [k for k, v in grade['checks'].items() if not v])
    assert report['passed'] == report['total']


if __name__ == '__main__':
    main()
