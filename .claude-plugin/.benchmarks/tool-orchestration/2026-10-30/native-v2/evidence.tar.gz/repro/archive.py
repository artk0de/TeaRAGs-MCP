#!/usr/bin/env python3
"""Allowlisted completed v2 archive, never a model/runner launcher."""
import gzip
import hashlib
import json
from pathlib import Path
import tomllib

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
OUT = ROOT / '.claude-plugin/.benchmarks/tool-orchestration/2026-10-30/native-v2'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
load = lambda path: json.loads(path.read_text())
manifest = load(BASE / 'manifest.json')
assert len(load(BASE / 'worker-exits.json')) == len(manifest['cases']) == 4
assert not OUT.exists(), 'Never overwrite an archived attempt'
reviews = [load(BASE / 'grade-o6-p1.json'), load(BASE / 'grade-o4-o5-independent.json')]
grades = [row for review in reviews for row in review['cases']]
assert len(grades) == len({row['case'] for row in grades}) == 4
assert all((Path(c['directory']) / 'actor/status.json').exists() for c in manifest['cases'])
snapshot = BASE / 'marketplace/harness/codex/tea-rags'
assert {str(p.relative_to(snapshot)): sha(p.read_bytes()) for p in snapshot.rglob('*') if p.is_file()} == manifest['source_plugin_sha256']
OUT.mkdir(parents=True)
records = []


def write_json(name, value):
    path = OUT / name; path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def copy(source, name, compress=False):
    assert source.is_file() and not source.is_symlink(), source
    raw = source.read_bytes(); encoded = gzip.compress(raw, mtime=0) if compress else raw
    assert not compress or sha(gzip.decompress(encoded)) == sha(raw)
    target = OUT / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(encoded)
    records.append({'archive_path': name, 'raw_sha256': sha(raw), 'archived_sha256': sha(encoded), 'raw_bytes': len(raw), 'archived_bytes': len(encoded), 'gzip_roundtrip_verified': compress})


safe_keys = ['ROOTGO', 'model', 'effort', 'plugin_version', 'source_plugin_sha256', 'fixture_server_sha256',
             'helper_sha256', 'runner_sha256', 'execution_runner_sha256', 'pending_parser_sha256', 'case_source_sha256',
             'max_workers', 'profile', 'retry_policy', 'pending_protocol', 'provenance', 'preparation_complete', 'projection_producer']
safe = {k: manifest[k] for k in safe_keys if k in manifest}
safe['cases'] = [{k: c[k] for k in ['key', 'suite', 'id', 'alias', 'actor_input_sha256', 'fixture_sha256', 'preflight', 'capability_proof', 'workspace_files_sha256'] if k in c} for c in manifest['cases']]
write_json('manifest.json', safe)
write_json('grades-all.json', {'cases': grades, 'summary': {'PASS': sum(x['verdict'] == 'PASS' for x in grades), 'FAIL': sum(x['verdict'] == 'FAIL' for x in grades)}})
runtime = {'model': manifest['model'], 'effort': manifest['effort'], 'case_count': 4, 'cases': []}
for meta in manifest['cases']:
    directory = Path(meta['directory']); actor = directory / 'actor'; prefix = 'cases/' + meta['key'] + '/'
    status = load(actor / 'status.json'); assert status['status'] == 'completed' and status['attempt'] == 1
    events = [json.loads(x) for x in (actor / 'events.jsonl').read_text().splitlines() if x.strip()]
    assert sum(e.get('method') == 'turn/started' for e in events) == 1
    starts = sum(e.get('method') == 'hook/started' for e in events); ends = sum(e.get('method') == 'hook/completed' for e in events)
    assert starts == ends
    runtime['cases'].append({'key': meta['key'], 'status': status, 'native_turns': 1, 'hooks_started': starts, 'hooks_completed': ends})
    for source, target in {
        'actor-input.json': 'actor-input.json', 'fixture.json': 'fixture.json', 'preflight.json': 'preflight.json',
        'actor/status.json': 'status.json', 'actor/thread-start.json': 'thread-start.json',
        'actor/pending-lifecycle.json': 'pending-lifecycle.json', 'actor/fixture-job-cleanup.json': 'fixture-job-cleanup.json',
        'preflight-no-turn/capability-proof.json': 'capability-proof.json',
        'preflight-no-turn/filesystem-denials.json': 'filesystem-denials.json',
        'preflight-no-turn/filesystem-allowed.json': 'filesystem-allowed.json',
        'preflight-no-turn/hooks.json': 'hooks.json', 'preflight-no-turn/skills.json': 'skills.json',
        'preflight-no-turn/mcp.json': 'mcp.json',
    }.items():
        if (directory / source).exists(): copy(directory / source, prefix + target)
    for source, target in {'actor/events.jsonl': 'events.jsonl.gz', 'actor/turn-events.json': 'turn-events.json.gz',
                           'actor/thread-read.json': 'thread-read.json.gz', 'fixture-tool-audit.jsonl': 'fixture-tool-audit.jsonl.gz'}.items():
        copy(directory / source, prefix + target, True)
    state = load(actor / 'thread-read.json')
    answers = [i['text'] for t in state['thread']['turns'] for i in t['items'] if i.get('type') == 'agentMessage' and i.get('phase') == 'final_answer']
    (OUT / prefix / 'answer.md').write_text('\n\n'.join(answers) + '\n')
    config = tomllib.loads((Path(meta['home']) / 'config.toml').read_text())
    write_json(prefix + 'profile-proof.json', {'model': config['model'], 'effort': config['model_reasoning_effort'],
        'approval_policy': config['approval_policy'], 'default_permissions': config['default_permissions'],
        'permissions': config['permissions'], 'features': {k: config['features'].get(k) for k in ['sleep_tool', 'unified_exec', 'multi_agent', 'memories', 'apps']},
        'note': 'Selected nonsecret permission/capability sections only; no auth, per-home config bundle or environment copied.'})
write_json('runtime-summary.json', runtime)
for name in manifest['source_plugin_sha256']: copy(snapshot / name, 'plugin-snapshot/' + name)
for name in ['grade-o6-p1.json', 'grade-o4-o5-independent.json', 'grade-o4-o5-independent.md', 'unit-parser-proof.json',
             'projection-producer-proof.json', 'source-produced-projection.json', 'cases-source.json', 'worker-exits.json']:
    copy(BASE / name, name)
for name in ['run.py', 'pending.py', 'test_pending.py', 'build_cases.py', 'fixture_mcp.py', 'grade-o6-p1.py', 'unit-proof.py', 'archive.py']:
    copy(BASE / name, 'repro/' + name)
copy(ROOT / '.tmp/plugin-routing-evals/run.py', 'repro/shared-routing-run.py')
copy(ROOT / '.tmp/codex61_app_rpc.py', 'repro/codex61_app_rpc.py')
failed = BASE / 'preparation-attempt-sandbox-denied'
if failed.exists():
    failure_file = failed / 'cases/O4-independent-mixed-tool-batch/preflight-no-turn/filesystem-denials.json'
    if failure_file.exists(): copy(failure_file, 'zero-turn-preparation-sandbox-denial.json')
    write_json('preparation-history.json', {'blocked_preparation_model_turns': 0, 'reason': 'Nested macOS sandbox_apply denied native boundary probe; preserved, then approved outer-sandbox-free preparation completed. No actor retry.', 'failed_manifest_sha256': sha((failed / 'manifest.json').read_bytes())})
write_json('raw-sha256.json', {'files': records, 'scope': 'Explicit allowlists only; no auth, actor homes, per-home configs, backend logs or environment bundles. Native output bytes preserved.'})
listing = ''.join(f'{sha(p.read_bytes())}  {p.relative_to(OUT)}\n' for p in sorted(OUT.rglob('*')) if p.is_file())
(OUT / 'inventory.sha256').write_text(listing)
print(json.dumps({'output': str(OUT), 'files': sum(p.is_file() for p in OUT.rglob('*')), 'inventory_entries': len(listing.splitlines()), 'inventory_sha256': sha(listing.encode()), 'PASS': sum(x['verdict'] == 'PASS' for x in grades), 'FAIL': sum(x['verdict'] == 'FAIL' for x in grades)}))
