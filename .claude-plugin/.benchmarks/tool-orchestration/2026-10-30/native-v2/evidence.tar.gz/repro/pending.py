"""Pure native-output and same-job proof helpers; no actor/tool execution."""
import re


def output_texts(event):
    if event.get('method') != 'rawResponseItem/completed':
        return []
    item = event.get('params', {}).get('item', {})
    if item.get('type') not in ('custom_tool_call_output', 'function_call_output'):
        return []
    output = item.get('output', [])
    if isinstance(output, str):
        return [output]
    return [x.get('text', '') for x in output if isinstance(x, dict)]


def pending_exec(event):
    values = output_texts(event)
    match = re.match(r'^Script running with cell ID ([A-Za-z0-9:_-]+)', values[0]) if values else None
    if not match:
        return None
    return {'kind': 'exec_cell', 'cell_id': match[1], 'call_id': event['params']['item'].get('call_id')}


def matching_job(candidate, calls, audit):
    call = calls.get(candidate['call_id'], {})
    if call.get('name') != 'exec':
        return None
    requests = [(i, event) for i, event in enumerate(audit)
                if event.get('event') == 'start' and event.get('method') == 'tools/call'
                and event.get('params', {}).get('name') == 'verify_route_contracts'
                and event.get('params', {}).get('_meta', {}).get('itemId') == call.get('id')]
    starts = [(i, event) for i, event in enumerate(audit) if event.get('event') == 'job_start']
    if len(requests) != 1 or len(starts) != 1:
        return None
    request_index, request = requests[0]
    start_index, start = starts[0]
    metadata = request['params']['_meta']
    if call.get('thread_id') and metadata.get('threadId') != call['thread_id']:
        return None
    if call.get('turn_id') and metadata.get('x-codex-turn-metadata', {}).get('turn_id') != call['turn_id']:
        return None
    ready = [event for i, event in enumerate(audit)
             if i > start_index > request_index and event.get('event') == 'job_ready'
             and event.get('pid') == start['pid'] and event.get('ready') == f"ORCH_JOB_READY {start['pid']}"]
    if len(ready) != 1:
        return None
    return {'wrapper_id': call['id'], 'call_id': candidate['call_id'],
            'native_mcp_call_id': metadata.get('callId'), 'job_pid': start['pid'],
            'job': start['job'], 'job_ready_monotonic_ns': ready[0]['monotonic_ns'],
            'thread_id': call.get('thread_id'), 'turn_id': call.get('turn_id')}
