#!/usr/bin/env python3
"""Archive completed native evidence; gzip bytes are round-trip verified."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
OUT = ROOT / '.claude-plugin/.benchmarks/tool-orchestration/2026-10-30/metadata-search-results'
assert not OUT.exists(), 'Never overwrite an evidence archive'
manifest = json.loads((BASE / 'manifest.json').read_text())
graded = json.loads((BASE / 'graded-results.json').read_text())
assert len(manifest['cases']) == 5 and graded['summary']['full_pass'] == 4 and graded['summary']['partial'] == 1
OUT.mkdir(parents=True)
receipts = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def put(source, relative, compress=False, role='evidence'):
    source = Path(source)
    assert source.is_file() and not source.is_symlink(), source
    raw = source.read_bytes()
    target = OUT / (relative + ('.gz' if compress else ''))
    target.parent.mkdir(parents=True, exist_ok=True)
    stored = gzip.compress(raw, compresslevel=9, mtime=0) if compress else raw
    target.write_bytes(stored)
    restored = gzip.decompress(target.read_bytes()) if compress else target.read_bytes()
    assert restored == raw
    receipts.append({'archive_path': str(target.relative_to(OUT)), 'source_path': str(source.relative_to(ROOT)),
        'role': role, 'gzip': compress, 'source_bytes': len(raw), 'stored_bytes': len(stored),
        'source_sha256': digest(raw), 'stored_sha256': digest(stored), 'roundtrip_sha256': digest(restored),
        'roundtrip_equal': True})


def emit(relative, data, role):
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode()
    target.write_bytes(raw)
    receipts.append({'archive_path': relative, 'source_path': None, 'role': role,
        'gzip': False, 'source_bytes': len(raw), 'stored_bytes': len(raw),
        'source_sha256': digest(raw), 'stored_sha256': digest(raw), 'roundtrip_sha256': digest(raw), 'roundtrip_equal': True})


put(BASE / 'README-results.md', 'README.md', role='report')
put(BASE / 'graded-results.json', 'graded-results.json', role='report')
put(BASE / 'native-evidence.json', 'controller/native-evidence.json', True)
for name in ['manifest.json', 'snapshot-fingerprints.json', 'source-plugin-sha256.json', 'producer-command.json', 'worker-exits.json']:
    put(BASE / name, 'controller/' + name)
for name in ['run.py', 'build_cases.py', 'fixture_mcp.py', 'extract.py', 'archive.py']:
    put(BASE / name, 'tools/' + name, role='harness-source')
put(ROOT / '.tmp/plugin-routing-evals/run.py', 'tools/upstream/native-helper.py', role='harness-source')
put(ROOT / '.tmp/codex61_app_rpc.py', 'tools/upstream/native-rpc.py', role='harness-source')
put(ROOT / 'src/core/api/tools/answer-banner.ts', 'controller/producer-source.ts', role='producer-source')
put(BASE / 'cases-source.json', 'gold/complete-case-definitions.json', True, 'frozen-case-and-oracle')
put(BASE / 'source-produced-search.json', 'gold/source-produced-search-cases.json', True, 'frozen-case-and-oracle')
put(ROOT / '.claude-plugin/.benchmarks/tool-orchestration/2026-10-30/search-evidence-evals.json',
    'gold/original-search-cases.json', True, 'frozen-case-and-oracle')
cases = {c['id']: c for c in json.loads((BASE / 'cases-source.json').read_text())['evals']}

for meta in manifest['cases']:
    key, directory = meta['key'], Path(meta['directory'])
    status = json.loads((directory / 'actor/status.json').read_text())
    assert status['status'] == 'completed' and status['attempt'] == 1
    actor_input = json.loads((directory / 'actor-input.json').read_text())
    assert set(actor_input) == {'cwd', 'project', 'text'}
    assert 'descriptor_forbidden_markers' not in actor_input['text'] and 'required_body_ids' not in actor_input['text']
    put(directory / 'actor-input.json', 'actor-inputs/' + key + '.json', role='actor-input-only')
    emit('gold/' + key + '.json', cases[key].get('grading', {}), 'grading-only')
    put(directory / 'fixture.json', 'fixtures/' + key + '.json', True, 'raw-fixture-controller-only')
    put(Path(meta['home']) / 'config.toml', 'profiles/' + key + '.config.toml', role='profile-no-auth')
    for name in ['native-install.json', 'hooks-before-trust.json', 'preflight.json']:
        put(directory / name, 'cases/' + key + '/' + name)
    audit = directory / 'fixture-tool-audit.jsonl'
    if audit.exists():
        put(audit, 'cases/' + key + '/fixture-tool-audit.jsonl', True)
    for stage in ['actor', 'preflight-no-turn', 'trust-no-turn']:
        for path in sorted((directory / stage).glob('*')):
            if path.is_file() and not path.is_symlink():
                compress = path.suffix in ('.jsonl', '.json') and path.stat().st_size > 4096
                put(path, 'cases/' + key + '/' + stage + '/' + path.name, compress)

expected = json.loads((BASE / 'source-plugin-sha256.json').read_text())
snapshot = BASE / 'marketplace/harness/codex/tea-rags'
actual = {str(p.relative_to(snapshot)): digest(p.read_bytes()) for p in snapshot.rglob('*') if p.is_file() and not p.is_symlink()}
assert actual == expected and len(actual) == 87
for relative in sorted(actual):
    put(snapshot / relative, 'frozen-plugin/' + relative, role='frozen-plugin')
archive_manifest = {'schema_version': 1, 'case_count': 5, 'frozen_plugin_files': 87,
    'model': manifest['model'], 'effort': manifest['effort'], 'plugin_version': manifest['plugin_version'],
    'verdict': graded['summary']['verdict'], 'actor_inputs_separate_from_gold': True,
    'authentication_files_included': False, 'home_databases_included': False,
    'older_wait_only_snapshot_modified': False, 'new_model_runs_by_archiver': 0,
    'source_fingerprints': manifest['snapshot_fingerprints'],
    'gzip_roundtrip_verified_files': sum(r['gzip'] for r in receipts),
    'all_roundtrips_equal': all(r['roundtrip_equal'] for r in receipts),
    'total_source_bytes': sum(r['source_bytes'] for r in receipts),
    'total_stored_bytes': sum(r['stored_bytes'] for r in receipts),
    'file_count_excluding_this_manifest': len(receipts), 'files': receipts,
    'self_hash_note': 'This manifest is excluded from its own non-circular file list.'}
(OUT / 'archive-manifest.json').write_text(json.dumps(archive_manifest, ensure_ascii=False, indent=2) + '\n')
assert all(digest((OUT / r['archive_path']).read_bytes()) == r['stored_sha256'] for r in receipts)
print(json.dumps({k: archive_manifest[k] for k in ['case_count', 'frozen_plugin_files', 'verdict',
    'gzip_roundtrip_verified_files', 'all_roundtrips_equal', 'total_source_bytes', 'total_stored_bytes',
    'file_count_excluding_this_manifest']}, indent=2))
print('ARCHIVED', OUT)
