#!/usr/bin/env python3
"""Offline native evidence extraction. No model calls; verdicts require content review."""
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
manifest = json.loads((BASE / 'manifest.json').read_text())
source = {c['id']: c for c in json.loads((BASE / 'cases-source.json').read_text())['evals']}
report = {'model_calls_by_extractor': 0, 'cases': {}}


def texts(item):
    return [x.get('text', '') for x in item.get('output', []) if isinstance(x, dict) and isinstance(x.get('text'), str)]


def body_rows(result):
    if not isinstance(result, dict):
        return []
    rows = result.get('results', {})
    if isinstance(rows, dict):
        decoded = [dict(zip(rows.get('columns', []), row)) for row in rows.get('rows', [])]
        return [{key.removeprefix('payload.'): value for key, value in row.items()}
                for row in decoded if row.get('payload.content') or row.get('content')]
    if isinstance(rows, list):
        return [row.get('payload', row) for row in rows if isinstance(row, dict)
                and (row.get('payload', {}).get('content') or row.get('content'))]
    return []


for meta in manifest['cases']:
    key, directory = meta['key'], Path(meta['directory'])
    actor = directory / 'actor'
    if not (actor / 'status.json').exists():
        report['cases'][key] = {'state': 'NOT_FINISHED'}
        continue
    status = json.loads((actor / 'status.json').read_text())
    events = [json.loads(line) for line in (actor / 'events.jsonl').open()]
    items, wrappers, outputs, finals = {}, {}, {}, {}
    hook_starts = hook_ends = turn_starts = 0
    for event in events:
        method, params = event.get('method'), event.get('params', {})
        item = params.get('item', {})
        hook_starts += method == 'hook/started'; hook_ends += method == 'hook/completed'; turn_starts += method == 'turn/started'
        if method == 'item/completed' and item.get('id'):
            items[item['id']] = item
        if method == 'rawResponseItem/completed':
            if item.get('type') in ('custom_tool_call', 'function_call'):
                wrappers[item.get('call_id', item.get('id'))] = item
            elif item.get('type') == 'custom_tool_call_output':
                outputs[item.get('call_id', item.get('id'))] = item
            elif item.get('type') == 'message' and item.get('role') == 'assistant' and item.get('phase') == 'final_answer':
                finals[item['id']] = '\n'.join(x.get('text', '') for x in item.get('content', []) if x.get('type') == 'output_text')
    final = '\n\n'.join(finals.values())
    (actor / 'final-answer.txt').write_text(final)
    commands, mcp_calls, observed_bodies = [], [], []
    for item in items.values():
        if item.get('type') == 'commandExecution':
            actions = item.get('commandActions', [])
            project_actions = [a for a in actions if isinstance(a.get('path'), str)
                               and (a['path'].startswith(meta['cwd'] + '/') or not a['path'].startswith('/'))]
            commands.append({'id': item['id'], 'command': item.get('command'), 'status': item.get('status'),
                'exit_code': item.get('exitCode'), 'project_read_actions': project_actions,
                'output': item.get('aggregatedOutput')})
        elif item.get('type') == 'mcpToolCall':
            result = (item.get('result') or {}).get('structuredContent')
            mcp_calls.append({'id': item['id'], 'tool': item.get('tool'), 'arguments': item.get('arguments'),
                'status': item.get('status'), 'error': item.get('error'), 'returned_structured_content': result})
            observed_bodies.extend(dict(row, native_call_id=item['id']) for row in body_rows(result))
    metadata = []
    for call_id, wrapper in wrappers.items():
        program = wrapper.get('input', wrapper.get('arguments', ''))
        if not isinstance(program, str) or 'ALL_TOOLS' not in program:
            continue
        delivered = texts(outputs.get(call_id, {}))
        descriptor_blocks = []
        other_blocks = []
        fixture = json.loads((directory / 'fixture.json').read_text())
        expected_snapshot = next((x.get('result', {}).get('snapshotId') for x in fixture.get('raw_tool_responses', [])
                                  if isinstance(x, dict) and x.get('tool') == 'inspect_delivery_queue'), None) if isinstance(fixture.get('raw_tool_responses'), list) else None
        for block in delivered:
            # Actual returned queue data is allowed; it is not a printed return schema.
            is_real_result = False
            if expected_snapshot and expected_snapshot in block:
                try:
                    is_real_result = isinstance(json.loads(block), dict) and '# tea-rags core' not in block
                except json.JSONDecodeError:
                    pass
            parsed = None
            try:
                parsed = json.loads(block)
            except json.JSONDecodeError:
                pass
            is_command_result = isinstance(parsed, dict) and 'chunk_id' in parsed and 'output' in parsed
            is_descriptor = ('declare const tools:' in block or 'exec tool declaration:' in block
                             or '# tea-rags core' in block or (isinstance(parsed, dict)
                             and any(k in parsed for k in ('schema', 'inputSchema', 'parameters'))))
            if not is_real_result and not is_command_result and is_descriptor:
                descriptor_blocks.append(block)
            else:
                other_blocks.append(block)
        descriptor = '\n'.join(descriptor_blocks)
        forbidden = source[key].get('grading', {}).get('descriptor_forbidden_markers', [])
        metadata.append({'call_id': call_id, 'wrapper_id': wrapper.get('id'), 'program': program,
            'delivered_text_blocks': delivered, 'descriptor_candidate_text': descriptor,
            'other_delivered_text_blocks': other_blocks,
            'descriptor_characters': len(descriptor),
            'forbidden_descriptor_markers_delivered': [word for word in forbidden if word in descriptor],
            'all_argument_names_delivered': all(word in descriptor for word in ['tenantKey', 'deployment', 'queueKey', 'includeRetryPolicy'])})
    fixture = json.loads((directory / 'fixture.json').read_text())
    expected = fixture.get('raw_tool_responses', [])
    expected_inspection = next((x for x in expected if isinstance(x, dict) and x.get('tool') == 'inspect_delivery_queue'), None) if isinstance(expected, list) else None
    inspection_checks = None
    if expected_inspection:
        calls = [c for c in mcp_calls if c['tool'] == 'inspect_delivery_queue']
        correct = [c for c in calls if c['status'] == 'completed'
                   and all((c['arguments'] or {}).get(k) == v for k, v in expected_inspection['arguments'].items())
                   and c['returned_structured_content'] == expected_inspection['result']]
        facts = source[key]['grading']['answer_facts']
        inspection_checks = {'native_call_count': len(calls), 'correct_argument_and_exact_result_call_ids': [c['id'] for c in correct],
            'failed_inspection_call_ids': [c['id'] for c in calls if c['status'] != 'completed'],
            'final_fact_tokens_present': {name: str(value) in final for name, value in facts.items()},
            'manual_semantic_review_required': True}
    entry = {'state': status.get('status'), 'status': status, 'actual_thread_start': json.loads((actor / 'thread-start.json').read_text()),
        'native_turn_starts': turn_starts, 'hook_starts': hook_starts, 'hook_completions': hook_ends,
        'metadata_lookups': metadata, 'inspection_checks': inspection_checks,
        'native_mcp_calls': mcp_calls, 'commands': commands, 'observed_body_rows': observed_bodies,
        'final_answer': final, 'final_answer_whitespace_words': len(final.split()),
        'warning': 'Evidence extraction is not a pass verdict; inspect delivered metadata and final semantics, not status alone.'}
    report['cases'][key] = entry
(BASE / 'native-evidence.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: {'state': row['state'], 'metadata_lookups': len(row.get('metadata_lookups', [])),
                       'mcp_calls': len(row.get('native_mcp_calls', [])), 'final_words': row.get('final_answer_whitespace_words')}
                  for key, row in report['cases'].items()}, indent=2))
