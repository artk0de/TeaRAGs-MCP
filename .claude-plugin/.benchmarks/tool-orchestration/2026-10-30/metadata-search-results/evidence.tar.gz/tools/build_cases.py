#!/usr/bin/env python3
"""Build actor-safe metadata fixtures from the frozen plugin, without models."""
import argparse
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--search-cases', type=Path)
args = parser.parse_args()
plugin = BASE / 'marketplace/harness/codex/tea-rags'
core = (plugin / 'scripts/core.txt').read_text()
schema = {
    'type': 'object', 'additionalProperties': False,
    'properties': {
        'project': {'type': 'string', 'description': 'Registered project alias.'},
        'path': {'type': 'string', 'description': 'Absolute current workspace root.'},
        'tenantKey': {'type': 'string', 'description': 'Tenant slug, for example acme.'},
        'deployment': {'type': 'string', 'enum': ['production', 'staging']},
        'queueKey': {'type': 'string', 'description': 'Exact queue key.'},
        'includeRetryPolicy': {'type': 'boolean', 'description': 'Include current retry policy in the snapshot.'}
    },
    'required': ['project', 'path', 'tenantKey', 'deployment', 'queueKey', 'includeRetryPolicy']
}
output = {
    'type': 'object', 'additionalProperties': False,
    'properties': {
        'snapshotId': {'type': 'string'}, 'observedAt': {'type': 'string'},
        'queue': {'type': 'object', 'properties': {
            'tenantKey': {'type': 'string'}, 'deployment': {'type': 'string'}, 'queueKey': {'type': 'string'},
            'queuedMessages': {'type': 'integer'}, 'oldestMessageAgeSeconds': {'type': 'integer'},
            'retryPolicy': {'type': 'object', 'properties': {
                'maxAttempts': {'type': 'integer'}, 'baseDelayMs': {'type': 'integer'},
                'maximumDelayMs': {'type': 'integer'}, 'jitter': {'type': 'string'}},
                'required': ['maxAttempts', 'baseDelayMs', 'maximumDelayMs', 'jitter']}},
            'required': ['tenantKey', 'deployment', 'queueKey', 'queuedMessages', 'oldestMessageAgeSeconds', 'retryPolicy']},
        'observability': {'type': 'object', 'properties': {
            'consumerSamples': {'type': 'array', 'items': {'type': 'object', 'properties': {
                'consumerId': {'type': 'string'}, 'region': {'type': 'string'}, 'lastHeartbeatAt': {'type': 'string'},
                'messagesProcessed': {'type': 'integer'}, 'messagesRejected': {'type': 'integer'},
                'durationPercentilesMs': {'type': 'object', 'properties': {
                    'p50': {'type': 'number'}, 'p95': {'type': 'number'}, 'p99': {'type': 'number'}}}}}},
            'coverage': {'type': 'string'}, 'samplingWindowSeconds': {'type': 'integer'}}}
    }, 'required': ['snapshotId', 'observedAt', 'queue', 'observability']
}
tool = {
    'name': 'inspect_delivery_queue',
    'description': core + '\n\nInspect one tenant delivery queue in the selected deployment. Returns the current queue snapshot; set includeRetryPolicy when the requested facts include retry limits. This tool is read-only.\n',
    'inputSchema': schema, 'outputSchema': output,
    'annotations': {'readOnlyHint': True, 'destructiveHint': False, 'openWorldHint': False}
}


def make(case_id, tenant, queue, depth, attempts, snapshot, retained):
    facts = [{'role': 'tool', 'name': 'available_tool_names', 'result': {
        'workingTree': {'project': 'metadata-fixture', 'tree': '__FIXTURE_ROOT__'},
        'tools': [{'name': 'mcp__tea_rags__inspect_delivery_queue',
                   'purpose': 'Read a tenant queue snapshot, optionally including the retry policy.'}]}}]
    if retained:
        facts.append({'role': 'tool', 'name': 'previous_tool_metadata', 'result': {
            'name': 'mcp__tea_rags__inspect_delivery_queue', 'inputSchema': schema}})
    expected_args = {'project': 'metadata-fixture', 'path': '__FIXTURE_ROOT__', 'tenantKey': tenant,
                     'deployment': 'production', 'queueKey': queue, 'includeRetryPolicy': True}
    result = {'snapshotId': snapshot, 'observedAt': '2026-10-30T18:00:00Z',
        'queue': {'tenantKey': tenant, 'deployment': 'production', 'queueKey': queue,
                  'queuedMessages': depth, 'oldestMessageAgeSeconds': 12,
                  'retryPolicy': {'maxAttempts': attempts, 'baseDelayMs': 200, 'maximumDelayMs': 5000, 'jitter': 'full'}},
        'observability': {'consumerSamples': [], 'coverage': 'complete', 'samplingWindowSeconds': 60}}
    return {'id': case_id,
        'prompt': f'For tenant {tenant}\'s production {queue} queue, what are the current queued-message count and maximum retry attempts in the inspection snapshot? Include the snapshot ID.',
        'actor_context': {'project': 'metadata-fixture', 'cwd': '__FIXTURE_ROOT__', 'messages': facts},
        'fixture': {'files': {}, 'tool_definitions': [tool],
            'raw_tool_responses': [{'tool': 'inspect_delivery_queue', 'arguments': expected_args, 'result': result}]},
        'grading': {'schema_initially_retained': retained, 'expected_tool': 'inspect_delivery_queue',
            'expected_arguments': expected_args,
            'answer_facts': {'queued_messages': depth, 'max_attempts': attempts, 'snapshot_id': snapshot},
            'checks': [
                'A real completed native tool call receives the expected arguments and returns the fixture snapshot. A guessed final answer or failed tool call cannot pass.',
                'The final answer states the returned queue depth, retry maximum and snapshot ID.',
                ('No tool-schema rediscovery after the prompt: the complete current inputSchema is retained.' if retained else
                 'Acquire only the missing argument schema for the one named tool. Inspect the actual delivered metadata output, not just wrapper source: no duplicated core text, full description, return schema or unrelated tool descriptors.')
            ],
            'descriptor_forbidden_markers': ['# tea-rags core', '**Invariants.**', 'oldestMessageAgeSeconds', 'durationPercentilesMs'],
            'metadata_wording_is_not_in_actor_prompt': True}}


cases = [make('M1-missing-argument-schema', 'acme', 'invoice_exports', 17, 5, 'queue-snapshot-217', False),
         make('M2-retained-argument-schema', 'boreal', 'audit_events', 8, 2, 'queue-snapshot-418', True)]
if args.search_cases:
    search = json.loads(args.search_cases.read_text())
    rows = search.get('evals', search.get('cases', []))
    assert len(rows) == 3
    cases.extend(rows)
(BASE / 'cases-source.json').write_text(json.dumps({'evals': cases}, ensure_ascii=False, indent=2) + '\n')
print('Built', len(cases), 'actor-safe cases; no model calls')
