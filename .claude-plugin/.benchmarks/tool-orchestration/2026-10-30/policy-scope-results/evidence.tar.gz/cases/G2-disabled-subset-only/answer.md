| Policy | delay_ms | Source path |
|---|---:|---|
| isolated_preview | 0 | config/retry/zone_sigma.yml |
