[config/active_retry.yml](config/active_retry.yml) lists these two policies:

| Policy name | retry_on_timeout | delay_ms | Source |
|---|---|---|---|
| regional_primary | true | 350 | [zone_kappa.yml](config/retry/zone_kappa.yml) |
| isolated_preview | false | 0 | [zone_sigma.yml](config/retry/zone_sigma.yml) |

**isolated_preview** disables timeout retries.
