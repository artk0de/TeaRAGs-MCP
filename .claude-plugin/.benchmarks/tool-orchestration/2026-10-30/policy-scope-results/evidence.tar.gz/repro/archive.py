#!/usr/bin/env python3
"""Compact allowlisted completed policy-scope evidence; never launches actors."""
import gzip
import hashlib
import json
from pathlib import Path
import tomllib

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
OUT = ROOT / '.claude-plugin/.benchmarks/tool-orchestration/2026-10-30/policy-scope-results'
sha = lambda x: hashlib.sha256(x).hexdigest()
load = lambda p: json.loads(p.read_text())
manifest = load(BASE / 'manifest.json'); grade = load(BASE / 'grade.json')
assert len(load(BASE / 'worker-exits.json')) == len(manifest['cases']) == 2
assert len(grade['cases']) == 2 and not OUT.exists()
snapshot = BASE / 'marketplace/harness/codex/tea-rags'
actual = {str(p.relative_to(snapshot)): sha(p.read_bytes()) for p in snapshot.rglob('*') if p.is_file()}
assert actual == manifest['source_plugin_sha256']
assert sha(json.dumps(actual, sort_keys=True, separators=(',', ':')).encode()) == manifest['candidate_fingerprint_sha256']
OUT.mkdir(parents=True); records = []


def write_json(name, data):
    path = OUT / name; path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + '\n')


def copy(source, name, compress=False):
    assert source.is_file() and not source.is_symlink()
    raw = source.read_bytes(); archived = gzip.compress(raw, mtime=0) if compress else raw
    assert not compress or sha(gzip.decompress(archived)) == sha(raw)
    path = OUT / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(archived)
    records.append({'archive_path': name, 'raw_sha256': sha(raw), 'archived_sha256': sha(archived), 'gzip_roundtrip_verified': compress})


safe = {k: manifest[k] for k in ['ROOTGO', 'model', 'effort', 'plugin_version', 'source_plugin_sha256', 'candidate_fingerprint_sha256',
    'source_definition_sha256', 'case_source_sha256', 'fixture_server_sha256', 'helper_sha256', 'runner_sha256', 'prepared_model_turns',
    'max_workers', 'controlled_change', 'old_attempts', 'profile', 'actor_input_boundary', 'preparation_complete']}
safe['cases'] = [{k: c[k] for k in ['key', 'id', 'alias', 'actor_input_sha256', 'fixture_sha256', 'preflight']} for c in manifest['cases']]
write_json('manifest.json', safe)
runtime = {'case_count': 2, 'cases': []}
for meta in manifest['cases']:
    directory = Path(meta['directory']); actor = directory / 'actor'; prefix = 'cases/' + meta['key'] + '/'
    status = load(actor / 'status.json'); assert status['status'] == 'completed' and status['attempt'] == 1
    events = [json.loads(x) for x in (actor / 'events.jsonl').read_text().splitlines() if x.strip()]
    assert sum(e.get('method') == 'turn/started' for e in events) == 1
    starts = sum(e.get('method') == 'hook/started' for e in events); ends = sum(e.get('method') == 'hook/completed' for e in events); assert starts == ends
    runtime['cases'].append({'key': meta['key'], 'status': status, 'native_turns': 1, 'hooks_started': starts, 'hooks_completed': ends})
    for source, target in {'actor-input.json': 'actor-input.json', 'fixture.json': 'fixture.json', 'preflight.json': 'preflight.json',
                           'actor/status.json': 'status.json', 'actor/thread-start.json': 'thread-start.json',
                           'preflight-no-turn/filesystem-denials.json': 'filesystem-denials.json', 'preflight-no-turn/filesystem-allowed.json': 'filesystem-allowed.json',
                           'preflight-no-turn/hooks.json': 'hooks.json', 'preflight-no-turn/skills.json': 'skills.json', 'preflight-no-turn/mcp.json': 'mcp.json'}.items():
        copy(directory / source, prefix + target)
    for source, target in {'actor/events.jsonl': 'events.jsonl.gz', 'actor/turn-events.json': 'turn-events.json.gz',
                           'actor/thread-read.json': 'thread-read.json.gz', 'fixture-tool-audit.jsonl': 'fixture-tool-audit.jsonl.gz'}.items(): copy(directory / source, prefix + target, True)
    state = load(actor / 'thread-read.json'); answers = [i['text'] for t in state['thread']['turns'] for i in t['items'] if i.get('type') == 'agentMessage' and i.get('phase') == 'final_answer']
    (OUT / prefix / 'answer.md').write_text('\n\n'.join(answers) + '\n')
    config = tomllib.loads((Path(meta['home']) / 'config.toml').read_text())
    write_json(prefix + 'profile-proof.json', {'model': config['model'], 'effort': config['model_reasoning_effort'], 'approval_policy': config['approval_policy'],
        'default_permissions': config['default_permissions'], 'permissions': config['permissions'],
        'features': {k: config['features'].get(k) for k in ['sleep_tool', 'unified_exec', 'multi_agent', 'memories', 'apps']},
        'scope': 'Selected nonsecret profile sections only, no whole home config/auth/environment bundle.'})
write_json('runtime-summary.json', runtime)
for name in actual: copy(snapshot / name, 'plugin-snapshot/' + name)
for name in ['cases-source.json', 'grade.json', 'worker-exits.json', 'preflight-summary.json']: copy(BASE / name, name)
for name in ['run.py', 'fixture_mcp.py', 'grade.py', 'archive.py']: copy(BASE / name, 'repro/' + name)
copy(ROOT / '.tmp/plugin-routing-evals/run.py', 'repro/shared-routing-run.py')
copy(ROOT / '.tmp/codex61_app_rpc.py', 'repro/codex61_app_rpc.py')
write_json('raw-sha256.json', {'files': records, 'scope': 'Explicit allowlists; no auth, actor homes, full per-home configs, backend logs or environment bundles.'})
listing = ''.join(f'{sha(p.read_bytes())}  {p.relative_to(OUT)}\n' for p in sorted(OUT.rglob('*')) if p.is_file())
(OUT / 'inventory.sha256').write_text(listing)
print(json.dumps({'output': str(OUT), 'files': sum(p.is_file() for p in OUT.rglob('*')), 'PASS': grade['summary']['PASS'], 'FAIL': grade['summary']['FAIL'], 'inventory_sha256': sha(listing.encode())}))
