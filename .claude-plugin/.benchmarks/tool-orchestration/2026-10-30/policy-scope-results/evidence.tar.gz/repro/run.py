#!/usr/bin/env python3
"""Two explicit policy-scope controls; zero-turn preparation and separate ROOTGO."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import queue
import shutil
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
V2 = ROOT / '.tmp/tool-orchestration-v2'
SOURCE = ROOT / '.claude-plugin/.benchmarks/tool-orchestration/2026-10-30/policy-scope-evals.json'
FINGERPRINT = 'a6367025c7c9cd033bd68c6485316d136c790759ee93e9d6c3646e1c1b49941f'
spec = importlib.util.spec_from_file_location('scope_helpers', ROOT / '.tmp/plugin-routing-evals/run.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.BASE = BASE
original_config = helper.write_config


def profile(meta, plugin, toolbin):
    original_config(meta, plugin, toolbin)
    path = Path(meta['home']) / 'config.toml'
    path.write_text(path.read_text().replace('[features]\n', '[features]\nsleep_tool = false\ndefault_mode_request_user_input = true\nunified_exec = true\n', 1))


helper.write_config = profile


class QuestionRPC(helper.transport.RPC):
    def __init__(self, *args, **kwargs):
        self.user_requests = []
        super().__init__(*args, **kwargs)

    def next(self, timeout=180):
        event = self.q.get(timeout=timeout)
        if '_process_exit' in event:
            raise RuntimeError('app-server exited ' + str(event))
        if 'method' in event and 'id' in event:
            if event['method'] == 'item/tool/requestUserInput':
                self.user_requests.append(event)
            else:
                self.send({'id': event['id'], 'error': {'code': -32000, 'message': 'Eval approval requests disabled'}})
        return event


helper.transport.RPC = QuestionRPC


def prepare():
    assert not (BASE / 'manifest.json').exists(), 'Fresh preparation only'
    definitions = json.loads(SOURCE.read_text())
    cases = definitions['evals']
    assert len(cases) == 2 and {c['id'] for c in cases} == {'G1-all-manifest-policies', 'G2-disabled-subset-only'}
    assert definitions['required_plugin_snapshot']['inventory_fingerprint_sha256'] == FINGERPRINT
    source_snapshot = V2 / 'marketplace/harness/codex/tea-rags'
    inventory = helper.inventory(source_snapshot)
    fingerprint = hashlib.sha256(json.dumps(inventory, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    assert fingerprint == FINGERPRINT
    old_case = next(c for c in json.loads((V2 / 'cases-source.json').read_text())['evals'] if c['id'].startswith('O5'))
    assert all(c['fixture'] == old_case['fixture'] and c['actor_context'] == old_case['actor_context'] for c in cases)
    snapshot = BASE / 'marketplace/harness/codex/tea-rags'
    assert not snapshot.exists()
    shutil.copytree(source_snapshot, snapshot)
    assert helper.inventory(snapshot) == inventory
    (BASE / 'marketplace/.agents/plugins').mkdir(parents=True)
    shutil.copyfile(V2 / 'marketplace/.agents/plugins/marketplace.json', BASE / 'marketplace/.agents/plugins/marketplace.json')
    shutil.copyfile(V2 / 'fixture_mcp.py', BASE / 'fixture_mcp.py')
    helper.dump(BASE / 'cases-source.json', definitions)
    manifest = {'ROOTGO': False, 'model': 'gpt-6.1-sol', 'effort': 'medium', 'plugin_version': '0.53.9',
        'source_plugin_sha256': inventory, 'candidate_fingerprint_sha256': fingerprint,
        'source_definition_sha256': helper.sha(SOURCE), 'case_source_sha256': helper.sha(BASE / 'cases-source.json'),
        'fixture_server_sha256': helper.sha(BASE / 'fixture_mcp.py'),
        'helper_sha256': helper.sha(ROOT / '.tmp/plugin-routing-evals/run.py'), 'runner_sha256': helper.sha(__file__),
        'cases': [], 'prepared_model_turns': 0, 'max_workers': 2,
        'controlled_change': 'Only explicit user answer-scope wording differs. Raw context, fixtures and final a636702 plugin stay fixed.',
        'old_attempts': 'Original O5 strict FAILs preserved; these are two new conditions, not retries or rubric rewrites.',
        'profile': {'sleep_tool': False, 'unified_exec': True, 'default_mode_request_user_input': True},
        'actor_input_boundary': 'Only prompt and retained raw messages; grading and fixture/controller JSON outside denied native workspace.'}
    helper.dump(BASE / 'manifest.json', manifest)
    for case in cases:
        directory = BASE / 'cases' / case['id']; directory.mkdir(parents=True)
        meta = helper.compile_case('policy-scope', case, directory); meta['key'] = case['id']
        helper.install_and_trust(meta, BASE / 'marketplace', '0.53.9', inventory)
        meta['preflight'] = helper.preflight(meta)
        meta['config_sha256'] = helper.sha(Path(meta['home']) / 'config.toml')
        manifest['cases'].append(meta); helper.dump(BASE / 'manifest.json', manifest)
        print('PREFLIGHT', meta['key'], 'trusted+connected+isolated; zero model turns', flush=True)
    assert helper.inventory(snapshot) == inventory and helper.inventory(source_snapshot) == inventory
    manifest['preparation_complete'] = True
    helper.dump(BASE / 'manifest.json', manifest)
    print('PREPARED_NO_MODELS', BASE, flush=True)


def worker(key):
    manifest = json.loads((BASE / 'manifest.json').read_text())
    assert manifest['ROOTGO'] and manifest['preparation_complete']
    assert helper.sha(__file__) == manifest['runner_sha256']
    assert helper.sha(ROOT / '.tmp/plugin-routing-evals/run.py') == manifest['helper_sha256']
    assert helper.sha(BASE / 'fixture_mcp.py') == manifest['fixture_server_sha256']
    meta = next(c for c in manifest['cases'] if c['key'] == key)
    directory = Path(meta['directory']); actor = directory / 'actor'; actor.mkdir()
    assert helper.inventory(Path(meta['plugin'])) == manifest['source_plugin_sha256']
    for path, expected in [(directory / 'actor-input.json', meta['actor_input_sha256']), (directory / 'fixture.json', meta['fixture_sha256']), (Path(meta['home']) / 'config.toml', meta['config_sha256'])]:
        assert helper.sha(path) == expected
    rpc = helper.rpc_for(meta, actor, allow=True); started = time.monotonic()
    status = {'key': key, 'attempt': 1, 'valid_runtime': False, 'model': 'gpt-6.1-sol', 'effort': 'medium'}
    try:
        thread = rpc.call('thread/start', {'cwd': meta['cwd'], 'model': 'gpt-6.1-sol', 'permissions': 'routing_eval', 'approvalPolicy': 'never', 'ephemeral': False, 'experimentalRawEvents': True})
        helper.dump(actor / 'thread-start.json', thread)
        assert thread['model'] == 'gpt-6.1-sol' and thread['reasoningEffort'] == 'medium' and thread['activePermissionProfile']['id'] == 'routing_eval' and not thread.get('instructionSources')
        tid = thread['thread']['id']; status['thread_id'] = tid
        text = json.loads((directory / 'actor-input.json').read_text())['text']
        turn = rpc.call('turn/start', {'threadId': tid, 'cwd': meta['cwd'], 'model': 'gpt-6.1-sol', 'effort': 'medium', 'permissions': 'routing_eval', 'approvalPolicy': 'never', 'input': [{'type': 'text', 'text': text}]})
        turn_id = turn['turn']['id']; status['turn_id'] = turn_id
        events, rpc.pending = rpc.pending, []
        deadline, completed = time.monotonic() + 180, None
        while time.monotonic() < deadline:
            completed = next((e for e in events if e.get('method') == 'turn/completed' and e.get('params', {}).get('turn', {}).get('id') == turn_id), None)
            if completed or rpc.user_requests: break
            try: events.append(rpc.next(timeout=min(30, max(1, deadline - time.monotonic()))))
            except queue.Empty: pass
        if rpc.user_requests and not completed:
            status['status'] = 'awaiting_user'; helper.dump(actor / 'user-requests.json', rpc.user_requests)
            rpc.call('turn/interrupt', {'threadId': tid, 'turnId': turn_id}, timeout=10)
        elif completed:
            status['status'] = completed['params']['turn']['status']; status['valid_runtime'] = status['status'] == 'completed'
        else:
            rpc.call('turn/interrupt', {'threadId': tid, 'turnId': turn_id}, timeout=10)
            status['status'] = 'timeout'
        helper.dump(actor / 'turn-events.json', events)
        helper.dump(actor / 'thread-read.json', rpc.call('thread/read', {'threadId': tid, 'includeTurns': True}))
    except BaseException as error:
        status.update(status='runtime_error', error=str(error))
    finally:
        status['wall_seconds'] = round(time.monotonic() - started, 3); helper.dump(actor / 'status.json', status); helper.close_rpc(rpc)
    print('CASE', key, status['status'], status['wall_seconds'], flush=True)
    return 0 if status['valid_runtime'] else 1


def execute(rootgo):
    assert rootgo, 'Root review and explicit ROOTGO required'
    manifest = json.loads((BASE / 'manifest.json').read_text())
    assert manifest['preparation_complete'] and len(manifest['cases']) == 2
    assert not any((Path(c['directory']) / 'actor').exists() for c in manifest['cases'])
    manifest['ROOTGO'] = True; helper.dump(BASE / 'manifest.json', manifest)
    running = [(subprocess.Popen([helper.PY, str(BASE / 'run.py'), 'worker', c['key']]), c['key']) for c in manifest['cases']]
    exits = []
    for process, key in running:
        process.wait(); exits.append({'key': key, 'exit_code': process.returncode}); helper.dump(BASE / 'worker-exits.json', exits)
    print('POLICY_SCOPE_EOF', BASE, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True); sub.add_parser('prepare')
    run = sub.add_parser('run'); run.add_argument('--rootgo', action='store_true')
    work = sub.add_parser('worker'); work.add_argument('key')
    args = parser.parse_args()
    if args.action == 'prepare': prepare()
    elif args.action == 'run': execute(args.rootgo)
    else: sys.exit(worker(args.key))
