#!/usr/bin/env python3
"""Offline scope/fact grading, separate from batching diagnostics."""
import json
import re
from pathlib import Path

BASE = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text())
manifest = load(BASE / 'manifest.json')
assert len(load(BASE / 'worker-exits.json')) == 2, 'Wait for root-confirmed EOF'
grades = []
for meta in manifest['cases']:
    directory = Path(meta['directory']); actor = directory / 'actor'
    status = load(actor / 'status.json'); fixture = load(directory / 'fixture.json')['files']
    events = [json.loads(x) for x in (actor / 'events.jsonl').read_text().splitlines() if x.strip()]
    native = [e['params']['item'] for e in events if e.get('method') == 'item/completed']
    raw = [e['params']['item'] for e in events if e.get('method') == 'rawResponseItem/completed']
    commands = [x for x in native if x.get('type') == 'commandExecution']
    calls = [x for x in raw if x.get('type') in ('custom_tool_call', 'function_call')]
    outputs = {x['call_id']: x for x in raw if x.get('type') in ('custom_tool_call_output', 'function_call_output')}
    answers = [x for x in native if x.get('type') == 'agentMessage' and x.get('phase') == 'final_answer']
    answer = answers[0]['text'] if len(answers) == 1 else ''
    reads = {}
    for x in commands:
        actions = [a for a in x.get('commandActions', []) if a['type'] == 'read']
        if len(actions) == 1:
            path = str(Path(actions[0]['path']).relative_to(meta['cwd']))
            reads[path] = x
    delivered = []
    for call in calls:
        value = outputs[call['call_id']]['output']
        texts = [value] if isinstance(value, str) else [x['text'] for x in value if 'text' in x]
        for text in texts:
            try: delivered.append(json.loads(text))
            except ValueError: pass
    manifest_bytes = any(x.get('output') == fixture['config/active_retry.yml'] for x in delivered if isinstance(x, dict))
    children = {x['path']: x['result']['value'] for x in delivered if isinstance(x, dict) and 'path' in x and x.get('result', {}).get('status') == 'fulfilled'}
    checks = {'completed_once': status['status'] == 'completed' and status['attempt'] == 1 and sum(e.get('method') == 'turn/started' for e in events) == 1,
              'actual_three_file_bytes': set(reads) == set(fixture) and all(reads[p]['exitCode'] == 0 and reads[p]['aggregatedOutput'] == fixture[p] for p in fixture),
              'actual_manifest_and_selected_bytes_delivered': manifest_bytes and set(children) == set(fixture) - {'config/active_retry.yml'} and all(v['exit_code'] == 0 and v['output'] == fixture[p] for p, v in children.items()),
              'one_final_answer': len(answers) == 1}
    if meta['key'].startswith('G1'):
        checks.update({'all_selected_values_and_paths': bool(re.search(r'regional_primary[^\n]*true[^\n]*350[^\n]*config/retry/zone_kappa\.yml', answer)) and bool(re.search(r'isolated_preview[^\n]*false[^\n]*0[^\n]*config/retry/zone_sigma\.yml', answer)),
                       'disabled_subset_named': bool(re.search(r'isolated_preview[^\n]*disables timeout retries', answer))})
    else:
        checks.update({'filtered_disabled_values_and_path': bool(re.search(r'isolated_preview[^\n]*0[^\n]*config/retry/zone_sigma\.yml', answer)),
                       'no_unasked_enabled_policy': 'regional_primary' not in answer and '350' not in answer})
    child_paths = list(children)
    diagnostics = {'manifest_before_children': reads['config/active_retry.yml']['completedAtMs'] < min(reads[p]['startedAtMs'] for p in child_paths),
                   'executed_labelled_batch': len(calls) == 2 and 'await Promise.allSettled' in calls[1]['input'] and len(children) == 2,
                   'timing_overlap': 'UNVERIFIABLE: zero-ms operations/staggered native scheduling; not a primary scope criterion',
                   'source_tool_count': len(commands), 'outer_call_count': len(calls)}
    grades.append({'case': meta['key'], 'verdict': 'PASS' if all(checks.values()) else 'FAIL', 'checks': checks,
                   'diagnostics': diagnostics, 'evidence': {'thread_id': status['thread_id'], 'turn_id': status['turn_id'],
                   'source_item_ids': {p: x['id'] for p, x in reads.items()}, 'delivered_selected_bytes': children,
                   'outer_calls': calls, 'final_answer': answer}})
report = {'reviewer': '/root/eval_architecture_gate', 'candidate_fingerprint_sha256': manifest['candidate_fingerprint_sha256'],
          'cases': grades, 'summary': {'PASS': sum(x['verdict'] == 'PASS' for x in grades), 'FAIL': sum(x['verdict'] == 'FAIL' for x in grades)},
          'interpretation': 'Two new explicit-scope conditions, one actor each, unchanged fixtures/context and exact same candidate. Both PASS supports a prompt-scope interpretation on these observations; it does not repair/relabel the earlier strict O5 FAIL or establish general completeness behavior. No production rule changed for this diagnostic.'}
(BASE / 'grade.json').write_text(json.dumps(report, indent=2) + '\n')
for grade in grades: print(grade['verdict'], grade['case'], [k for k, v in grade['checks'].items() if not v])
assert report['summary']['PASS'] == 2
